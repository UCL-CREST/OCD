public class getImage {
    private java.io.FileWriter fw;
    public getImage() {
        super();
    }
    public void translogFile ( String[] a ) {
        try {
            this.fw = new java.io.FileWriter ( "ImageList.txt", false );
            int i = 0;
            while ( a[i] != null ) {
                this.fw.write ( a[i] );
                this.fw.write ( 10 );
                i = i + 1;
            }
            this.fw.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( java.io.IOException ignoredException ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void translogFile1 ( String[] a ) {
        try {
            this.fw = new java.io.FileWriter ( "JpgGifList.txt", false );
            int i = 0;
            while ( a[i] != null ) {
                this.fw.write ( a[i] );
                this.fw.write ( 10 );
                i = i + 1;
            }
            this.fw.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( java.io.IOException ignoredException ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void tokenFile ( String s ) {
        String[] a = new String[10];
        String[] a0 = new String[10];
        label0: {
            label1: try {
                try {
                    java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( s ) );
                    String s0 = a1.readLine();
                    int i = 0;
                    int i0 = 0;
                    while ( s0 != null ) {
                        java.util.StringTokenizer a2 = new java.util.StringTokenizer ( s0, " '\"' " );
                        while ( true ) {
                            boolean b = a2.hasMoreTokens();
                            int i1 = i;
                            if ( b ) {
                                String s1 = a2.nextToken();
                                if ( !s1.endsWith ( "gif" ) ) {
                                    boolean b0 = s1.endsWith ( "jpg" );
                                    i = i1;
                                    if ( !b0 ) {
                                        continue;
                                    }
                                }
                                if ( s1.startsWith ( "http" ) ) {
                                    i = i1 + 1;
                                    a[i1] = s1;
                                    System.out.println ( s1 );
                                    java.util.StringTokenizer a3 = new java.util.StringTokenizer ( s1, "/" );
                                    while ( true ) {
                                        boolean b1 = a3.hasMoreTokens();
                                        int i2 = i0;
                                        if ( !b1 ) {
                                            break;
                                        }
                                        String s2 = a3.nextToken();
                                        {
                                            if ( !s2.endsWith ( "gif" ) ) {
                                                boolean b2 = s2.endsWith ( "jpg" );
                                                i0 = i2;
                                                if ( !b2 ) {
                                                    continue;
                                                }
                                            }
                                            i0 = i2 + 1;
                                            a0[i2] = s2;
                                        }
                                    }
                                } else {
                                    String s3 = new StringBuilder().append ( "http://www.cs.rmit.edu." ).append ( s1 ).toString();
                                    i = i1 + 1;
                                    a[i1] = s3;
                                    System.out.println ( s3 );
                                    java.util.StringTokenizer a4 = new java.util.StringTokenizer ( s1, "/" );
                                    while ( true ) {
                                        boolean b3 = a4.hasMoreTokens();
                                        int i3 = i0;
                                        if ( !b3 ) {
                                            break;
                                        }
                                        String s4 = a4.nextToken();
                                        {
                                            if ( !s4.endsWith ( "gif" ) ) {
                                                boolean b4 = s4.endsWith ( "jpg" );
                                                i0 = i3;
                                                if ( !b4 ) {
                                                    continue;
                                                }
                                            }
                                            i0 = i3 + 1;
                                            a0[i3] = s4;
                                        }
                                    }
                                }
                            } else {
                                s0 = a1.readLine();
                                break;
                            }
                        }
                    }
                    this.translogFile ( a );
                    this.translogFile1 ( a0 );
                    a1.close();
                } catch ( java.io.FileNotFoundException ignoredException ) {
                    break label1;
                }
                break label0;
            } catch ( java.io.IOException ignoredException0 ) {
                System.err.println ( "Error " );
                break label0;
            }
            System.err.println ( new StringBuilder().append ( "File " ).append ( s ).append ( " was not found" ).toString() );
        }
    }
}
