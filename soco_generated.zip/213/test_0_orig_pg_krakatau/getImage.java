public class getImage {
    public getImage() {
        super();
    }
}
