public class getImage {
}
