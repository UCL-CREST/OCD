public class getImage {
    private java.io.FileWriter f00;
    public getImage() {
        super();
    }
    public void m00 ( String[] a ) {
        try {
            this.f00 = new java.io.FileWriter ( "ImageList.txt", false );
            int i = 0;
            while ( a[i] != null ) {
                this.f00.write ( a[i] );
                this.f00.write ( 10 );
                i = i + 1;
            }
            this.f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( java.io.IOException ignoredException ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m10 ( String[] a ) {
        try {
            this.f00 = new java.io.FileWriter ( "JpgGifList.txt", false );
            int i = 0;
            while ( a[i] != null ) {
                this.f00.write ( a[i] );
                this.f00.write ( 10 );
                i = i + 1;
            }
            this.f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( java.io.IOException ignoredException ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m20 ( String s ) {
        String[] a = new String[10];
        String[] a0 = new String[10];
        label0: {
            label1: try {
                try {
                    java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( s ) );
                    String s0 = a1.readLine();
                    int i = 0;
                    int i0 = 0;
                    while ( s0 != null ) {
                        java.util.StringTokenizer a2 = new java.util.StringTokenizer ( s0, " '\"' " );
                        while ( a2.hasMoreTokens() ) {
                            String s1 = a2.nextToken();
                            {
                                if ( !s1.endsWith ( "gif" ) && !s1.endsWith ( "jpg" ) ) {
                                    continue;
                                }
                                if ( s1.startsWith ( "http" ) ) {
                                    a[i] = s1;
                                    i = i + 1;
                                    System.out.println ( s1 );
                                    java.util.StringTokenizer a3 = new java.util.StringTokenizer ( s1, "/" );
                                    while ( a3.hasMoreTokens() ) {
                                        String s2 = a3.nextToken();
                                        {
                                            if ( !s2.endsWith ( "gif" ) && !s2.endsWith ( "jpg" ) ) {
                                                continue;
                                            }
                                            a0[i0] = s2;
                                            i0 = i0 + 1;
                                        }
                                    }
                                } else {
                                    String s3 = new StringBuilder().append ( "http://www.cs.rmit.edu." ).append ( s1 ).toString();
                                    a[i] = s3;
                                    i = i + 1;
                                    System.out.println ( s3 );
                                    java.util.StringTokenizer a4 = new java.util.StringTokenizer ( s1, "/" );
                                    while ( a4.hasMoreTokens() ) {
                                        String s4 = a4.nextToken();
                                        {
                                            if ( !s4.endsWith ( "gif" ) && !s4.endsWith ( "jpg" ) ) {
                                                continue;
                                            }
                                            a0[i0] = s4;
                                            i0 = i0 + 1;
                                        }
                                    }
                                }
                            }
                        }
                        s0 = a1.readLine();
                    }
                    this.m00 ( a );
                    this.m10 ( a0 );
                    a1.close();
                } catch ( java.io.FileNotFoundException ignoredException ) {
                    break label1;
                }
                break label0;
            } catch ( java.io.IOException ignoredException0 ) {
                System.err.println ( "Error " );
                break label0;
            }
            System.err.println ( new StringBuilder().append ( "File " ).append ( s ).append ( " was not found" ).toString() );
        }
    }
}
