import java.io.FileNotFoundException;
import java.util.StringTokenizer;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
public class getImage {
    private FileWriter f00;
    public void m00 ( final String[] array ) {
        final String s = "ImageList.txt";
        try {
            this.f00 = new FileWriter ( s, false );
            for ( int n = 0; array[n] != null; ++n ) {
                this.f00.write ( array[n] );
                this.f00.write ( 10 );
            }
            this.f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( IOException ex ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m10 ( final String[] array ) {
        final String s = "JpgGifList.txt";
        try {
            this.f00 = new FileWriter ( s, false );
            for ( int n = 0; array[n] != null; ++n ) {
                this.f00.write ( array[n] );
                this.f00.write ( 10 );
            }
            this.f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( IOException ex ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m20 ( final String s ) {
        final String[] array = new String[10];
        final String[] array2 = new String[10];
        int n = 0;
        int n2 = 0;
        try {
            final BufferedReader bufferedReader = new BufferedReader ( new FileReader ( s ) );
            for ( String s2 = bufferedReader.readLine(); s2 != null; s2 = bufferedReader.readLine() ) {
                final StringTokenizer stringTokenizer = new StringTokenizer ( s2, " '\"' " );
                while ( stringTokenizer.hasMoreTokens() ) {
                    final String nextToken = stringTokenizer.nextToken();
                    if ( nextToken.endsWith ( "gif" ) || nextToken.endsWith ( "jpg" ) ) {
                        if ( !nextToken.startsWith ( "http" ) ) {
                            final String string = "http://www.cs.rmit.edu." + nextToken;
                            array[n] = string;
                            ++n;
                            System.out.println ( string );
                            final StringTokenizer stringTokenizer2 = new StringTokenizer ( nextToken, "/" );
                            while ( stringTokenizer2.hasMoreTokens() ) {
                                final String nextToken2 = stringTokenizer2.nextToken();
                                if ( nextToken2.endsWith ( "gif" ) || nextToken2.endsWith ( "jpg" ) ) {
                                    array2[n2] = nextToken2;
                                    ++n2;
                                }
                            }
                        } else {
                            array[n] = nextToken;
                            ++n;
                            System.out.println ( nextToken );
                            final StringTokenizer stringTokenizer3 = new StringTokenizer ( nextToken, "/" );
                            while ( stringTokenizer3.hasMoreTokens() ) {
                                final String nextToken3 = stringTokenizer3.nextToken();
                                if ( nextToken3.endsWith ( "gif" ) || nextToken3.endsWith ( "jpg" ) ) {
                                    array2[n2] = nextToken3;
                                    ++n2;
                                }
                            }
                        }
                    }
                }
            }
            this.m00 ( array );
            this.m10 ( array2 );
            bufferedReader.close();
        } catch ( FileNotFoundException ex ) {
            System.err.println ( "File " + s + " was not found" );
        } catch ( IOException ex2 ) {
            System.err.println ( "Error " );
        }
    }
}
