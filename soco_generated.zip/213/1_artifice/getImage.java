import java.io.*;
import java.util.*;
public class getImage {
    private FileWriter f00;
    public getImage() {
    }
    public void m00 ( String[] v0 ) {
        String v1;
        v1 = "ImageList.txt";
        try {
            f00 = new FileWriter ( v1, false );
            int v2;
            v2 = 0;
            while ( v0[v2] != null ) {
                f00.write ( v0[v2] );
                f00.write ( '\n' );
                v2 = v2 + 1;
            }
            f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( IOException v3 ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m10 ( String[] v4 ) {
        String v5;
        v5 = "JpgGifList.txt";
        try {
            f00 = new FileWriter ( v5, false );
            int v6;
            v6 = 0;
            while ( v4[v6] != null ) {
                f00.write ( v4[v6] );
                f00.write ( '\n' );
                v6 = v6 + 1;
            }
            f00.close();
            System.out.println ( "Saved sucessfully" );
        } catch ( IOException v7 ) {
            System.out.println ( "Error saving the file" );
        }
    }
    public void m20 ( String v8 ) {
        String v9;
        v9 = "";
        String v10;
        v10 = "";
        String v11;
        v11 = "";
        String v12;
        v12 = "";
        String v13;
        v13 = null;
        String[] v14;
        v14 = new String[10];
        String[] v15;
        v15 = new String[10];
        boolean v16;
        v16 = false;
        int v17;
        v17 = 0;
        int v18;
        v18 = 0;
        try {
            BufferedReader v19;
            v19 = new BufferedReader ( new FileReader ( v8 ) );
            v13 = v19.readLine();
            for ( ; v13 != null; ) {
                StringTokenizer v20;
                v20 = new StringTokenizer ( v13, " '\"' " );
                for ( ; v20.hasMoreTokens(); ) {
                    v10 = v20.nextToken();
                    if ( v10.endsWith ( "gif" ) || v10.endsWith ( "jpg" ) ) {
                        if ( !v10.startsWith ( "http" ) ) {
                            v11 = "http://www.cs.rmit.edu." + v10;
                            v14[+v17] = v11;
                            v17 = v17 + 1;
                            System.out.println ( v11 );
                            StringTokenizer v21;
                            v21 = new StringTokenizer ( v10, "/" );
                            for ( ; v21.hasMoreTokens(); ) {
                                v12 = v21.nextToken();
                                if ( v12.endsWith ( "gif" ) || v12.endsWith ( "jpg" ) ) {
                                    v15[+v18] = v12;
                                    v18 = v18 + 1;
                                }
                            }
                        } else {
                            v14[+v17] = v10;
                            v17 = v17 + 1;
                            System.out.println ( v10 );
                            StringTokenizer v22;
                            v22 = new StringTokenizer ( v10, "/" );
                            for ( ; v22.hasMoreTokens(); ) {
                                v12 = v22.nextToken();
                                if ( v12.endsWith ( "gif" ) || v12.endsWith ( "jpg" ) ) {
                                    v15[+v18] = v12;
                                    v18 = v18 + 1;
                                }
                            }
                        }
                    }
                }
                v13 = v19.readLine();
            }
            m00 ( v14 );
            m10 ( v15 );
            v19.close();
        } catch ( FileNotFoundException v23 ) {
            System.err.println ( "File " + v8 + " was not found" );
        } catch ( IOException v24 ) {
            System.err.println ( "Error " );
        }
    }
}
