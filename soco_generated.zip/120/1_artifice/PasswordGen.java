public class PasswordGen {
    private int f00 = 0;
    private int f10 = 3;
    private String f20;
    public PasswordGen() {
        f20 = "";
    }
    public boolean m00 ( int v0 ) {
        f00 = v0;
        return true;
    }
    public String m10() {
        return f20;
    }
    public String m20 ( int v1 ) {
        int v2, v3, v4;
        int v5[];
        boolean v6;
        v5 = new int[f10];
        v4 = 0;
        while ( v4 < f10 ) {
            v5[v4] = 0;
            v4 = v4 + 1;
        }
        v6 = false;
        v3 = v1;
        v4 = 0;
        for ( ; !v6; ) {
            v2 = v3 % 52;
            if ( v2 == 0 ) {
                v2 = 52;
            }
            v3 = v3 / 52;
            v5[v4] = v2;
            if ( v4 < f10 ) {
                v4 = v4 + 1;
            }
            if ( v3 == 0 ) {
                v6 = true;
            }
        }
        f20 = m40 ( v5 );
        return f20;
    }
    public String m30() {
        f00 = f00 + 1;
        f20 = m20 ( f00 );
        return f20;
    }
    private String m40 ( int[] v7 ) {
        String v8;
        int v9;
        v8 = "";
        v9 = 0;
        while ( v9 < f10 ) {
            if ( v7[v9] != 0 ) {
                if ( v7[v9] < 27 ) {
                    v8 = v8 + ( new Character ( ( char ) ( v7[v9] + 64 ) ).toString() );
                } else {
                    v8 = v8 + ( new Character ( ( char ) ( v7[v9] + 70 ) ).toString() );
                }
            }
            v9 = v9 + 1;
        }
        return v8;
    }
}
