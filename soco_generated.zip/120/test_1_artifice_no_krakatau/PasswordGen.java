public class PasswordGen {
    private int f00;
    private int f10;
    private String f20;
    public PasswordGen() {
        super();
        this.f00 = 0;
        this.f10 = 3;
        this.f20 = "";
    }
    public boolean m00 ( int i ) {
        this.f00 = i;
        return true;
    }
    public String m10() {
        return this.f20;
    }
    public String m20 ( int i ) {
        int[] a = new int[this.f10];
        int i0 = 0;
        while ( i0 < this.f10 ) {
            a[i0] = 0;
            i0 = i0 + 1;
        }
        int i1 = 0;
        boolean b = false;
        while ( !b ) {
            int i2 = i % 52;
            if ( i2 == 0 ) {
                i2 = 52;
            }
            int i3 = i / 52;
            a[i1] = i2;
            if ( i1 < this.f10 ) {
                i1 = i1 + 1;
            }
            if ( i3 != 0 ) {
                i = i3;
                b = false;
            } else {
                i = 0;
                b = true;
            }
        }
        this.f20 = this.m40 ( a );
        return this.f20;
    }
    public String m30() {
        this.f00 = this.f00 + 1;
        this.f20 = this.m20 ( this.f00 );
        return this.f20;
    }
    private String m40 ( int[] a ) {
        String s = "";
        int i = 0;
        while ( i < this.f10 ) {
            if ( a[i] != 0 ) {
                if ( ( a[i] != 0 ) >= 27 ) {
                    StringBuilder a0 = new StringBuilder().append ( s );
                    int i0 = ( char ) ( a[i] + 70 );
                    s = a0.append ( new Character ( ( char ) i0 ).toString() ).toString();
                } else {
                    StringBuilder a1 = new StringBuilder().append ( s );
                    int i1 = ( char ) ( a[i] + 64 );
                    s = a1.append ( new Character ( ( char ) i1 ).toString() ).toString();
                }
            }
            i = i + 1;
        }
        return s;
    }
}
