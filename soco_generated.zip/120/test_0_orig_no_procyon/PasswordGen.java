public class PasswordGen {
    private int iLastSeed;
    private int iPasswordLength;
    private String strPassword;
    public PasswordGen() {
        this.iLastSeed = 0;
        this.iPasswordLength = 3;
        this.strPassword = "";
    }
    public boolean setSeed ( final int iLastSeed ) {
        this.iLastSeed = iLastSeed;
        return true;
    }
    public String getPassword() {
        return this.strPassword;
    }
    public String getPassword ( final int n ) {
        final int[] array = new int[this.iPasswordLength];
        for ( int i = 0; i < this.iPasswordLength; ++i ) {
            array[i] = 0;
        }
        int j = 0;
        int n2 = n;
        int n3 = 0;
        while ( j == 0 ) {
            int n4 = n2 % 52;
            if ( n4 == 0 ) {
                n4 = 52;
            }
            n2 /= 52;
            array[n3] = n4;
            if ( n3 < this.iPasswordLength ) {
                ++n3;
            }
            if ( n2 == 0 ) {
                j = 1;
            }
        }
        return this.strPassword = this.convertPassword ( array );
    }
    public String getNextPassword() {
        ++this.iLastSeed;
        return this.strPassword = this.getPassword ( this.iLastSeed );
    }
    private String convertPassword ( final int[] array ) {
        String s = "";
        for ( int i = 0; i < this.iPasswordLength; ++i ) {
            if ( array[i] != 0 ) {
                if ( array[i] < 27 ) {
                    s += new Character ( ( char ) ( array[i] + 64 ) ).toString();
                } else {
                    s += new Character ( ( char ) ( array[i] + 70 ) ).toString();
                }
            }
        }
        return s;
    }
}
