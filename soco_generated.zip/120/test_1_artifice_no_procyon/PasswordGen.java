public class PasswordGen {
    private int f00;
    private int f10;
    private String f20;
    public PasswordGen() {
        this.f00 = 0;
        this.f10 = 3;
        this.f20 = "";
    }
    public boolean m00 ( final int f00 ) {
        this.f00 = f00;
        return true;
    }
    public String m10() {
        return this.f20;
    }
    public String m20 ( final int n ) {
        final int[] array = new int[this.f10];
        for ( int i = 0; i < this.f10; ++i ) {
            array[i] = 0;
        }
        int j = 0;
        int n2 = n;
        int n3 = 0;
        while ( j == 0 ) {
            int n4 = n2 % 52;
            if ( n4 == 0 ) {
                n4 = 52;
            }
            n2 /= 52;
            array[n3] = n4;
            if ( n3 < this.f10 ) {
                ++n3;
            }
            if ( n2 == 0 ) {
                j = 1;
            }
        }
        return this.f20 = this.m40 ( array );
    }
    public String m30() {
        ++this.f00;
        return this.f20 = this.m20 ( this.f00 );
    }
    private String m40 ( final int[] array ) {
        String s = "";
        for ( int i = 0; i < this.f10; ++i ) {
            if ( array[i] != 0 ) {
                if ( array[i] < 27 ) {
                    s += new Character ( ( char ) ( array[i] + 64 ) ).toString();
                } else {
                    s += new Character ( ( char ) ( array[i] + 70 ) ).toString();
                }
            }
        }
        return s;
    }
}
