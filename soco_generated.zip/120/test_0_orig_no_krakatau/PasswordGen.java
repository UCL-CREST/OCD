public class PasswordGen {
    private int iLastSeed;
    private int iPasswordLength;
    private String strPassword;
    public PasswordGen() {
        super();
        this.iLastSeed = 0;
        this.iPasswordLength = 3;
        this.strPassword = "";
    }
    public boolean setSeed ( int i ) {
        this.iLastSeed = i;
        return true;
    }
    public String getPassword() {
        return this.strPassword;
    }
    public String getPassword ( int i ) {
        int[] a = new int[this.iPasswordLength];
        int i0 = 0;
        while ( i0 < this.iPasswordLength ) {
            a[i0] = 0;
            i0 = i0 + 1;
        }
        int i1 = 0;
        boolean b = false;
        while ( !b ) {
            int i2 = i % 52;
            if ( i2 == 0 ) {
                i2 = 52;
            }
            int i3 = i / 52;
            a[i1] = i2;
            if ( i1 < this.iPasswordLength ) {
                i1 = i1 + 1;
            }
            if ( i3 != 0 ) {
                i = i3;
                b = false;
            } else {
                i = 0;
                b = true;
            }
        }
        this.strPassword = this.convertPassword ( a );
        return this.strPassword;
    }
    public String getNextPassword() {
        this.iLastSeed = this.iLastSeed + 1;
        this.strPassword = this.getPassword ( this.iLastSeed );
        return this.strPassword;
    }
    private String convertPassword ( int[] a ) {
        String s = "";
        int i = 0;
        while ( i < this.iPasswordLength ) {
            if ( a[i] != 0 ) {
                if ( ( a[i] != 0 ) >= 27 ) {
                    StringBuilder a0 = new StringBuilder().append ( s );
                    int i0 = ( char ) ( a[i] + 70 );
                    s = a0.append ( new Character ( ( char ) i0 ).toString() ).toString();
                } else {
                    StringBuilder a1 = new StringBuilder().append ( s );
                    int i1 = ( char ) ( a[i] + 64 );
                    s = a1.append ( new Character ( ( char ) i1 ).toString() ).toString();
                }
            }
            i = i + 1;
        }
        return s;
    }
}
