public class PasswordGen {
    public PasswordGen() {
        super();
    }
}
