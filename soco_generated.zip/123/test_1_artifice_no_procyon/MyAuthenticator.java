import java.net.PasswordAuthentication;
import java.net.Authenticator;
class MyAuthenticator extends Authenticator {
    String f00;
    public MyAuthenticator ( final String f00 ) {
        this.f00 = f00;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( "", this.f00.toCharArray() );
    }
}
