import java.net.PasswordAuthentication;
import java.net.Authenticator;
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( "", null.toCharArray() );
    }
}
