import java.net.*;
import java.io.*;
class MyAuthenticator  extends Authenticator {
    String f00;
    public MyAuthenticator ( String v0 ) {
        f00 = v0;
    }
    protected PasswordAuthentication getPasswordAuthentication() {
        String v1;
        v1 = f00;
        return new PasswordAuthentication ( "", v1.toCharArray() );
    }
}
