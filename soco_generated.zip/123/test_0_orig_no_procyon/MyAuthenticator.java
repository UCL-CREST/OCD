import java.net.PasswordAuthentication;
import java.net.Authenticator;
class MyAuthenticator extends Authenticator {
    String password;
    public MyAuthenticator ( final String password ) {
        this.password = password;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( "", this.password.toCharArray() );
    }
}
