class MyAuthenticator extends java.net.Authenticator {
    String password;
    public MyAuthenticator ( String s ) {
        super();
        this.password = s;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( "", this.password.toCharArray() );
    }
}
