class MyAuthenticator extends java.net.Authenticator {
    String f00;
    public MyAuthenticator ( String s ) {
        super();
        this.f00 = s;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( "", this.f00.toCharArray() );
    }
}
