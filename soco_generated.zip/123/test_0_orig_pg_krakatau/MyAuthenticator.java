class MyAuthenticator extends java.net.Authenticator {
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( "", ( ( String ) null ).toCharArray() );
    }
}
