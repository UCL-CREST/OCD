import java.net.InetAddress;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.net.URLConnection;
import java.io.IOException;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.net.URL;
public class WatchDog {
    public static final int interval = 79200000;
    public static void main ( final String[] array ) {
        final WatchDog watchDog = new WatchDog();
        final Thread thread = new Thread();
        final String s = new String();
        final String s2 = new String();
        final String s3 = new String ( "http://www.cs.rmit.edu./students/" );
        try {
            final URL url = new URL ( s3 );
            final URLConnection openConnection = url.openConnection();
            openConnection.connect();
            System.out.println ( "Connection opened......" );
            System.out.println ( "Retrieving data from URL" );
            final DataInputStream dataInputStream = new DataInputStream ( new BufferedInputStream ( openConnection.getInputStream() ) );
            System.out.println ( " data from the URL......" );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( ( InputStream ) url.getContent() ) );
            String line;
            while ( ( line = dataInputStream.readLine() ) != null ) {
                System.out.println ( line );
                new FileWriter ( "watchdogresult.html" ).write ( line );
            }
            System.out.println ( "Waiting for any change...." );
            Thread.sleep ( 79200000L );
            final URLConnection openConnection2 = url.openConnection();
            openConnection2.connect();
            while ( new DataInputStream ( new BufferedInputStream ( openConnection2.getInputStream() ) ).readLine() != null ) {
                new FileWriter ( "watchdogresult.tmp" ).write ( s2 );
            }
            if ( !true ) {
                watchDog.mail();
            }
        } catch ( InterruptedException ex2 ) {}
        catch ( IOException ex ) {
            ex.printStackTrace();
            final String s4 = new String ( ex.getMessage() );
            if ( s4 != null ) {
                System.out.println ( "Message :" + s4 );
            } else {
                System.out.println ( "Other problems" );
            }
        }
    }
    public void mail() {
        try {
            final String s = new String ( "Watchdog Reporter" );
            final String s2 = new String ( "@cs.rmit.edu." );
            final String s3 = new String ( " is a change in " );
            final URLConnection openConnection = new URL ( "mailto:" + s2 ).openConnection();
            openConnection.setDoInput ( false );
            openConnection.setDoOutput ( true );
            System.out.println ( "Connecting..." );
            System.out.flush();
            openConnection.connect();
            final PrintWriter printWriter = new PrintWriter ( new OutputStreamWriter ( openConnection.getOutputStream() ) );
            printWriter.println ( "From: \"" + s + "\" <" + System.getProperty ( "user.name" ) + "@" + InetAddress.getLocalHost().getHostName() + ">" );
            printWriter.println ( ": " );
            printWriter.println ( "Subject: " + s3 );
            printWriter.println();
            final String s4 = new String ( "Watchdog observe that  is a change in the web  ." );
            printWriter.close();
            System.out.println ( "Message sent." );
            System.out.flush();
        } catch ( Exception ex ) {
            System.err.println ( ex );
        }
    }
}
