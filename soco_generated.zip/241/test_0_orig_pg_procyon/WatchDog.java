import java.net.URLConnection;
import java.io.IOException;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.net.URL;
public class WatchDog {
    public static void main ( final String[] array ) {
        new WatchDog();
        new Thread();
        new String();
        final String s = new String();
        final String s2 = new String ( "http://www.cs.rmit.edu./students/" );
        try {
            final URL url;
            final URLConnection openConnection;
            ( openConnection = ( url = new URL ( s2 ) ).openConnection() ).connect();
            System.out.println ( "Connection opened......" );
            System.out.println ( "Retrieving data from URL" );
            final DataInputStream dataInputStream = new DataInputStream ( new BufferedInputStream ( openConnection.getInputStream() ) );
            System.out.println ( " data from the URL......" );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( ( InputStream ) url.getContent() ) );
            String line;
            while ( ( line = dataInputStream.readLine() ) != null ) {
                System.out.println ( line );
                new FileWriter ( "watchdogresult.html" ).write ( line );
            }
            System.out.println ( "Waiting for any change...." );
            Thread.sleep ( 79200000L );
            final URLConnection openConnection2;
            ( openConnection2 = url.openConnection() ).connect();
            while ( new DataInputStream ( new BufferedInputStream ( openConnection2.getInputStream() ) ).readLine() != null ) {
                new FileWriter ( "watchdogresult.tmp" ).write ( s );
            }
        } catch ( InterruptedException ex3 ) {}
        catch ( IOException ex2 ) {
            final IOException ex = ex2;
            ex2.printStackTrace();
            System.out.println ( "Message :" + new String ( ex.getMessage() ) );
        }
    }
}
