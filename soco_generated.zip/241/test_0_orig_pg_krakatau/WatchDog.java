public class WatchDog {
    public WatchDog() {
        super();
    }
    public static void main ( String[] a ) {
        java.io.IOException a0 = null;
        WatchDog a1 = new WatchDog();
        Thread a2 = new Thread();
        String s = new String();
        String s0 = new String();
        String s1 = new String ( "http://www.cs.rmit.edu./students/" );
        try {
            try {
                java.net.URL a3 = new java.net.URL ( s1 );
                java.net.URLConnection a4 = a3.openConnection();
                a4.connect();
                System.out.println ( "Connection opened......" );
                System.out.println ( "Retrieving data from URL" );
                java.io.DataInputStream a5 = new java.io.DataInputStream ( ( java.io.InputStream ) new java.io.BufferedInputStream ( a4.getInputStream() ) );
                System.out.println ( " data from the URL......" );
                java.io.BufferedReader a6 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( ( java.io.InputStream ) a3.getContent() ) );
                while ( true ) {
                    String s2 = a5.readLine();
                    if ( s2 == null ) {
                        System.out.println ( "Waiting for any change...." );
                        Thread.sleep ( 79200000L );
                        java.net.URLConnection a7 = a3.openConnection();
                        a7.connect();
                        java.io.DataInputStream a8 = new java.io.DataInputStream ( ( java.io.InputStream ) new java.io.BufferedInputStream ( a7.getInputStream() ) );
                        while ( a8.readLine() != null ) {
                            new java.io.FileWriter ( "watchdogresult.tmp" ).write ( s0 );
                        }
                        return;
                    } else {
                        System.out.println ( s2 );
                        new java.io.FileWriter ( "watchdogresult.html" ).write ( s2 );
                    }
                }
            } catch ( java.io.IOException a9 ) {
                a0 = a9;
            }
        } catch ( InterruptedException ignoredException ) {
            return;
        }
        a0.printStackTrace();
        String s3 = new String ( a0.getMessage() );
        System.out.println ( new StringBuilder ( "Message :" ).append ( s3 ).toString() );
    }
}
