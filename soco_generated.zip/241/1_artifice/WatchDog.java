import java.io.*;
import java.net.*;
import java.util.*;
import java.*;
public class WatchDog {
    public static final int f00 = 79200000;
    public static void main ( String[] v0 ) {
        WatchDog v1;
        v1 = new WatchDog();
        Thread v2;
        v2 = new Thread();
        URLConnection v3;
        v3 = null;
        DataInputStream v4;
        v4 = null;
        DataInputStream v5;
        v5 = null;
        String v6;
        String v7;
        String v8;
        v8 = new String();
        String v9;
        v9 = new String();
        String v10;
        v10 = new String ( "http://www.cs.rmit.edu./students/" );
        boolean v11;
        try {
            URL v12;
            v12 = new URL ( v10 );
            v3 = v12.openConnection();
            v3.connect();
            Object v13;
            v13 = null;
            System.out.println ( "Connection opened......" );
            System.out.println ( "Retrieving data from URL" );
            v4 = new DataInputStream ( new BufferedInputStream ( v3.getInputStream() ) );
            System.out.println ( " data from the URL......" );
            v13 = v12.getContent();
            BufferedReader v14;
            v14 = null;
            v14 = new BufferedReader ( new InputStreamReader ( ( InputStream ) v13 ) );
            for ( ; ( v6 = v4.readLine() ) != null; ) {
                System.out.println ( v6 );
                FileWriter v15;
                v15 = new FileWriter ( "watchdogresult.html" );
                v15.write ( v6 );
            }
            System.out.println ( "Waiting for any change...." );
            v2.sleep ( 79200000 );
            v3 = v12.openConnection();
            v3.connect();
            v5 = new DataInputStream ( new BufferedInputStream ( v3.getInputStream() ) );
            for ( ; ( v7 = v5.readLine() ) != null; ) {
                FileWriter v16;
                v16 = new FileWriter ( "watchdogresult.tmp" );
                v16.write ( v9 );
            }
            v11 = true;
            if ( v11 );
            else {
                v11 = false;
                v1.m00();
            }
        } catch ( InterruptedException v17 ) {}
        catch ( IOException v18 ) {
            v18.printStackTrace();
            String v19;
            v19 = new String ( v18.getMessage() );
            if ( v19 != null ) {
                System.out.println ( "Message :" + v19 );
            } else {
                System.out.println ( "Other problems" );
            }
        }
    }
    public void m00() {
        try {
            String v20;
            v20 = new String ( "Watchdog Reporter" );
            String v21;
            v21 = new String ( "@cs.rmit.edu." );
            String v22;
            v22 = new String ( " is a change in " );
            URL v23;
            v23 = new URL ( "mailto:" + v21 );
            URLConnection v24;
            v24 = v23.openConnection();
            v24.setDoInput ( false );
            v24.setDoOutput ( true );
            System.out.println ( "Connecting..." );
            System.out.flush();
            v24.connect();
            PrintWriter v25;
            v25 = new PrintWriter ( new OutputStreamWriter ( v24.getOutputStream() ) );
            v25.println ( "From: \"" + v20 + "\" <" +
                          System.getProperty ( "user.name" ) + "@" +
                          InetAddress.getLocalHost().getHostName() + ">" );
            v25.println ( ": " );
            v25.println ( "Subject: " + v22 );
            v25.println();
            String v26;
            v26 = new String (
                "Watchdog observe that  is a change in the web  ." );
            v25.close();
            System.out.println ( "Message sent." );
            System.out.flush();
        } catch ( Exception v27 ) {
            System.err.println ( v27 );
        }
    }
}
