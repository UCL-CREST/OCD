public class WatchDog {
    final public static int interval = 79200000;
    public WatchDog() {
        super();
    }
    public static void main ( String[] a ) {
        WatchDog a0 = new WatchDog();
        Thread a1 = new Thread();
        String s = new String();
        String s0 = new String();
        String s1 = new String ( "http://www.cs.rmit.edu./students/" );
        label0: {
            java.io.IOException a2 = null;
            label1: try {
                try {
                    java.net.URL a3 = new java.net.URL ( s1 );
                    java.net.URLConnection a4 = a3.openConnection();
                    a4.connect();
                    System.out.println ( "Connection opened......" );
                    System.out.println ( "Retrieving data from URL" );
                    java.io.DataInputStream a5 = new java.io.DataInputStream ( ( java.io.InputStream ) new java.io.BufferedInputStream ( a4.getInputStream() ) );
                    System.out.println ( " data from the URL......" );
                    java.io.BufferedReader a6 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( ( java.io.InputStream ) a3.getContent() ) );
                    while ( true ) {
                        String s2 = a5.readLine();
                        if ( s2 == null ) {
                            break;
                        }
                        System.out.println ( s2 );
                        new java.io.FileWriter ( "watchdogresult.html" ).write ( s2 );
                    }
                    System.out.println ( "Waiting for any change...." );
                    Thread.sleep ( 79200000L );
                    java.net.URLConnection a7 = a3.openConnection();
                    a7.connect();
                    java.io.DataInputStream a8 = new java.io.DataInputStream ( ( java.io.InputStream ) new java.io.BufferedInputStream ( a7.getInputStream() ) );
                    while ( a8.readLine() != null ) {
                        new java.io.FileWriter ( "watchdogresult.tmp" ).write ( s0 );
                    }
                } catch ( java.io.IOException a9 ) {
                    a2 = a9;
                    break label1;
                }
                break label0;
            } catch ( InterruptedException ignoredException ) {
                break label0;
            }
            a2.printStackTrace();
            String s3 = new String ( a2.getMessage() );
            System.out.println ( new StringBuilder().append ( "Message :" ).append ( s3 ).toString() );
        }
    }
    public void mail() {
        try {
            String s = new String ( "Watchdog Reporter" );
            String s0 = new String ( "@cs.rmit.edu." );
            String s1 = new String ( " is a change in " );
            java.net.URLConnection a = new java.net.URL ( new StringBuilder().append ( "mailto:" ).append ( s0 ).toString() ).openConnection();
            a.setDoInput ( false );
            a.setDoOutput ( true );
            System.out.println ( "Connecting..." );
            System.out.flush();
            a.connect();
            java.io.PrintWriter a0 = new java.io.PrintWriter ( ( java.io.Writer ) new java.io.OutputStreamWriter ( a.getOutputStream() ) );
            a0.println ( new StringBuilder().append ( "From: \"" ).append ( s ).append ( "\" <" ).append ( System.getProperty ( "user.name" ) ).append ( "@" ).append ( java.net.InetAddress.getLocalHost().getHostName() ).append ( ">" ).toString() );
            a0.println ( ": " );
            a0.println ( new StringBuilder().append ( "Subject: " ).append ( s1 ).toString() );
            a0.println();
            String s2 = new String ( "Watchdog observe that  is a change in the web  ." );
            a0.close();
            System.out.println ( "Message sent." );
            System.out.flush();
        } catch ( Exception a1 ) {
            System.err.println ( ( Object ) a1 );
        }
    }
}
