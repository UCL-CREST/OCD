public class WatchdogPropertyHelper {
    private static java.util.Properties testProps;
    public WatchdogPropertyHelper() {
        super();
    }
    public static String getProperty ( String s ) {
        try {
            WatchdogPropertyHelper.initProps();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            a.printStackTrace();
        }
        return testProps.getProperty ( s );
    }
    private static void initProps() {
        if ( testProps == null ) {
            testProps = new java.util.Properties();
            java.io.InputStream a = WatchdogPropertyHelper.class.getResourceAsStream ( "/watchdog.properties" );
            testProps.load ( a );
        }
    }
}
