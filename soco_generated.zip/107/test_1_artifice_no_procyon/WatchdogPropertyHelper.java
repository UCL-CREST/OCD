import java.util.Properties;
public class WatchdogPropertyHelper {
    private static Properties f00;
    public static String m00 ( final String s ) {
        try {
            m10();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            ex.printStackTrace();
        }
        return WatchdogPropertyHelper.f00.getProperty ( s );
    }
    private static void m10() throws Exception {
        if ( WatchdogPropertyHelper.f00 == null ) {
            ( WatchdogPropertyHelper.f00 = new Properties() ).load ( WatchdogPropertyHelper.class.getResourceAsStream ( "/watchdog.properties" ) );
        }
    }
}
