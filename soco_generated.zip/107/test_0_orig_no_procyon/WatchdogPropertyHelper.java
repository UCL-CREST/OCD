import java.util.Properties;
public class WatchdogPropertyHelper {
    private static Properties testProps;
    public static String getProperty ( final String s ) {
        try {
            initProps();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            ex.printStackTrace();
        }
        return WatchdogPropertyHelper.testProps.getProperty ( s );
    }
    private static void initProps() throws Exception {
        if ( WatchdogPropertyHelper.testProps == null ) {
            ( WatchdogPropertyHelper.testProps = new Properties() ).load ( WatchdogPropertyHelper.class.getResourceAsStream ( "/watchdog.properties" ) );
        }
    }
}
