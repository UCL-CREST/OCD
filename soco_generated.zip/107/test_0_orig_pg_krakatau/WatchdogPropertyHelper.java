public class WatchdogPropertyHelper {
    public WatchdogPropertyHelper() {
        super();
    }
}
