public class WatchdogPropertyHelper {
    private static java.util.Properties f00;
    public WatchdogPropertyHelper() {
        super();
    }
    public static String m00 ( String s ) {
        try {
            WatchdogPropertyHelper.m10();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            a.printStackTrace();
        }
        return f00.getProperty ( s );
    }
    private static void m10() {
        if ( f00 == null ) {
            f00 = new java.util.Properties();
            java.io.InputStream a = WatchdogPropertyHelper.class.getResourceAsStream ( "/watchdog.properties" );
            f00.load ( a );
        }
    }
}
