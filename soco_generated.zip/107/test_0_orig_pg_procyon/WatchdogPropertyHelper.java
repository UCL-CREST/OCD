public class WatchdogPropertyHelper {
}
