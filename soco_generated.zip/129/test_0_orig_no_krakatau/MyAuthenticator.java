public class MyAuthenticator extends java.net.Authenticator {
    java.net.PasswordAuthentication pa;
    public MyAuthenticator() {
        super();
        this.pa = null;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return this.pa;
    }
    void setPasswordAuthentication ( java.net.PasswordAuthentication a ) {
        this.pa = a;
    }
}
