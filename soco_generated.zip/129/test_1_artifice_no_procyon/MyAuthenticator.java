import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    PasswordAuthentication f00;
    public MyAuthenticator() {
        this.f00 = null;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return this.f00;
    }
    void m10 ( final PasswordAuthentication f00 ) {
        this.f00 = f00;
    }
}
