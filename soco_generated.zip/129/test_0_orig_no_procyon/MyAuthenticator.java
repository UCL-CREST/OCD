import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    PasswordAuthentication pa;
    public MyAuthenticator() {
        this.pa = null;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return this.pa;
    }
    void setPasswordAuthentication ( final PasswordAuthentication pa ) {
        this.pa = pa;
    }
}
