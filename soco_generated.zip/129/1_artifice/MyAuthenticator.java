import java.net.*;
public class MyAuthenticator extends Authenticator {
    PasswordAuthentication f00 = null;;
    protected PasswordAuthentication getPasswordAuthentication() {
        return f00;
    }
    void m10 ( PasswordAuthentication v0 ) {
        this.f00 = v0;
    }
}
