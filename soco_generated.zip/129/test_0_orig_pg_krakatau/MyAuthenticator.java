public class MyAuthenticator extends java.net.Authenticator {
    private java.net.PasswordAuthentication a;
    public MyAuthenticator() {
        super();
        this.a = null;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return null;
    }
}
