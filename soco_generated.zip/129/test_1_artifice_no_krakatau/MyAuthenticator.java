public class MyAuthenticator extends java.net.Authenticator {
    java.net.PasswordAuthentication f00;
    public MyAuthenticator() {
        super();
        this.f00 = null;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return this.f00;
    }
    void m10 ( java.net.PasswordAuthentication a ) {
        this.f00 = a;
    }
}
