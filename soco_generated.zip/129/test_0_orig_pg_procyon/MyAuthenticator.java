import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    private PasswordAuthentication a;
    public MyAuthenticator() {
        this.a = null;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return null;
    }
}
