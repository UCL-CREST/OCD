public class HoldSharedData {
    private int      f00 = 0;
    private    int  f10;
    private    int  f20 = 0;
    private String[] f30;
    private int      f40;
    public HoldSharedData ( int v0, String[] v1, int v2 ) {
        f10 = v0;
        f30 = v1;
        f40 = v2;
    }
    public int m00() {
        return f40;
    }
    public void m10( ) {
        f00 = f00 + 1;
    }
    public int m20() {
        return f00;
    }
    public int m30() {
        return f10;
    }
    public void m40 ( int v3 ) {
        f20 = v3;
    }
    public int m50() {
        return f20;
    }
    public String m60 ( int v4 ) {
        return f30[v4];
    }
}
