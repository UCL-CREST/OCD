import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    String f00;
    String f10;
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new PasswordAuthentication ( this.f00, this.f10.toCharArray() );
    }
    public MyAuthenticator ( final String f00, final String f ) {
        this.f00 = f00;
        this.f10 = f;
    }
}
