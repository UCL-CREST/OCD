import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new PasswordAuthentication ( null, null.toCharArray() );
    }
}
