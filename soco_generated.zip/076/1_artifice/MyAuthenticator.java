import java.io.*;
import java.net.*;
public class MyAuthenticator extends Authenticator {
    String f00;
    String f10;
    protected PasswordAuthentication getPasswordAuthentication() {
        String v0;
        v0 = getRequestingPrompt();
        String v1;
        v1 = getRequestingHost();
        InetAddress v2;
        v2 = getRequestingSite();
        int v3;
        v3 = getRequestingPort();
        return new PasswordAuthentication ( f00,
                                            f10.toCharArray() );
    }
    public MyAuthenticator ( String v4, String v5 ) {
        f00 = v4;
        f10 = v5;
    }
}
