import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class MyAuthenticator extends Authenticator {
    String username;
    String password;
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new PasswordAuthentication ( this.username, this.password.toCharArray() );
    }
    public MyAuthenticator ( final String username, final String password ) {
        this.username = username;
        this.password = password;
    }
}
