public class MyAuthenticator extends java.net.Authenticator {
    String username;
    String password;
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new java.net.PasswordAuthentication ( this.username, this.password.toCharArray() );
    }
    public MyAuthenticator ( String s, String s0 ) {
        super();
        this.username = s;
        this.password = s0;
    }
}
