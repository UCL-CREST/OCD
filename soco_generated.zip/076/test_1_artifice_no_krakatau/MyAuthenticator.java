public class MyAuthenticator extends java.net.Authenticator {
    String f00;
    String f10;
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new java.net.PasswordAuthentication ( this.f00, this.f10.toCharArray() );
    }
    public MyAuthenticator ( String s, String s0 ) {
        super();
        this.f00 = s;
        this.f10 = s0;
    }
}
