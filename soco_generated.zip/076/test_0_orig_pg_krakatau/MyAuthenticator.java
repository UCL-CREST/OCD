public class MyAuthenticator extends java.net.Authenticator {
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        this.getRequestingPrompt();
        this.getRequestingHost();
        this.getRequestingSite();
        this.getRequestingPort();
        return new java.net.PasswordAuthentication ( ( String ) null, ( ( String ) null ).toCharArray() );
    }
}
