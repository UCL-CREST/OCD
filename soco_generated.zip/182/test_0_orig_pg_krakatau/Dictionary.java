public class Dictionary extends java.net.Authenticator {
    private String a;
    private char[] b;
    private java.net.URL c;
    private java.io.BufferedReader d;
    public static void main ( String[] a0 ) {
        Dictionary a1 = null;
        if ( a0.length != 3 ) {
            System.err.println ( "usage: Dictionary <url> <username> <dictionary-file>" );
            System.exit ( 1 );
        }
        String s = a0[0];
        String s0 = a0[1];
        String s1 = a0[2];
        label1: {
            java.net.MalformedURLException a2 = null;
            label2: try {
                try {
                    a1 = new Dictionary ( s, s0, s1 );
                } catch ( java.net.MalformedURLException a3 ) {
                    a2 = a3;
                    break label2;
                }
                break label1;
            } catch ( java.io.FileNotFoundException a4 ) {
                a4.printStackTrace();
                System.exit ( 1 );
                a1 = null;
                break label1;
            }
            a2.printStackTrace();
            System.exit ( 1 );
            a1 = null;
        }
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) a1 );
        java.net.URL a5 = a1.c;
        try {
            java.net.HttpURLConnection a6 = ( java.net.HttpURLConnection ) a5.openConnection();
            a6.connect();
            while ( a6.getResponseCode() == 401 ) {
                if ( a1.b == null ) {
                    break;
                }
                label0: {
                    NullPointerException a7 = null;
                    try {
                        try {
                            a6.getInputStream();
                            a6.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a8 ) {
                        a7 = a8;
                    }
                    a7.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a6 = ( java.net.HttpURLConnection ) a1.c.openConnection();
            }
        } catch ( java.io.IOException a9 ) {
            a9.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder ( "password=" ).append ( new String ( a1.b ) ).toString() );
    }
    private Dictionary ( String s, String s0, String s1 ) {
        super();
        this.c = new java.net.URL ( s );
        this.a = s0;
        char[] a0 = new char[1];
        a0[0] = ( char ) 97;
        this.b = a0;
        this.d = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( new java.io.File ( s1 ) ) );
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = null;
        java.io.BufferedReader a0 = this.d;
        try {
            s = null;
            s = a0.readLine();
            while ( s != null && s.length() != 3 ) {
                s = this.d.readLine();
            }
        } catch ( java.io.IOException a1 ) {
            a1.printStackTrace();
            System.exit ( 1 );
        }
        if ( s.length() == 3 ) {
            this.b = s.toCharArray();
        } else {
            this.b = null;
        }
        return new java.net.PasswordAuthentication ( this.a, this.b );
    }
}
