public class Dictionary extends java.net.Authenticator {
    private String f00;
    private char[] f10;
    private java.net.URL f20;
    private java.io.BufferedReader f30;
    public static void main ( String[] a ) {
        Dictionary a0 = null;
        if ( a.length != 3 ) {
            System.err.println ( "usage: Dictionary <url> <username> <dictionary-file>" );
            System.exit ( 1 );
        }
        String s = a[0];
        String s0 = a[1];
        String s1 = a[2];
        label0: {
            java.net.MalformedURLException a1 = null;
            label1: try {
                try {
                    a0 = new Dictionary ( s, s0, s1 );
                } catch ( java.net.MalformedURLException a2 ) {
                    a1 = a2;
                    break label1;
                }
                break label0;
            } catch ( java.io.FileNotFoundException a3 ) {
                a3.printStackTrace();
                System.exit ( 1 );
                a0 = null;
                break label0;
            }
            a1.printStackTrace();
            System.exit ( 1 );
            a0 = null;
        }
        a0.m00();
    }
    public Dictionary ( String s, String s0, String s1 ) {
        super();
        this.f20 = new java.net.URL ( s );
        this.f00 = s0;
        char[] a = new char[1];
        a[0] = ( char ) 97;
        this.f10 = a;
        this.f30 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( new java.io.File ( s1 ) ) );
    }
    public void m00() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) this );
        java.net.URL a = this.f20;
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) a.openConnection();
            a0.connect();
            while ( a0.getResponseCode() == 401 ) {
                if ( this.f10 == null ) {
                    break;
                }
                label0: {
                    NullPointerException a1 = null;
                    try {
                        try {
                            a0.getInputStream();
                            a0.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a2 ) {
                        a1 = a2;
                    }
                    a1.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a0 = ( java.net.HttpURLConnection ) this.f20.openConnection();
            }
        } catch ( java.io.IOException a3 ) {
            a3.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder().append ( "password=" ).append ( new String ( this.f10 ) ).toString() );
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = null;
        java.io.BufferedReader a = this.f30;
        try {
            s = null;
            s = a.readLine();
            while ( s != null ) {
                {
                    if ( s.length() != 3 ) {
                        s = this.f30.readLine();
                        continue;
                    }
                    break;
                }
            }
        } catch ( java.io.IOException a0 ) {
            a0.printStackTrace();
            System.exit ( 1 );
        }
        if ( s.length() == 3 ) {
            this.f10 = s.toCharArray();
        } else {
            this.f10 = null;
        }
        return new java.net.PasswordAuthentication ( this.f00, this.f10 );
    }
}
