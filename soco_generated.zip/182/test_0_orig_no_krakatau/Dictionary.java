public class Dictionary extends java.net.Authenticator {
    private String username;
    private char[] thisPassword;
    private java.net.URL url;
    private java.io.BufferedReader bf;
    public static void main ( String[] a ) {
        Dictionary a0 = null;
        if ( a.length != 3 ) {
            System.err.println ( "usage: Dictionary <url> <username> <dictionary-file>" );
            System.exit ( 1 );
        }
        String s = a[0];
        String s0 = a[1];
        String s1 = a[2];
        label0: {
            java.net.MalformedURLException a1 = null;
            label1: try {
                try {
                    a0 = new Dictionary ( s, s0, s1 );
                } catch ( java.net.MalformedURLException a2 ) {
                    a1 = a2;
                    break label1;
                }
                break label0;
            } catch ( java.io.FileNotFoundException a3 ) {
                a3.printStackTrace();
                System.exit ( 1 );
                a0 = null;
                break label0;
            }
            a1.printStackTrace();
            System.exit ( 1 );
            a0 = null;
        }
        a0.work();
    }
    public Dictionary ( String s, String s0, String s1 ) {
        super();
        this.url = new java.net.URL ( s );
        this.username = s0;
        char[] a = new char[1];
        a[0] = ( char ) 97;
        this.thisPassword = a;
        this.bf = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( new java.io.File ( s1 ) ) );
    }
    public void work() {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) this );
        java.net.URL a = this.url;
        try {
            java.net.HttpURLConnection a0 = ( java.net.HttpURLConnection ) a.openConnection();
            a0.connect();
            while ( a0.getResponseCode() == 401 ) {
                if ( this.thisPassword == null ) {
                    break;
                }
                label0: {
                    NullPointerException a1 = null;
                    try {
                        try {
                            a0.getInputStream();
                            a0.connect();
                            continue;
                        } catch ( java.net.ProtocolException ignoredException ) {
                            break label0;
                        }
                    } catch ( NullPointerException a2 ) {
                        a1 = a2;
                    }
                    a1.printStackTrace();
                    System.exit ( 1 );
                    continue;
                }
                a0 = ( java.net.HttpURLConnection ) this.url.openConnection();
            }
        } catch ( java.io.IOException a3 ) {
            a3.printStackTrace();
            System.exit ( 1 );
        }
        System.out.println ( new StringBuilder().append ( "password=" ).append ( new String ( this.thisPassword ) ).toString() );
    }
    public java.net.PasswordAuthentication getPasswordAuthentication() {
        String s = null;
        java.io.BufferedReader a = this.bf;
        try {
            s = null;
            s = a.readLine();
            while ( s != null ) {
                {
                    if ( s.length() != 3 ) {
                        s = this.bf.readLine();
                        continue;
                    }
                    break;
                }
            }
        } catch ( java.io.IOException a0 ) {
            a0.printStackTrace();
            System.exit ( 1 );
        }
        if ( s.length() == 3 ) {
            this.thisPassword = s.toCharArray();
        } else {
            this.thisPassword = null;
        }
        return new java.net.PasswordAuthentication ( this.username, this.thisPassword );
    }
}
