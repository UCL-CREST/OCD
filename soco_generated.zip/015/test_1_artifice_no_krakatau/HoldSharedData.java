public class HoldSharedData {
    private int f00;
    private int f10;
    private int f20;
    private String[] f30;
    private int f40;
    public HoldSharedData ( int i, String[] a, int i0 ) {
        super();
        this.f00 = 0;
        this.f20 = 0;
        this.f10 = i;
        this.f30 = a;
        this.f40 = i0;
    }
    public int m00() {
        return this.f40;
    }
    public void m10() {
        this.f00 = this.f00 + 1;
    }
    public int m20() {
        return this.f00;
    }
    public int m30() {
        return this.f10;
    }
    public void m40 ( int i ) {
        this.f20 = i;
    }
    public int m50() {
        return this.f20;
    }
    public String m60 ( int i ) {
        return this.f30[i];
    }
}
