public class HoldSharedData {
}
