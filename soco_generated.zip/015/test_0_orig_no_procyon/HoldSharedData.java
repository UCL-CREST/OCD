public class HoldSharedData {
    private int numOfConnections;
    private int startTime;
    private int totalTime;
    private String[] password;
    private int pwdCount;
    public HoldSharedData ( final int startTime, final String[] password, final int pwdCount ) {
        this.numOfConnections = 0;
        this.totalTime = 0;
        this.startTime = startTime;
        this.password = password;
        this.pwdCount = pwdCount;
    }
    public int getPwdCount() {
        return this.pwdCount;
    }
    public void setNumOfConnections() {
        ++this.numOfConnections;
    }
    public int getNumOfConnections() {
        return this.numOfConnections;
    }
    public int getStartTime() {
        return this.startTime;
    }
    public void setTotalTime ( final int totalTime ) {
        this.totalTime = totalTime;
    }
    public int getTotalTime() {
        return this.totalTime;
    }
    public String getPasswordAt ( final int n ) {
        return this.password[n];
    }
}
