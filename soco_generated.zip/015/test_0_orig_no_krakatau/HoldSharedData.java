public class HoldSharedData {
    private int numOfConnections;
    private int startTime;
    private int totalTime;
    private String[] password;
    private int pwdCount;
    public HoldSharedData ( int i, String[] a, int i0 ) {
        super();
        this.numOfConnections = 0;
        this.totalTime = 0;
        this.startTime = i;
        this.password = a;
        this.pwdCount = i0;
    }
    public int getPwdCount() {
        return this.pwdCount;
    }
    public void setNumOfConnections() {
        this.numOfConnections = this.numOfConnections + 1;
    }
    public int getNumOfConnections() {
        return this.numOfConnections;
    }
    public int getStartTime() {
        return this.startTime;
    }
    public void setTotalTime ( int i ) {
        this.totalTime = i;
    }
    public int getTotalTime() {
        return this.totalTime;
    }
    public String getPasswordAt ( int i ) {
        return this.password[i];
    }
}
