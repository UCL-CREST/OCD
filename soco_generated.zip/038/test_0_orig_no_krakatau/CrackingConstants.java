public class CrackingConstants {
    final public static int quietMode = 0;
    final public static int verboseMode1 = 1;
    final public static int verboseMode2 = 2;
    final public static int simpleScan = 0;
    final public static int casedScan = 1;
    final public static int notFound = -1;
    final public static String[] lowerChars;
    final public static String[] upperChars;
    final public static int punctuationUpperBound = 42;
    final public static int punctuationLowerBound = 36;
    final public static int numbersUpperBound = 35;
    final public static int numbersLowerBound = 26;
    final public static int consonantUpperBound = 25;
    final public static int consonantLowerBound = 6;
    final public static int vowelUpperBound = 5;
    final public static int vowelLowerBound = 0;
    public CrackingConstants() {
        super();
    }
    public static int findIndex ( char a, int i, int i0 ) {
        int i1 = lowerChars.length;
        int i2 = a;
        if ( i1 < i0 ) {
            i0 = lowerChars.length;
        }
        if ( 0 > i ) {
            i = 0;
        }
        while ( i < i0 ) {
            if ( lowerChars[i].indexOf ( i2 ) > -1 ) {
                return i;
            }
            if ( upperChars[i].indexOf ( i2 ) > -1 ) {
                return i;
            }
            i = i + 1;
        }
        return -1;
    }
    static {
        String[] a = new String[43];
        a[0] = "a";
        a[1] = "e";
        a[2] = "i";
        a[3] = "o";
        a[4] = "u";
        a[5] = "y";
        a[6] = "b";
        a[7] = "c";
        a[8] = "d";
        a[9] = "f";
        a[10] = "g";
        a[11] = "h";
        a[12] = "j";
        a[13] = "k";
        a[14] = "l";
        a[15] = "m";
        a[16] = "n";
        a[17] = "p";
        a[18] = "q";
        a[19] = "r";
        a[20] = "s";
        a[21] = "t";
        a[22] = "v";
        a[23] = "w";
        a[24] = "x";
        a[25] = "z";
        a[26] = "0";
        a[27] = "1";
        a[28] = "2";
        a[29] = "3";
        a[30] = "4";
        a[31] = "5";
        a[32] = "6";
        a[33] = "7";
        a[34] = "8";
        a[35] = "9";
        a[36] = "'";
        a[37] = "`";
        a[38] = ".";
        a[39] = ",";
        a[40] = "!";
        a[41] = "\"";
        a[42] = "&";
        lowerChars = a;
        String[] a0 = new String[43];
        a0[0] = "A";
        a0[1] = "E";
        a0[2] = "I";
        a0[3] = "O";
        a0[4] = "U";
        a0[5] = "Y";
        a0[6] = "B";
        a0[7] = "C";
        a0[8] = "D";
        a0[9] = "F";
        a0[10] = "G";
        a0[11] = "H";
        a0[12] = "J";
        a0[13] = "K";
        a0[14] = "L";
        a0[15] = "M";
        a0[16] = "N";
        a0[17] = "P";
        a0[18] = "Q";
        a0[19] = "R";
        a0[20] = "S";
        a0[21] = "T";
        a0[22] = "V";
        a0[23] = "W";
        a0[24] = "X";
        a0[25] = "Z";
        a0[26] = "0";
        a0[27] = "1";
        a0[28] = "2";
        a0[29] = "3";
        a0[30] = "4";
        a0[31] = "5";
        a0[32] = "6";
        a0[33] = "7";
        a0[34] = "8";
        a0[35] = "9";
        a0[36] = "'";
        a0[37] = "`";
        a0[38] = ".";
        a0[39] = ",";
        a0[40] = "!";
        a0[41] = "\"";
        a0[42] = "&";
        upperChars = a0;
    }
}
