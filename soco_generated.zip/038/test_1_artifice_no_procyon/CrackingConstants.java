public class CrackingConstants {
    public static final int f00 = 0;
    public static final int f10 = 1;
    public static final int f20 = 2;
    public static final int f30 = 0;
    public static final int f40 = 1;
    public static final int f50 = -1;
    public static final String[] f60;
    public static final String[] f70;
    public static final int f80 = 42;
    public static final int f90 = 36;
    public static final int f100 = 35;
    public static final int f110 = 26;
    public static final int f120 = 25;
    public static final int f130 = 6;
    public static final int f140 = 5;
    public static final int f150 = 0;
    public static int m00 ( final char c, int n, int length ) {
        if ( CrackingConstants.f60.length < length ) {
            length = CrackingConstants.f60.length;
        }
        if ( 0 > n ) {
            n = 0;
        }
        for ( int i = n; i < length; ++i ) {
            if ( CrackingConstants.f60[i].indexOf ( c ) > -1 ) {
                return i;
            }
            if ( CrackingConstants.f70[i].indexOf ( c ) > -1 ) {
                return i;
            }
        }
        return -1;
    }
    static {
        f60 = new String[] { "a", "e", "i", "o", "u", "y", "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "'", "`", ".", ",", "!", "\"", "&" };
        f70 = new String[] { "A", "E", "I", "O", "U", "Y", "B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "'", "`", ".", ",", "!", "\"", "&" };
    }
}
