public class CrackingConstants {
    public static final int f00 = 0;
    public static final  int f10 = 1;
    public static final int  f20 = 2;
    public static final int f30 = 0;
    public static final int f40 = 1;
    public static final int f50 = -1;
    public static final String [] f60 = {"a", "e", "i", "o", "u", "y",
                                         "b", "c", "d", "f", "g", "h",
                                         "j", "k", "l", "m", "n", "p",
                                         "q", "r", "s", "t", "v", "w",
                                         "x", "z", "0", "1", "2", "3",
                                         "4", "5", "6", "7", "8", "9",
                                         "\'", "`", ".", ",", "!", "\"",
                                         "&"
                                        };
    public static final String [] f70 = {"A", "E", "I", "O", "U", "Y",
                                         "B", "C", "D", "F", "G", "H",
                                         "J", "K", "L", "M", "N", "P",
                                         "Q", "R", "S", "T", "V", "W",
                                         "X", "Z", "0", "1", "2", "3",
                                         "4", "5", "6", "7", "8", "9",
                                         "\'", "`", ".", ",", "!", "\"",
                                         "&"
                                        };
    public static final int f80 = 42;
    public static final int f90 = 36;
    public static final int f100 = 35;
    public static final int f110 = 26;
    public static final int f120 = 25;
    public static final int f130 = 6;
    public static final int f140 = 5;
    public static final int f150 = 0;
    public static int m00 ( char v0, int v1, int v2 ) {
        if ( f60.length < v2 ) {
            v2 = f60.length;
        }
        if ( 0 > v1 ) {
            v1 = 0;
        }
        int v3;
        v3 = v1;
        while ( v3 < v2 ) {
            if ( f60[v3].indexOf ( v0 ) > -1 ) {
                return v3;
            }
            if ( f70[v3].indexOf ( v0 ) > -1 ) {
                return v3;
            }
            v3 = v3 + 1;
        }
        return f50;
    }
}
