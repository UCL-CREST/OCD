class LoginAttemptResults {
    private boolean success;
    private int passwordsTried;
    public LoginAttemptResults() {
        this.success = false;
        this.passwordsTried = 0;
    }
    public void setSuccess ( final boolean success ) {
        this.success = success;
    }
    public boolean getSuccess() {
        return this.success;
    }
    public void setPasswordsTried ( final int passwordsTried ) {
        this.passwordsTried = passwordsTried;
    }
    public int getPasswordsTried() {
        return this.passwordsTried;
    }
}
