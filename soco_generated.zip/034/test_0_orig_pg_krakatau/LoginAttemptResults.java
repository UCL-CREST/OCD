class LoginAttemptResults {
    public LoginAttemptResults() {
        super();
    }
}
