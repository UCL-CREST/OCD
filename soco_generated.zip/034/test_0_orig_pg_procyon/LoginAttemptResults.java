class LoginAttemptResults {
}
