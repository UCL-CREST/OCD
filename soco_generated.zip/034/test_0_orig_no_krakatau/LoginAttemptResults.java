class LoginAttemptResults {
    private boolean success;
    private int passwordsTried;
    public LoginAttemptResults() {
        super();
        this.success = false;
        this.passwordsTried = 0;
    }
    public void setSuccess ( boolean b ) {
        this.success = b;
    }
    public boolean getSuccess() {
        return this.success;
    }
    public void setPasswordsTried ( int i ) {
        this.passwordsTried = i;
    }
    public int getPasswordsTried() {
        return this.passwordsTried;
    }
}
