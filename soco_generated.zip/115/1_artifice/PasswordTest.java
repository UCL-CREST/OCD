import java.net.*;
import java.util.*;
import java.io.*;
public class PasswordTest {
    private String f00;
    private String f10;
    private String f20;
    public PasswordTest ( String v0, String v1, String v2 ) {
        f00 = v0;
        f10 = v1;
        f20 = v2;
    }
    boolean m00() {
        boolean v3;
        v3 = false;
        Authenticator.setDefault ( new MyAuthenticator () );
        try {
            URL v4;
            v4 = new URL ( f00 );
            HttpURLConnection v5;
            v5 = ( HttpURLConnection ) v4.openConnection();
            v5.connect();
            if ( v5.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                v3 = true;
            }
        } catch ( IOException v6 ) {}
        return v3;
    }
    class MyAuthenticator extends Authenticator {
        protected PasswordAuthentication getPasswordAuthentication() {
            String v7;
            v7 = f10;
            String v8;
            v8 = f20;
            return new PasswordAuthentication ( v7, v8.toCharArray() );
        }
    }
}
