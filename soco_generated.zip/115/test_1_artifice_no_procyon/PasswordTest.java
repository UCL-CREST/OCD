import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.Authenticator;
public class PasswordTest {
    private String f00;
    private String f10;
    private String f20;
    public PasswordTest ( final String f00, final String f, final String f2 ) {
        this.f00 = f00;
        this.f10 = f;
        this.f20 = f2;
    }
    boolean m00() {
        boolean b = false;
        Authenticator.setDefault ( new MyAuthenticator() );
        try {
            final HttpURLConnection httpURLConnection = ( HttpURLConnection ) new URL ( this.f00 ).openConnection();
            httpURLConnection.connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                b = true;
            }
        } catch ( IOException ex ) {}
        return b;
    }
    class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication ( PasswordTest.this.f10, PasswordTest.this.f20.toCharArray() );
        }
    }
}
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( PasswordTest.access$000 ( PasswordTest.this ), PasswordTest.access$100 ( PasswordTest.this ).toCharArray() );
    }
}
