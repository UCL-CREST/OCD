import java.net.PasswordAuthentication;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.Authenticator;
public class PasswordTest {
    private String strURL;
    private String strUsername;
    private String strPassword;
    public PasswordTest ( final String strURL, final String strUsername, final String strPassword ) {
        this.strURL = strURL;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
    }
    boolean func() {
        boolean b = false;
        Authenticator.setDefault ( new MyAuthenticator() );
        try {
            final HttpURLConnection httpURLConnection = ( HttpURLConnection ) new URL ( this.strURL ).openConnection();
            httpURLConnection.connect();
            if ( httpURLConnection.getResponseMessage().equalsIgnoreCase ( "OK" ) ) {
                b = true;
            }
        } catch ( IOException ex ) {}
        return b;
    }
    class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication ( PasswordTest.this.strUsername, PasswordTest.this.strPassword.toCharArray() );
        }
    }
}
class MyAuthenticator extends Authenticator {
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( PasswordTest.access$000 ( PasswordTest.this ), PasswordTest.access$100 ( PasswordTest.this ).toCharArray() );
    }
}
