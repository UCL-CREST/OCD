public class PasswordTest {
    private String f00;
    private String f10;
    private String f20;
    public PasswordTest ( String s, String s0, String s1 ) {
        super();
        this.f00 = s;
        this.f10 = s0;
        this.f20 = s1;
    }
    boolean m00() {
        boolean b = false;
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new PasswordTest$MyAuthenticator ( this ) );
        String s = this.f00;
        try {
            java.net.HttpURLConnection a = ( java.net.HttpURLConnection ) new java.net.URL ( s ).openConnection();
            a.connect();
            b = a.getResponseMessage().equalsIgnoreCase ( "OK" );
        } catch ( java.io.IOException ignoredException ) {
            b = false;
        }
        return b;
    }
    static String access$000 ( PasswordTest a ) {
        return a.f10;
    }
    static String access$100 ( PasswordTest a ) {
        return a.f20;
    }
}
class PasswordTest$MyAuthenticator extends java.net.Authenticator {
    final PasswordTest this$0;
    PasswordTest$MyAuthenticator ( PasswordTest a ) {
        this.this$0 = a;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( PasswordTest.access$000 ( this.this$0 ), PasswordTest.access$100 ( this.this$0 ).toCharArray() );
    }
}
