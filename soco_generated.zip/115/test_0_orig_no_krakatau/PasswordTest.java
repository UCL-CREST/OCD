public class PasswordTest {
    private String strURL;
    private String strUsername;
    private String strPassword;
    public PasswordTest ( String s, String s0, String s1 ) {
        super();
        this.strURL = s;
        this.strUsername = s0;
        this.strPassword = s1;
    }
    boolean func() {
        boolean b = false;
        java.net.Authenticator.setDefault ( ( java.net.Authenticator ) new PasswordTest$MyAuthenticator ( this ) );
        String s = this.strURL;
        try {
            java.net.HttpURLConnection a = ( java.net.HttpURLConnection ) new java.net.URL ( s ).openConnection();
            a.connect();
            b = a.getResponseMessage().equalsIgnoreCase ( "OK" );
        } catch ( java.io.IOException ignoredException ) {
            b = false;
        }
        return b;
    }
    static String access$000 ( PasswordTest a ) {
        return a.strUsername;
    }
    static String access$100 ( PasswordTest a ) {
        return a.strPassword;
    }
}
class PasswordTest$MyAuthenticator extends java.net.Authenticator {
    final PasswordTest this$0;
    PasswordTest$MyAuthenticator ( PasswordTest a ) {
        this.this$0 = a;
        super();
    }
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( PasswordTest.access$000 ( this.this$0 ), PasswordTest.access$100 ( this.this$0 ).toCharArray() );
    }
}
