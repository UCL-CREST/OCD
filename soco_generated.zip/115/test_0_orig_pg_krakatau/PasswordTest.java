public class PasswordTest {
    static String a ( PasswordTest a ) {
        return null;
    }
    static String b ( PasswordTest a ) {
        return null;
    }
}
class PasswordTest$MyAuthenticator extends java.net.Authenticator {
    private PasswordTest a;
    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        return new java.net.PasswordAuthentication ( PasswordTest.a ( this.a ), PasswordTest.b ( this.a ).toCharArray() );
    }
}
