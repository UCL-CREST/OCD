import java.net.PasswordAuthentication;
import java.net.Authenticator;
public class PasswordTest {
}
class PasswordTest$MyAuthenticator extends Authenticator {
    private   PasswordTest a;
    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication ( PasswordTest.a ( this.a ), PasswordTest.b ( this.a ).toCharArray() );
    }
}
