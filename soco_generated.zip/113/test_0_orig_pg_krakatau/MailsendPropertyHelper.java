public class MailsendPropertyHelper {
    public MailsendPropertyHelper() {
        super();
    }
}
