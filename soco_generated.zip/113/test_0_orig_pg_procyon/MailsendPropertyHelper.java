public class MailsendPropertyHelper {
}
