import java.util.Properties;
public class MailsendPropertyHelper {
    private static Properties testProps;
    public static String getProperty ( final String s ) {
        try {
            initProps();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            ex.printStackTrace();
        }
        return MailsendPropertyHelper.testProps.getProperty ( s );
    }
    private static void initProps() throws Exception {
        if ( MailsendPropertyHelper.testProps == null ) {
            ( MailsendPropertyHelper.testProps = new Properties() ).load ( MailsendPropertyHelper.class.getResourceAsStream ( "/mailsend.properties" ) );
        }
    }
}
