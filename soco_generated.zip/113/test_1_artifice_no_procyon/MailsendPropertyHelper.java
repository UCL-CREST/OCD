import java.util.Properties;
public class MailsendPropertyHelper {
    private static Properties f00;
    public static String m00 ( final String s ) {
        try {
            m10();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the watchddog Props" );
            ex.printStackTrace();
        }
        return MailsendPropertyHelper.f00.getProperty ( s );
    }
    private static void m10() throws Exception {
        if ( MailsendPropertyHelper.f00 == null ) {
            ( MailsendPropertyHelper.f00 = new Properties() ).load ( MailsendPropertyHelper.class.getResourceAsStream ( "/mailsend.properties" ) );
        }
    }
}
