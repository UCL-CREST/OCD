public class WatchDog {
    public WatchDog() {
        super();
    }
    public static void main ( String[] a ) {
        try {
            Process a0 = Runtime.getRuntime().exec ( new StringBuilder ( "wget -O " ).append ( "file1" ).append ( " " ).append ( "http://www.cs.rmit.edu./students/" ).toString() );
            java.io.BufferedReader a1 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a0.getInputStream() ) );
            java.io.BufferedReader a2 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a0.getErrorStream() ) );
            while ( true ) {
                String s = a1.readLine();
                if ( s == null ) {
                    break;
                }
                System.out.println ( s );
            }
            while ( true ) {
                String s0 = a2.readLine();
                if ( s0 == null ) {
                    break;
                }
                System.out.println ( s0 );
            }
            try {
                a0.waitFor();
            } catch ( InterruptedException ignoredException ) {
            }
        } catch ( java.io.IOException a3 ) {
            System.out.println ( "exception happened - here's what I know: " );
            a3.printStackTrace();
            System.exit ( -1 );
        }
        label0: while ( true ) {
            try {
                Process a4 = Runtime.getRuntime().exec ( "sleep 86400" );
                java.io.BufferedReader a5 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a4.getInputStream() ) );
                java.io.BufferedReader a6 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a4.getErrorStream() ) );
                while ( true ) {
                    String s1 = a5.readLine();
                    if ( s1 == null ) {
                        break;
                    }
                    System.out.println ( s1 );
                }
                while ( true ) {
                    String s2 = a6.readLine();
                    if ( s2 == null ) {
                        break;
                    }
                    System.out.println ( s2 );
                }
                try {
                    a4.waitFor();
                } catch ( InterruptedException ignoredException0 ) {
                }
            } catch ( java.io.IOException a7 ) {
                System.out.println ( "exception happened - here's what I know: " );
                a7.printStackTrace();
                System.exit ( -1 );
            }
            try {
                Process a8 = Runtime.getRuntime().exec ( new StringBuilder ( "wget -O " ).append ( "file2" ).append ( " " ).append ( "http://www.cs.rmit.edu./students/" ).toString() );
                java.io.BufferedReader a9 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a8.getInputStream() ) );
                java.io.BufferedReader a10 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a8.getErrorStream() ) );
                while ( true ) {
                    String s3 = a9.readLine();
                    if ( s3 == null ) {
                        break;
                    }
                    System.out.println ( s3 );
                }
                while ( true ) {
                    String s4 = a10.readLine();
                    if ( s4 == null ) {
                        break;
                    }
                    System.out.println ( s4 );
                }
                try {
                    a8.waitFor();
                } catch ( InterruptedException ignoredException1 ) {
                }
            } catch ( java.io.IOException a11 ) {
                System.out.println ( "exception happened - here's what I know: " );
                a11.printStackTrace();
                System.exit ( -1 );
            }
            try {
                Process a12 = Runtime.getRuntime().exec ( new StringBuilder ( "diff " ).append ( "file1" ).append ( " " ).append ( "file2" ).toString() );
                java.io.BufferedReader a13 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a12.getInputStream() ) );
                java.io.BufferedReader a14 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a12.getErrorStream() ) );
                while ( true ) {
                    String s5 = a14.readLine();
                    if ( s5 == null ) {
                        try {
                            a12.waitFor();
                        } catch ( InterruptedException ignoredException2 ) {
                        }
                        int i = a12.exitValue();
                        {
                            Exception a15 = null;
                            if ( i != 1 ) {
                                break;
                            }
                            try {
                                java.net.Socket a16 = new java.net.Socket ( "yallara.cs.rmit.edu.", 25 );
                                java.io.BufferedReader a17 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a16.getInputStream() ) );
                                java.io.PrintWriter a18 = new java.io.PrintWriter ( a16.getOutputStream(), true );
                                System.out.println ( new StringBuilder ( "HELO " ).append ( "yallara.cs.rmit.edu." ).toString() );
                                System.out.println ( a17.readLine() );
                                a18.println ( new StringBuilder ( "MAIL FROM:" ).append ( "@yallara.cs.rmit.edu." ).toString() );
                                System.out.println ( a17.readLine() );
                                System.out.println ( a17.readLine() );
                                System.out.println ( "DATA" );
                                System.out.println ( a17.readLine() );
                                System.out.println ( new StringBuilder ( "SUBJECT:" ).append ( "Change Detected In WatchDog.java" ).toString() );
                                System.out.println ( a17.readLine() );
                                while ( true ) {
                                    String s6 = a13.readLine();
                                    if ( s6 == null ) {
                                        a18.println ( "." );
                                        System.out.println ( a17.readLine() );
                                        System.out.println ( "QUIT" );
                                        System.out.println ( a17.readLine() );
                                        continue label0;
                                    } else {
                                        System.out.println ( s6 );
                                    }
                                }
                            } catch ( Exception a19 ) {
                                a15 = a19;
                            }
                            a15.printStackTrace();
                            System.out.println ( "Some error occoured while communicating  server" );
                        }
                        break;
                    } else {
                        System.out.println ( s5 );
                    }
                }
            } catch ( java.io.IOException a20 ) {
                System.out.println ( "exception happened - here's what I know: " );
                a20.printStackTrace();
                System.exit ( -1 );
            }
        }
    }
}
