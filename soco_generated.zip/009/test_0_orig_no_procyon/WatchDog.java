import java.io.PrintWriter;
import java.net.Socket;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class WatchDog {
    public static void main ( final String[] array ) {
        final String s = "http://www.cs.rmit.edu./students/";
        final String s2 = "file1";
        final String s3 = "file2";
        try {
            final Process exec = Runtime.getRuntime().exec ( "wget -O " + s2 + " " + s );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( exec.getInputStream() ) );
            final BufferedReader bufferedReader2 = new BufferedReader ( new InputStreamReader ( exec.getErrorStream() ) );
            String line;
            while ( ( line = bufferedReader.readLine() ) != null ) {
                System.out.println ( line );
            }
            String line2;
            while ( ( line2 = bufferedReader2.readLine() ) != null ) {
                System.out.println ( line2 );
            }
            try {
                exec.waitFor();
            } catch ( InterruptedException ex6 ) {}
        } catch ( IOException ex ) {
            System.out.println ( "exception happened - here's what I know: " );
            ex.printStackTrace();
            System.exit ( -1 );
        }
        while ( true ) {
            try {
                final Process exec2 = Runtime.getRuntime().exec ( "sleep 86400" );
                final BufferedReader bufferedReader3 = new BufferedReader ( new InputStreamReader ( exec2.getInputStream() ) );
                final BufferedReader bufferedReader4 = new BufferedReader ( new InputStreamReader ( exec2.getErrorStream() ) );
                String line3;
                while ( ( line3 = bufferedReader3.readLine() ) != null ) {
                    System.out.println ( line3 );
                }
                String line4;
                while ( ( line4 = bufferedReader4.readLine() ) != null ) {
                    System.out.println ( line4 );
                }
                try {
                    exec2.waitFor();
                } catch ( InterruptedException ex7 ) {}
            } catch ( IOException ex2 ) {
                System.out.println ( "exception happened - here's what I know: " );
                ex2.printStackTrace();
                System.exit ( -1 );
            }
            try {
                final Process exec3 = Runtime.getRuntime().exec ( "wget -O " + s3 + " " + s );
                final BufferedReader bufferedReader5 = new BufferedReader ( new InputStreamReader ( exec3.getInputStream() ) );
                final BufferedReader bufferedReader6 = new BufferedReader ( new InputStreamReader ( exec3.getErrorStream() ) );
                String line5;
                while ( ( line5 = bufferedReader5.readLine() ) != null ) {
                    System.out.println ( line5 );
                }
                String line6;
                while ( ( line6 = bufferedReader6.readLine() ) != null ) {
                    System.out.println ( line6 );
                }
                try {
                    exec3.waitFor();
                } catch ( InterruptedException ex8 ) {}
            } catch ( IOException ex3 ) {
                System.out.println ( "exception happened - here's what I know: " );
                ex3.printStackTrace();
                System.exit ( -1 );
            }
            try {
                final Process exec4 = Runtime.getRuntime().exec ( "diff " + s2 + " " + s3 );
                final BufferedReader bufferedReader7 = new BufferedReader ( new InputStreamReader ( exec4.getInputStream() ) );
                String line7;
                while ( ( line7 = new BufferedReader ( new InputStreamReader ( exec4.getErrorStream() ) ).readLine() ) != null ) {
                    System.out.println ( line7 );
                }
                try {
                    exec4.waitFor();
                } catch ( InterruptedException ex9 ) {}
                if ( exec4.exitValue() != 1 ) {
                    continue;
                }
                final String s4 = "yallara.cs.rmit.edu.";
                final String s5 = "yallara.cs.rmit.edu.";
                final String s6 = "@yallara.cs.rmit.edu.";
                final String s7 = "Change Detected In WatchDog.java";
                try {
                    final Socket socket = new Socket ( s4, 25 );
                    final BufferedReader bufferedReader8 = new BufferedReader ( new InputStreamReader ( socket.getInputStream() ) );
                    final PrintWriter printWriter = new PrintWriter ( socket.getOutputStream(), true );
                    System.out.println ( "HELO " + s5 );
                    System.out.println ( bufferedReader8.readLine() );
                    printWriter.println ( "MAIL FROM:" + s6 );
                    System.out.println ( bufferedReader8.readLine() );
                    System.out.println ( bufferedReader8.readLine() );
                    System.out.println ( "DATA" );
                    System.out.println ( bufferedReader8.readLine() );
                    System.out.println ( "SUBJECT:" + s7 );
                    System.out.println ( bufferedReader8.readLine() );
                    String line8;
                    while ( ( line8 = bufferedReader7.readLine() ) != null ) {
                        System.out.println ( line8 );
                    }
                    printWriter.println ( "." );
                    System.out.println ( bufferedReader8.readLine() );
                    System.out.println ( "QUIT" );
                    System.out.println ( bufferedReader8.readLine() );
                } catch ( Exception ex4 ) {
                    ex4.printStackTrace();
                    System.out.println ( "Some error occoured while communicating  server" );
                }
            } catch ( IOException ex5 ) {
                System.out.println ( "exception happened - here's what I know: " );
                ex5.printStackTrace();
                System.exit ( -1 );
            }
        }
    }
}
