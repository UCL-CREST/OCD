import java.util.*;
import java.text.*;
import java.io.*;
import java.*;
import java.net.*;
public class WatchDog {
    public static void main ( String v0[] ) {
        String v1;
        v1 = null;
        String v2;
        v2 = "http://www.cs.rmit.edu./students/";
        String v3;
        v3 = "file1";
        String v4;
        v4 = "file2";
        try {
            Process v5;
            v5 = Runtime.getRuntime().exec ( "wget -O " + v3 + " " + v2 );
            BufferedReader v6;
            v6 = new BufferedReader ( new InputStreamReader (
                                          v5.getInputStream() ) );
            BufferedReader v7;
            v7 = new BufferedReader ( new InputStreamReader (
                                          v5.getErrorStream() ) );
            for ( ; ( v1 = v6.readLine() ) != null; ) {
                System.out.println ( v1 );
            }
            for ( ; ( v1 = v7.readLine() ) != null; ) {
                System.out.println ( v1 );
            }
            try {
                v5.waitFor();
            } catch ( InterruptedException v8 ) {
            }
        } catch ( IOException v9 ) {
            System.out.println ( "exception happened - here's what I know: " );
            v9.printStackTrace();
            System.exit ( -1 );
        }
        for ( ; true; ) {
            try {
                Process v10;
                v10 = Runtime.getRuntime().exec ( "sleep 86400" );
                BufferedReader v11;
                v11 = new BufferedReader ( new InputStreamReader (
                                               v10.getInputStream() ) );
                BufferedReader v12;
                v12 = new BufferedReader ( new InputStreamReader (
                                               v10.getErrorStream() ) );
                for ( ; ( v1 = v11.readLine() ) != null; ) {
                    System.out.println ( v1 );
                }
                for ( ; ( v1 = v12.readLine() ) != null; ) {
                    System.out.println ( v1 );
                }
                try {
                    v10.waitFor();
                } catch ( InterruptedException v13 ) {
                }
            } catch ( IOException v14 ) {
                System.out.println ( "exception happened - here's what I know: " );
                v14.printStackTrace();
                System.exit ( -1 );
            }
            try {
                Process v15;
                v15 = Runtime.getRuntime().exec ( "wget -O " + v4 + " " + v2 );
                BufferedReader v16;
                v16 = new BufferedReader ( new InputStreamReader (
                                               v15.getInputStream() ) );
                BufferedReader v17;
                v17 = new BufferedReader ( new InputStreamReader (
                                               v15.getErrorStream() ) );
                for ( ; ( v1 = v16.readLine() ) != null; ) {
                    System.out.println ( v1 );
                }
                for ( ; ( v1 = v17.readLine() ) != null; ) {
                    System.out.println ( v1 );
                }
                try {
                    v15.waitFor();
                } catch ( InterruptedException v18 ) {
                }
            } catch ( IOException v19 ) {
                System.out.println ( "exception happened - here's what I know: " );
                v19.printStackTrace();
                System.exit ( -1 );
            }
            try {
                Process v20;
                v20 = Runtime.getRuntime().exec ( "diff " + v3 + " " + v4 );
                BufferedReader v21;
                v21 = new BufferedReader ( new InputStreamReader (
                                               v20.getInputStream() ) );
                BufferedReader v22;
                v22 = new BufferedReader ( new InputStreamReader (
                                               v20.getErrorStream() ) );
                for ( ; ( v1 = v22.readLine() ) != null; ) {
                    System.out.println ( v1 );
                }
                try {
                    v20.waitFor();
                } catch ( InterruptedException v23 ) {
                }
                if ( ( v20.exitValue() ) == 1 ) {
                    String v24;
                    v24 = "yallara.cs.rmit.edu.";
                    String v25;
                    v25 = "yallara.cs.rmit.edu.";
                    String v26;
                    v26 = "@yallara.cs.rmit.edu.";
                    String v27;
                    v27 = "Change Detected In WatchDog.java";
                    try {
                        Socket v28;
                        v28 = new Socket ( v24, 25 );
                        BufferedReader v29;
                        v29 = new BufferedReader ( new InputStreamReader (
                                                       v28.getInputStream() ) );
                        PrintWriter v30;
                        v30 = new PrintWriter ( v28.getOutputStream(), true );
                        System.out.println ( "HELO " + v25 );
                        System.out.println ( v29.readLine() );
                        v30.println ( "MAIL FROM:" + v26 );
                        System.out.println ( v29.readLine() );
                        System.out.println ( v29.readLine() );
                        System.out.println ( "DATA" );
                        System.out.println ( v29.readLine() );
                        System.out.println ( "SUBJECT:" + v27 );
                        System.out.println ( v29.readLine() );
                        for ( ; ( v1 = v21.readLine() ) != null; ) {
                            System.out.println ( v1 );
                        }
                        v30.println ( "." );
                        System.out.println ( v29.readLine() );
                        System.out.println ( "QUIT" );
                        System.out.println ( v29.readLine() );
                    } catch ( Exception v31 ) {
                        v31.printStackTrace();
                        System.out
                        .println ( "Some error occoured while communicating  server" );
                    }
                }
            } catch ( IOException v32 ) {
                System.out.println ( "exception happened - here's what I know: " );
                v32.printStackTrace();
                System.exit ( -1 );
            }
        }
    }
}
