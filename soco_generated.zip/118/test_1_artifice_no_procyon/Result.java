import java.util.Date;
public class Result {
    private String f00;
    private String f10;
    private String f20;
    private Date f30;
    private Date f40;
    private int f50;
    public Result ( final String f00, final String f, final String f2, final Date f3, final Date f4, final int f5 ) {
        this.f00 = f00;
        this.f10 = f;
        this.f20 = f2;
        this.f30 = f3;
        this.f40 = f4;
        this.f50 = f5;
    }
    @Override
    public String toString() {
        return "******************************\n" + "Password successfully cracked!\n\n" + "URL: " + this.f00 + "\n" + "Username: " + this.f10 + "\n" + "Password: " + this.f20 + "\n" + " Time: " + this.f30.toString() + "\n" + "End Time: " + this.f40.toString() + "\n" + " Attempts: " + this.f50 + "\n" + "******************************\n";
    }
}
