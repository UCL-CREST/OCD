public class Result {
    private String strURL;
    private String strUsername;
    private String strPassword;
    private java.util.Date dtTimeStart;
    private java.util.Date dtTimeEnd;
    private int iAttempts;
    public Result ( String s, String s0, String s1, java.util.Date a, java.util.Date a0, int i ) {
        super();
        this.strURL = s;
        this.strUsername = s0;
        this.strPassword = s1;
        this.dtTimeStart = a;
        this.dtTimeEnd = a0;
        this.iAttempts = i;
    }
    public String toString() {
        String s = new StringBuilder().append ( "******************************\n" ).append ( "Password successfully cracked!\n\n" ).toString();
        String s0 = new StringBuilder().append ( s ).append ( "URL: " ).append ( this.strURL ).append ( "\n" ).toString();
        String s1 = new StringBuilder().append ( s0 ).append ( "Username: " ).append ( this.strUsername ).append ( "\n" ).toString();
        String s2 = new StringBuilder().append ( s1 ).append ( "Password: " ).append ( this.strPassword ).append ( "\n" ).toString();
        String s3 = new StringBuilder().append ( s2 ).append ( " Time: " ).append ( this.dtTimeStart.toString() ).append ( "\n" ).toString();
        String s4 = new StringBuilder().append ( s3 ).append ( "End Time: " ).append ( this.dtTimeEnd.toString() ).append ( "\n" ).toString();
        String s5 = new StringBuilder().append ( s4 ).append ( " Attempts: " ).append ( this.iAttempts ).append ( "\n" ).toString();
        return new StringBuilder().append ( s5 ).append ( "******************************\n" ).toString();
    }
}
