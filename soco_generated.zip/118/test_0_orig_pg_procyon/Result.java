import java.util.Date;
public class Result {
    @Override
    public String toString() {
        return "******************************\n" + "Password successfully cracked!\n\n" + "URL: " + ( String ) null + "\n" + "Username: " + ( String ) null + "\n" + "Password: " + ( String ) null + "\n" + " Time: " + null.toString() + "\n" + "End Time: " + null.toString() + "\n" + " Attempts: 0" + "\n" + "******************************\n";
    }
}
