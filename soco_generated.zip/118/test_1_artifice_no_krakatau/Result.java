public class Result {
    private String f00;
    private String f10;
    private String f20;
    private java.util.Date f30;
    private java.util.Date f40;
    private int f50;
    public Result ( String s, String s0, String s1, java.util.Date a, java.util.Date a0, int i ) {
        super();
        this.f00 = s;
        this.f10 = s0;
        this.f20 = s1;
        this.f30 = a;
        this.f40 = a0;
        this.f50 = i;
    }
    public String toString() {
        String s = new StringBuilder().append ( "******************************\n" ).append ( "Password successfully cracked!\n\n" ).toString();
        String s0 = new StringBuilder().append ( s ).append ( "URL: " ).append ( this.f00 ).append ( "\n" ).toString();
        String s1 = new StringBuilder().append ( s0 ).append ( "Username: " ).append ( this.f10 ).append ( "\n" ).toString();
        String s2 = new StringBuilder().append ( s1 ).append ( "Password: " ).append ( this.f20 ).append ( "\n" ).toString();
        String s3 = new StringBuilder().append ( s2 ).append ( " Time: " ).append ( this.f30.toString() ).append ( "\n" ).toString();
        String s4 = new StringBuilder().append ( s3 ).append ( "End Time: " ).append ( this.f40.toString() ).append ( "\n" ).toString();
        String s5 = new StringBuilder().append ( s4 ).append ( " Attempts: " ).append ( this.f50 ).append ( "\n" ).toString();
        return new StringBuilder().append ( s5 ).append ( "******************************\n" ).toString();
    }
}
