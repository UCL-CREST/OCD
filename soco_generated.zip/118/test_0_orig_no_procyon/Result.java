import java.util.Date;
public class Result {
    private String strURL;
    private String strUsername;
    private String strPassword;
    private Date dtTimeStart;
    private Date dtTimeEnd;
    private int iAttempts;
    public Result ( final String strURL, final String strUsername, final String strPassword, final Date dtTimeStart, final Date dtTimeEnd, final int iAttempts ) {
        this.strURL = strURL;
        this.strUsername = strUsername;
        this.strPassword = strPassword;
        this.dtTimeStart = dtTimeStart;
        this.dtTimeEnd = dtTimeEnd;
        this.iAttempts = iAttempts;
    }
    @Override
    public String toString() {
        return "******************************\n" + "Password successfully cracked!\n\n" + "URL: " + this.strURL + "\n" + "Username: " + this.strUsername + "\n" + "Password: " + this.strPassword + "\n" + " Time: " + this.dtTimeStart.toString() + "\n" + "End Time: " + this.dtTimeEnd.toString() + "\n" + " Attempts: " + this.iAttempts + "\n" + "******************************\n";
    }
}
