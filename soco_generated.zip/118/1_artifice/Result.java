import java.util.*;
import java.io.*;
public class Result {
    private String f00;
    private String f10;
    private String f20;
    private Date f30;
    private Date f40;
    private int f50;
    public Result ( String v0, String v1, String v2, Date v3, Date v4, int v5 ) {
        f00 = v0;
        f10 = v1;
        f20 = v2;
        f30 = v3;
        f40 = v4;
        f50 = v5;
    }
    public String toString() {
        String v6;
        v6 = "******************************\n";
        v6 = v6 + ( "Password successfully cracked!\n\n" );
        v6 = v6 + ( "URL: " + f00 + "\n" );
        v6 = v6 + ( "Username: " + f10 + "\n" );
        v6 = v6 + ( "Password: " + f20 + "\n" );
        v6 = v6 + ( " Time: " + f30.toString() + "\n" );
        v6 = v6 + ( "End Time: " + f40.toString() + "\n" );
        v6 = v6 + ( " Attempts: " + f50 + "\n" );
        v6 = v6 + ( "******************************\n" );
        return v6;
    }
}
