public class Result {
    public String toString() {
        String s = new StringBuilder().append ( "******************************\n" ).append ( "Password successfully cracked!\n\n" ).toString();
        String s0 = new StringBuilder().append ( s ).append ( "URL: " ).append ( ( String ) null ).append ( "\n" ).toString();
        String s1 = new StringBuilder().append ( s0 ).append ( "Username: " ).append ( ( String ) null ).append ( "\n" ).toString();
        String s2 = new StringBuilder().append ( s1 ).append ( "Password: " ).append ( ( String ) null ).append ( "\n" ).toString();
        String s3 = new StringBuilder().append ( s2 ).append ( " Time: " ).append ( ( ( java.util.Date ) null ).toString() ).append ( "\n" ).toString();
        String s4 = new StringBuilder().append ( s3 ).append ( "End Time: " ).append ( ( ( java.util.Date ) null ).toString() ).append ( "\n" ).toString();
        String s5 = new StringBuilder().append ( s4 ).append ( " Attempts: 0" ).append ( "\n" ).toString();
        return new StringBuilder().append ( s5 ).append ( "******************************\n" ).toString();
    }
}
