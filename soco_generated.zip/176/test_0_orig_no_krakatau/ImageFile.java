public class ImageFile {
    private String imageUrl;
    private int imageSize;
    public ImageFile ( String s, int i ) {
        super();
        this.imageUrl = s;
        this.imageSize = i;
    }
    public String getImageUrl() {
        return this.imageUrl;
    }
    public int getImageSize() {
        return this.imageSize;
    }
}
