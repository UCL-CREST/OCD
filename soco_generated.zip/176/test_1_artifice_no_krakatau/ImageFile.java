public class ImageFile {
    private String f00;
    private int f10;
    public ImageFile ( String s, int i ) {
        super();
        this.f00 = s;
        this.f10 = i;
    }
    public String m00() {
        return this.f00;
    }
    public int m10() {
        return this.f10;
    }
}
