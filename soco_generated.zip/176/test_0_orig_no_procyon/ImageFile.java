public class ImageFile {
    private String imageUrl;
    private int imageSize;
    public ImageFile ( final String imageUrl, final int imageSize ) {
        this.imageUrl = imageUrl;
        this.imageSize = imageSize;
    }
    public String getImageUrl() {
        return this.imageUrl;
    }
    public int getImageSize() {
        return this.imageSize;
    }
}
