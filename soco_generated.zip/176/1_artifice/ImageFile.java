public class ImageFile {
    private String f00;
    private int f10;
    public ImageFile ( String v0, int v1 ) {
        f00 = v0;
        f10 = v1;
    }
    public String m00() {
        return f00;
    }
    public int m10() {
        return f10;
    }
}
