public class ImageFile {
    private String f00;
    private int f10;
    public ImageFile ( final String f00, final int f ) {
        this.f00 = f00;
        this.f10 = f;
    }
    public String m00() {
        return this.f00;
    }
    public int m10() {
        return this.f10;
    }
}
