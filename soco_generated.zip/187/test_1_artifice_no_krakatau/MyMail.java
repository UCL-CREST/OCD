public class MyMail implements java.io.Serializable {
    final public static int f00 = 25;
    final public static char f10 = ( char ) 50;
    final public static char f20 = ( char ) 51;
    final public static char f30 = ( char ) 52;
    final private static String f40 = "\r\n";
    private String f50;
    private String f60;
    private String f70;
    private String f80;
    private String f90;
    public MyMail() {
        super();
        this.f50 = "";
        this.f60 = "";
        this.f70 = "";
        this.f80 = "";
        this.f90 = "";
    }
    public MyMail ( String s ) {
        super();
        this.f50 = "";
        this.f60 = "";
        this.f70 = "";
        this.f80 = "";
        this.f90 = "";
        this.f90 = s;
    }
    public String m00() {
        return this.f50;
    }
    public String m10() {
        return this.f60;
    }
    public String m20() {
        return this.f70;
    }
    public String m30() {
        return this.f80;
    }
    public String m40() {
        return this.f90;
    }
    public void m50 ( String s ) {
        this.f50 = s;
    }
    public void m60 ( String s ) {
        this.f60 = s;
    }
    public void m70 ( String s ) {
        this.f70 = s;
    }
    public void m80 ( String s ) {
        this.f80 = s;
    }
    public void m90 ( String s ) {
        this.f90 = s;
    }
    private boolean m100 ( String s ) {
        if ( s.indexOf ( " " ) == -1 ) {
            return false;
        }
        String s0 = s.substring ( 0, s.indexOf ( " " ) ).toUpperCase();
        int i = s0.charAt ( 0 );
        if ( i != 50 ) {
            int i0 = s0.charAt ( 0 );
            if ( i0 != 51 ) {
                return false;
            }
        }
        return true;
    }
    public void m110() {
        String s = this.f90;
        try {
            java.net.Socket a = new java.net.Socket ( s, 25 );
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a.getInputStream() ) );
            java.io.PrintWriter a1 = new java.io.PrintWriter ( ( java.io.Writer ) new java.io.OutputStreamWriter ( a.getOutputStream() ) );
            System.out.println ( "1" );
            String s0 = a0.readLine();
            if ( !this.m100 ( s0 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s0 ).toString() );
            }
            try {
                String s1 = java.net.InetAddress.getLocalHost().getHostName();
                a1.print ( new StringBuilder().append ( "HELO " ).append ( s1 ).append ( "\r\n" ).toString() );
            } catch ( java.net.UnknownHostException ignoredException ) {
                a1.print ( "HELO myhostname\r\n" );
            }
            a1.flush();
            System.out.println ( "2" );
            String s2 = a0.readLine();
            if ( !this.m100 ( s2 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s2 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "MAIL From:<" ).append ( this.f50 ).append ( ">" ).toString() );
            a1.flush();
            System.out.println ( "3" );
            String s3 = a0.readLine();
            if ( !this.m100 ( s3 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s3 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "RCPT :<" ).append ( this.f60 ).append ( ">" ).toString() );
            a1.flush();
            System.out.println ( "4" );
            String s4 = a0.readLine();
            if ( !this.m100 ( s4 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s4 ).toString() );
            }
            a1.println ( "DATA" );
            a1.flush();
            System.out.println ( "5" );
            String s5 = a0.readLine();
            if ( !this.m100 ( s5 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s5 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "From: " ).append ( this.f50 ).toString() );
            a1.println ( new StringBuilder().append ( ": " ).append ( this.f60 ).toString() );
            a1.println ( new StringBuilder().append ( "Subject: " ).append ( this.f70 ).toString() );
            a1.println();
            a1.println ( this.f80 );
            a1.println ( ".\n\r" );
            a1.flush();
            System.out.println ( "6" );
            String s6 = a0.readLine();
            if ( !this.m100 ( s6 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s6 ).toString() );
            }
            a1.println ( "QUIT" );
            a1.flush();
            a.close();
        } catch ( java.io.IOException a2 ) {
            System.out.println ( a2.getMessage() );
        }
    }
}
