import java.net.UnknownHostException;
import java.net.InetAddress;
import java.io.IOException;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.Serializable;
public class MyMail implements Serializable {
    public static final int f00 = 25;
    public static final char f10 = '2';
    public static final char f20 = '3';
    public static final char f30 = '4';
    private static final String f40 = "\r\n";
    private String f50;
    private String f60;
    private String f70;
    private String f80;
    private String f90;
    public MyMail() {
        this.f50 = "";
        this.f60 = "";
        this.f70 = "";
        this.f80 = "";
        this.f90 = "";
    }
    public MyMail ( final String f90 ) {
        this.f50 = "";
        this.f60 = "";
        this.f70 = "";
        this.f80 = "";
        this.f90 = "";
        this.f90 = f90;
    }
    public String m00() {
        return this.f50;
    }
    public String m10() {
        return this.f60;
    }
    public String m20() {
        return this.f70;
    }
    public String m30() {
        return this.f80;
    }
    public String m40() {
        return this.f90;
    }
    public void m50 ( final String f50 ) {
        this.f50 = f50;
    }
    public void m60 ( final String f60 ) {
        this.f60 = f60;
    }
    public void m70 ( final String f70 ) {
        this.f70 = f70;
    }
    public void m80 ( final String f80 ) {
        this.f80 = f80;
    }
    public void m90 ( final String f90 ) {
        this.f90 = f90;
    }
    private boolean m100 ( final String s ) {
        if ( s.indexOf ( " " ) == -1 ) {
            return false;
        }
        final String upperCase = s.substring ( 0, s.indexOf ( " " ) ).toUpperCase();
        return upperCase.charAt ( 0 ) == '2' || upperCase.charAt ( 0 ) == '3';
    }
    public void m110() {
        try {
            final Socket socket = new Socket ( this.f90, 25 );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( socket.getInputStream() ) );
            final PrintWriter printWriter = new PrintWriter ( new OutputStreamWriter ( socket.getOutputStream() ) );
            System.out.println ( "1" );
            final String line = bufferedReader.readLine();
            if ( !this.m100 ( line ) ) {
                throw new IOException ( "ERR - " + line );
            }
            try {
                printWriter.print ( "HELO " + InetAddress.getLocalHost().getHostName() + "\r\n" );
            } catch ( UnknownHostException ex2 ) {
                printWriter.print ( "HELO myhostname\r\n" );
            }
            printWriter.flush();
            System.out.println ( "2" );
            final String line2 = bufferedReader.readLine();
            if ( !this.m100 ( line2 ) ) {
                throw new IOException ( "ERR - " + line2 );
            }
            printWriter.println ( "MAIL From:<" + this.f50 + ">" );
            printWriter.flush();
            System.out.println ( "3" );
            final String line3 = bufferedReader.readLine();
            if ( !this.m100 ( line3 ) ) {
                throw new IOException ( "ERR - " + line3 );
            }
            printWriter.println ( "RCPT :<" + this.f60 + ">" );
            printWriter.flush();
            System.out.println ( "4" );
            final String line4 = bufferedReader.readLine();
            if ( !this.m100 ( line4 ) ) {
                throw new IOException ( "ERR - " + line4 );
            }
            printWriter.println ( "DATA" );
            printWriter.flush();
            System.out.println ( "5" );
            final String line5 = bufferedReader.readLine();
            if ( !this.m100 ( line5 ) ) {
                throw new IOException ( "ERR - " + line5 );
            }
            printWriter.println ( "From: " + this.f50 );
            printWriter.println ( ": " + this.f60 );
            printWriter.println ( "Subject: " + this.f70 );
            printWriter.println();
            printWriter.println ( this.f80 );
            printWriter.println ( ".\n\r" );
            printWriter.flush();
            System.out.println ( "6" );
            final String line6 = bufferedReader.readLine();
            if ( !this.m100 ( line6 ) ) {
                throw new IOException ( "ERR - " + line6 );
            }
            printWriter.println ( "QUIT" );
            printWriter.flush();
            socket.close();
        } catch ( IOException ex ) {
            System.out.println ( ex.getMessage() );
        }
    }
}
