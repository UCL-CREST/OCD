import java.io.Serializable;
public class MyMail implements Serializable {
}
