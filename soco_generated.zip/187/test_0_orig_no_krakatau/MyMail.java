public class MyMail implements java.io.Serializable {
    final public static int SMTPPort = 25;
    final public static char successPrefix = ( char ) 50;
    final public static char morePrefix = ( char ) 51;
    final public static char failurePrefix = ( char ) 52;
    final private static String CRLF = "\r\n";
    private String mailFrom;
    private String mailTo;
    private String messageSubject;
    private String messageBody;
    private String mailServer;
    public MyMail() {
        super();
        this.mailFrom = "";
        this.mailTo = "";
        this.messageSubject = "";
        this.messageBody = "";
        this.mailServer = "";
    }
    public MyMail ( String s ) {
        super();
        this.mailFrom = "";
        this.mailTo = "";
        this.messageSubject = "";
        this.messageBody = "";
        this.mailServer = "";
        this.mailServer = s;
    }
    public String getFrom() {
        return this.mailFrom;
    }
    public String getTo() {
        return this.mailTo;
    }
    public String getSubject() {
        return this.messageSubject;
    }
    public String getMessage() {
        return this.messageBody;
    }
    public String getMailServer() {
        return this.mailServer;
    }
    public void setFrom ( String s ) {
        this.mailFrom = s;
    }
    public void setTo ( String s ) {
        this.mailTo = s;
    }
    public void setSubject ( String s ) {
        this.messageSubject = s;
    }
    public void setMessage ( String s ) {
        this.messageBody = s;
    }
    public void setMailServer ( String s ) {
        this.mailServer = s;
    }
    private boolean responseValid ( String s ) {
        if ( s.indexOf ( " " ) == -1 ) {
            return false;
        }
        String s0 = s.substring ( 0, s.indexOf ( " " ) ).toUpperCase();
        int i = s0.charAt ( 0 );
        if ( i != 50 ) {
            int i0 = s0.charAt ( 0 );
            if ( i0 != 51 ) {
                return false;
            }
        }
        return true;
    }
    public void sendMail() {
        String s = this.mailServer;
        try {
            java.net.Socket a = new java.net.Socket ( s, 25 );
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a.getInputStream() ) );
            java.io.PrintWriter a1 = new java.io.PrintWriter ( ( java.io.Writer ) new java.io.OutputStreamWriter ( a.getOutputStream() ) );
            System.out.println ( "1" );
            String s0 = a0.readLine();
            if ( !this.responseValid ( s0 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s0 ).toString() );
            }
            try {
                String s1 = java.net.InetAddress.getLocalHost().getHostName();
                a1.print ( new StringBuilder().append ( "HELO " ).append ( s1 ).append ( "\r\n" ).toString() );
            } catch ( java.net.UnknownHostException ignoredException ) {
                a1.print ( "HELO myhostname\r\n" );
            }
            a1.flush();
            System.out.println ( "2" );
            String s2 = a0.readLine();
            if ( !this.responseValid ( s2 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s2 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "MAIL From:<" ).append ( this.mailFrom ).append ( ">" ).toString() );
            a1.flush();
            System.out.println ( "3" );
            String s3 = a0.readLine();
            if ( !this.responseValid ( s3 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s3 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "RCPT :<" ).append ( this.mailTo ).append ( ">" ).toString() );
            a1.flush();
            System.out.println ( "4" );
            String s4 = a0.readLine();
            if ( !this.responseValid ( s4 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s4 ).toString() );
            }
            a1.println ( "DATA" );
            a1.flush();
            System.out.println ( "5" );
            String s5 = a0.readLine();
            if ( !this.responseValid ( s5 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s5 ).toString() );
            }
            a1.println ( new StringBuilder().append ( "From: " ).append ( this.mailFrom ).toString() );
            a1.println ( new StringBuilder().append ( ": " ).append ( this.mailTo ).toString() );
            a1.println ( new StringBuilder().append ( "Subject: " ).append ( this.messageSubject ).toString() );
            a1.println();
            a1.println ( this.messageBody );
            a1.println ( ".\n\r" );
            a1.flush();
            System.out.println ( "6" );
            String s6 = a0.readLine();
            if ( !this.responseValid ( s6 ) ) {
                throw new java.io.IOException ( new StringBuilder().append ( "ERR - " ).append ( s6 ).toString() );
            }
            a1.println ( "QUIT" );
            a1.flush();
            a.close();
        } catch ( java.io.IOException a2 ) {
            System.out.println ( a2.getMessage() );
        }
    }
}
