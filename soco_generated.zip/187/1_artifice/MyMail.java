import java.net.*;
import java.io.*;
import java.util.Date;
public class MyMail implements Serializable {
    public static final int f00 = 25;
    public static final char f10 = '2';
    public static final char f20 = '3';
    public static final char f30 = '4';
    private static final String f40 = "\r\n";
    private String f50 = "";
    private String f60 = "";
    private String f70 = "";
    private String f80 = "";
    private String f90 = "";
    public MyMail () {
        super();
    }
    public MyMail ( String v0 ) {
        super();
        f90 = v0;
    }
    public String m00() {
        return f50;
    }
    public String m10() {
        return f60;
    }
    public String m20() {
        return f70;
    }
    public String m30() {
        return f80;
    }
    public String m40() {
        return f90;
    }
    public void m50 ( String v1 ) {
        f50 = v1;
    }
    public void m60 ( String v2 ) {
        f60 = v2;
    }
    public void m70 ( String v3 ) {
        f70 = v3;
    }
    public void m80 ( String v4 ) {
        f80 = v4;
    }
    public void m90 ( String v5 ) {
        f90 = v5;
    }
    private boolean m100 ( String v6 ) {
        if ( v6.indexOf ( " " ) == -1 ) {
            return false;
        }
        String v7;
        v7 = v6.substring ( 0, v6.indexOf ( " " ) );
        v7 = v7.toUpperCase();
        if ( ( v7.charAt ( 0 ) == f10 ) ||
                ( v7.charAt ( 0 ) == f20 ) ) {
            return true;
        } else {
            return false;
        }
    }
    public void m110() {
        try {
            String v8;
            Socket v9;
            v9 = new Socket ( f90, f00 );
            BufferedReader v10;
            v10 = new BufferedReader ( new InputStreamReader ( v9.getInputStream() ) );
            PrintWriter v11;
            v11 = new PrintWriter ( new OutputStreamWriter ( v9.getOutputStream() ) );
            System.out.println ( "1" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            try {
                InetAddress v12;
                v12 = InetAddress.getLocalHost();
                String v13;
                v13 = v12.getHostName();
                v11.print ( "HELO " + v13 + f40 );
            } catch ( UnknownHostException v14 ) {
                v11.print ( "HELO myhostname"  + f40 );
            }
            v11.flush();
            System.out.println ( "2" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            v11.println ( "MAIL From:<" + f50 + ">" );
            v11.flush();
            System.out.println ( "3" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            v11.println ( "RCPT :<" + f60 + ">" );
            v11.flush();
            System.out.println ( "4" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            v11.println ( "DATA" );
            v11.flush();
            System.out.println ( "5" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            v11.println ( "From: " + f50 );
            v11.println ( ": " + f60 );
            v11.println ( "Subject: " + f70 );
            v11.println ();
            v11.println ( f80 );
            v11.println ( ".\n\r" );
            v11.flush();
            System.out.println ( "6" );
            v8 = v10.readLine();
            if ( !m100 ( v8 ) ) {
                throw new IOException ( "ERR - " + v8 );
            }
            v11.println ( "QUIT" );
            v11.flush();
            v9.close();
        } catch ( IOException v15 ) {
            System.out.println ( v15.getMessage() );
        }
    }
}
