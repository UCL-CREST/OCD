import java.net.UnknownHostException;
import java.net.InetAddress;
import java.io.IOException;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.Serializable;
public class MyMail implements Serializable {
    public static final int SMTPPort = 25;
    public static final char successPrefix = '2';
    public static final char morePrefix = '3';
    public static final char failurePrefix = '4';
    private static final String CRLF = "\r\n";
    private String mailFrom;
    private String mailTo;
    private String messageSubject;
    private String messageBody;
    private String mailServer;
    public MyMail() {
        this.mailFrom = "";
        this.mailTo = "";
        this.messageSubject = "";
        this.messageBody = "";
        this.mailServer = "";
    }
    public MyMail ( final String mailServer ) {
        this.mailFrom = "";
        this.mailTo = "";
        this.messageSubject = "";
        this.messageBody = "";
        this.mailServer = "";
        this.mailServer = mailServer;
    }
    public String getFrom() {
        return this.mailFrom;
    }
    public String getTo() {
        return this.mailTo;
    }
    public String getSubject() {
        return this.messageSubject;
    }
    public String getMessage() {
        return this.messageBody;
    }
    public String getMailServer() {
        return this.mailServer;
    }
    public void setFrom ( final String mailFrom ) {
        this.mailFrom = mailFrom;
    }
    public void setTo ( final String mailTo ) {
        this.mailTo = mailTo;
    }
    public void setSubject ( final String messageSubject ) {
        this.messageSubject = messageSubject;
    }
    public void setMessage ( final String messageBody ) {
        this.messageBody = messageBody;
    }
    public void setMailServer ( final String mailServer ) {
        this.mailServer = mailServer;
    }
    private boolean responseValid ( final String s ) {
        if ( s.indexOf ( " " ) == -1 ) {
            return false;
        }
        final String upperCase = s.substring ( 0, s.indexOf ( " " ) ).toUpperCase();
        return upperCase.charAt ( 0 ) == '2' || upperCase.charAt ( 0 ) == '3';
    }
    public void sendMail() {
        try {
            final Socket socket = new Socket ( this.mailServer, 25 );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( socket.getInputStream() ) );
            final PrintWriter printWriter = new PrintWriter ( new OutputStreamWriter ( socket.getOutputStream() ) );
            System.out.println ( "1" );
            final String line = bufferedReader.readLine();
            if ( !this.responseValid ( line ) ) {
                throw new IOException ( "ERR - " + line );
            }
            try {
                printWriter.print ( "HELO " + InetAddress.getLocalHost().getHostName() + "\r\n" );
            } catch ( UnknownHostException ex2 ) {
                printWriter.print ( "HELO myhostname\r\n" );
            }
            printWriter.flush();
            System.out.println ( "2" );
            final String line2 = bufferedReader.readLine();
            if ( !this.responseValid ( line2 ) ) {
                throw new IOException ( "ERR - " + line2 );
            }
            printWriter.println ( "MAIL From:<" + this.mailFrom + ">" );
            printWriter.flush();
            System.out.println ( "3" );
            final String line3 = bufferedReader.readLine();
            if ( !this.responseValid ( line3 ) ) {
                throw new IOException ( "ERR - " + line3 );
            }
            printWriter.println ( "RCPT :<" + this.mailTo + ">" );
            printWriter.flush();
            System.out.println ( "4" );
            final String line4 = bufferedReader.readLine();
            if ( !this.responseValid ( line4 ) ) {
                throw new IOException ( "ERR - " + line4 );
            }
            printWriter.println ( "DATA" );
            printWriter.flush();
            System.out.println ( "5" );
            final String line5 = bufferedReader.readLine();
            if ( !this.responseValid ( line5 ) ) {
                throw new IOException ( "ERR - " + line5 );
            }
            printWriter.println ( "From: " + this.mailFrom );
            printWriter.println ( ": " + this.mailTo );
            printWriter.println ( "Subject: " + this.messageSubject );
            printWriter.println();
            printWriter.println ( this.messageBody );
            printWriter.println ( ".\n\r" );
            printWriter.flush();
            System.out.println ( "6" );
            final String line6 = bufferedReader.readLine();
            if ( !this.responseValid ( line6 ) ) {
                throw new IOException ( "ERR - " + line6 );
            }
            printWriter.println ( "QUIT" );
            printWriter.flush();
            socket.close();
        } catch ( IOException ex ) {
            System.out.println ( ex.getMessage() );
        }
    }
}
