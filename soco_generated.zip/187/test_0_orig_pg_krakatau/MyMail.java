public class MyMail implements java.io.Serializable {
    public MyMail() {
        super();
    }
}
