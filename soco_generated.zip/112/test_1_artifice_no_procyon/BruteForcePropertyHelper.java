import java.util.Properties;
public class BruteForcePropertyHelper {
    private static Properties f00;
    public static String m00 ( final String s ) {
        try {
            m10();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the burteforce Props" );
            ex.printStackTrace();
        }
        return BruteForcePropertyHelper.f00.getProperty ( s );
    }
    private static void m10() throws Exception {
        if ( BruteForcePropertyHelper.f00 == null ) {
            ( BruteForcePropertyHelper.f00 = new Properties() ).load ( BruteForcePropertyHelper.class.getResourceAsStream ( "/bruteforce.properties" ) );
        }
    }
}
