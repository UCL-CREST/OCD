public class BruteForcePropertyHelper {
    private static java.util.Properties f00;
    public BruteForcePropertyHelper() {
        super();
    }
    public static String m00 ( String s ) {
        try {
            BruteForcePropertyHelper.m10();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the burteforce Props" );
            a.printStackTrace();
        }
        return f00.getProperty ( s );
    }
    private static void m10() {
        if ( f00 == null ) {
            f00 = new java.util.Properties();
            java.io.InputStream a = BruteForcePropertyHelper.class.getResourceAsStream ( "/bruteforce.properties" );
            f00.load ( a );
        }
    }
}
