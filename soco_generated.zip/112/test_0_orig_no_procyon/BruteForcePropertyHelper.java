import java.util.Properties;
public class BruteForcePropertyHelper {
    private static Properties bruteForceProps;
    public static String getProperty ( final String s ) {
        try {
            initProps();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the burteforce Props" );
            ex.printStackTrace();
        }
        return BruteForcePropertyHelper.bruteForceProps.getProperty ( s );
    }
    private static void initProps() throws Exception {
        if ( BruteForcePropertyHelper.bruteForceProps == null ) {
            ( BruteForcePropertyHelper.bruteForceProps = new Properties() ).load ( BruteForcePropertyHelper.class.getResourceAsStream ( "/bruteforce.properties" ) );
        }
    }
}
