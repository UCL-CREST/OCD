public class BruteForcePropertyHelper {
    private static java.util.Properties bruteForceProps;
    public BruteForcePropertyHelper() {
        super();
    }
    public static String getProperty ( String s ) {
        try {
            BruteForcePropertyHelper.initProps();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the burteforce Props" );
            a.printStackTrace();
        }
        return bruteForceProps.getProperty ( s );
    }
    private static void initProps() {
        if ( bruteForceProps == null ) {
            bruteForceProps = new java.util.Properties();
            java.io.InputStream a = BruteForcePropertyHelper.class.getResourceAsStream ( "/bruteforce.properties" );
            bruteForceProps.load ( a );
        }
    }
}
