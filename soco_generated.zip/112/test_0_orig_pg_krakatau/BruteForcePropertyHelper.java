public class BruteForcePropertyHelper {
    public BruteForcePropertyHelper() {
        super();
    }
}
