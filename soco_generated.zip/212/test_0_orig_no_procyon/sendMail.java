import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
public class sendMail {
    public void sendMail ( final String s, final String s2, final String s3 ) {
        try {
            final Socket socket = new Socket ( s, 25 );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( socket.getInputStream(), "8859_1" ) );
            final BufferedWriter bufferedWriter = new BufferedWriter ( new OutputStreamWriter ( socket.getOutputStream(), "8859_1" ) );
            this.send ( bufferedReader, bufferedWriter, "HELO client" );
            this.send ( bufferedReader, bufferedWriter, "MAIL FROM: <WatchDog@SecureECommerce.>" );
            this.send ( bufferedReader, bufferedWriter, "RCPT : " + s2 );
            this.send ( bufferedReader, bufferedWriter, "DATA" );
            this.send ( bufferedWriter, "Subject: " );
            this.send ( bufferedWriter, "From: Admin <WatchDog@SecureECommerce.>" );
            this.send ( bufferedWriter, "\n" );
            this.send ( bufferedWriter, s3 );
            this.send ( bufferedWriter, "\n.\n" );
            this.send ( bufferedReader, bufferedWriter, "QUIT" );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
    public void send ( final BufferedReader bufferedReader, final BufferedWriter bufferedWriter, String line ) {
        try {
            bufferedWriter.write ( line + "\n" );
            bufferedWriter.flush();
            System.out.println ( line );
            line = bufferedReader.readLine();
            System.out.println ( line );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
    public void send ( final BufferedWriter bufferedWriter, final String s ) {
        try {
            bufferedWriter.write ( s + "\n" );
            bufferedWriter.flush();
            System.out.println ( s );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
}
