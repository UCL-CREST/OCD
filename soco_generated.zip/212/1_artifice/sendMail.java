import java.net.*;
import java.io.*;
public class sendMail {
    public void m00 ( String v0, String v1, String v2 ) {
        try {
            Socket v3;
            v3 = new Socket ( v0, 25 );
            BufferedReader v4;
            v4 = new BufferedReader ( new InputStreamReader ( v3.getInputStream(),
                                      "8859_1" ) );
            BufferedWriter v5;
            v5 = new BufferedWriter ( new OutputStreamWriter (
                                          v3.getOutputStream(), "8859_1" ) );
            m10 ( v4, v5, "HELO client" );
            m10 ( v4, v5, "MAIL FROM: <WatchDog@SecureECommerce.>" );
            m10 ( v4, v5, "RCPT : " + v1 );
            m10 ( v4, v5, "DATA" );
            m20 ( v5, "Subject: " );
            m20 ( v5, "From: Admin <WatchDog@SecureECommerce.>" );
            m20 ( v5, "\n" );
            m20 ( v5, v2 );
            m20 ( v5, "\n.\n" );
            m10 ( v4, v5, "QUIT" );
        } catch ( Exception v6 ) {
            v6.printStackTrace();
        }
    }
    public void m10 ( BufferedReader v7, BufferedWriter v8, String v9 ) {
        try {
            v8.write ( v9 + "\n" );
            v8.flush();
            System.out.println ( v9 );
            v9 = v7.readLine();
            System.out.println ( v9 );
        } catch ( Exception v10 ) {
            v10.printStackTrace();
        }
    }
    public void m20 ( BufferedWriter v11, String v12 ) {
        try {
            v11.write ( v12 + "\n" );
            v11.flush();
            System.out.println ( v12 );
        } catch ( Exception v13 ) {
            v13.printStackTrace();
        }
    }
}
