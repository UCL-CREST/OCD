public class sendMail {
    public sendMail() {
        super();
    }
}
