public class sendMail {
    public sendMail() {
        super();
    }
    public void m00 ( String s, String s0, String s1 ) {
        try {
            java.net.Socket a = new java.net.Socket ( s, 25 );
            java.io.BufferedReader a0 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a.getInputStream(), "8859_1" ) );
            java.io.BufferedWriter a1 = new java.io.BufferedWriter ( ( java.io.Writer ) new java.io.OutputStreamWriter ( a.getOutputStream(), "8859_1" ) );
            this.m10 ( a0, a1, "HELO client" );
            this.m10 ( a0, a1, "MAIL FROM: <WatchDog@SecureECommerce.>" );
            this.m10 ( a0, a1, new StringBuilder().append ( "RCPT : " ).append ( s0 ).toString() );
            this.m10 ( a0, a1, "DATA" );
            this.m20 ( a1, "Subject: " );
            this.m20 ( a1, "From: Admin <WatchDog@SecureECommerce.>" );
            this.m20 ( a1, "\n" );
            this.m20 ( a1, s1 );
            this.m20 ( a1, "\n.\n" );
            this.m10 ( a0, a1, "QUIT" );
        } catch ( Exception a2 ) {
            a2.printStackTrace();
        }
    }
    public void m10 ( java.io.BufferedReader a, java.io.BufferedWriter a0, String s ) {
        try {
            a0.write ( new StringBuilder().append ( s ).append ( "\n" ).toString() );
            a0.flush();
            System.out.println ( s );
            String s0 = a.readLine();
            System.out.println ( s0 );
        } catch ( Exception a1 ) {
            a1.printStackTrace();
        }
    }
    public void m20 ( java.io.BufferedWriter a, String s ) {
        try {
            a.write ( new StringBuilder().append ( s ).append ( "\n" ).toString() );
            a.flush();
            System.out.println ( s );
        } catch ( Exception a0 ) {
            a0.printStackTrace();
        }
    }
}
