import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
public class sendMail {
    public void m00 ( final String s, final String s2, final String s3 ) {
        try {
            final Socket socket = new Socket ( s, 25 );
            final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( socket.getInputStream(), "8859_1" ) );
            final BufferedWriter bufferedWriter = new BufferedWriter ( new OutputStreamWriter ( socket.getOutputStream(), "8859_1" ) );
            this.m10 ( bufferedReader, bufferedWriter, "HELO client" );
            this.m10 ( bufferedReader, bufferedWriter, "MAIL FROM: <WatchDog@SecureECommerce.>" );
            this.m10 ( bufferedReader, bufferedWriter, "RCPT : " + s2 );
            this.m10 ( bufferedReader, bufferedWriter, "DATA" );
            this.m20 ( bufferedWriter, "Subject: " );
            this.m20 ( bufferedWriter, "From: Admin <WatchDog@SecureECommerce.>" );
            this.m20 ( bufferedWriter, "\n" );
            this.m20 ( bufferedWriter, s3 );
            this.m20 ( bufferedWriter, "\n.\n" );
            this.m10 ( bufferedReader, bufferedWriter, "QUIT" );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
    public void m10 ( final BufferedReader bufferedReader, final BufferedWriter bufferedWriter, String line ) {
        try {
            bufferedWriter.write ( line + "\n" );
            bufferedWriter.flush();
            System.out.println ( line );
            line = bufferedReader.readLine();
            System.out.println ( line );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
    public void m20 ( final BufferedWriter bufferedWriter, final String s ) {
        try {
            bufferedWriter.write ( s + "\n" );
            bufferedWriter.flush();
            System.out.println ( s );
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }
}
