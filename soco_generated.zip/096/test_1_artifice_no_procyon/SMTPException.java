public class SMTPException extends Exception {
    private String f00;
    public SMTPException ( final String f00 ) {
        this.f00 = f00;
    }
    @Override
    public String getMessage() {
        return this.f00;
    }
}
