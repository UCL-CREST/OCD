public class SMTPException extends Exception {
    private String f00;
    public SMTPException ( String v0 ) {
        f00 = v0;
    }
    public String getMessage() {
        return f00;
    }
}
