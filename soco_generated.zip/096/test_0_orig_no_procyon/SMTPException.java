public class SMTPException extends Exception {
    private String msg;
    public SMTPException ( final String msg ) {
        this.msg = msg;
    }
    @Override
    public String getMessage() {
        return this.msg;
    }
}
