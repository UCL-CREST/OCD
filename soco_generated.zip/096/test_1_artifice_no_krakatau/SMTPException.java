public class SMTPException extends Exception {
    private String f00;
    public SMTPException ( String s ) {
        super();
        this.f00 = s;
    }
    public String getMessage() {
        return this.f00;
    }
}
