public class SMTPException extends Exception {
    public String getMessage() {
        return null;
    }
}
