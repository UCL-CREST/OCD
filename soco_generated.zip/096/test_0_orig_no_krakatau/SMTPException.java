public class SMTPException extends Exception {
    private String msg;
    public SMTPException ( String s ) {
        super();
        this.msg = s;
    }
    public String getMessage() {
        return this.msg;
    }
}
