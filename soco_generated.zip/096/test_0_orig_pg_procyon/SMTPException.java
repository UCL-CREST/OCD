public class SMTPException extends Exception {
    @Override
    public String getMessage() {
        return null;
    }
}
