class WebPage {
    private boolean f00 = false;
    private String f10 = "";
    public WebPage() {
    }
    public void m00 ( boolean v0 ) {
        f00 = v0;
    }
    public boolean m10() {
        return f00;
    }
    public void m20 ( String v1 ) {
        f10 = v1;
    }
    public String m30() {
        return f10;
    }
}
