class WebPage {
}
