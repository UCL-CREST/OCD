class WebPage {
    private boolean f00;
    private String f10;
    public WebPage() {
        super();
        this.f00 = false;
        this.f10 = "";
    }
    public void m00 ( boolean b ) {
        this.f00 = b;
    }
    public boolean m10() {
        return this.f00;
    }
    public void m20 ( String s ) {
        this.f10 = s;
    }
    public String m30() {
        return this.f10;
    }
}
