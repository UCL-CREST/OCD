class WebPage {
    public WebPage() {
        super();
    }
}
