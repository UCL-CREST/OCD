class WebPage {
    private boolean success;
    private String pageContents;
    public WebPage() {
        this.success = false;
        this.pageContents = "";
    }
    public void setSuccess ( final boolean success ) {
        this.success = success;
    }
    public boolean getSuccess() {
        return this.success;
    }
    public void setPageContents ( final String pageContents ) {
        this.pageContents = pageContents;
    }
    public String getPageContents() {
        return this.pageContents;
    }
}
