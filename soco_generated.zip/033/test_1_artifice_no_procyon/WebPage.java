class WebPage {
    private boolean f00;
    private String f10;
    public WebPage() {
        this.f00 = false;
        this.f10 = "";
    }
    public void m00 ( final boolean f00 ) {
        this.f00 = f00;
    }
    public boolean m10() {
        return this.f00;
    }
    public void m20 ( final String f10 ) {
        this.f10 = f10;
    }
    public String m30() {
        return this.f10;
    }
}
