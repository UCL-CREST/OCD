class WebPage {
    private boolean success;
    private String pageContents;
    public WebPage() {
        super();
        this.success = false;
        this.pageContents = "";
    }
    public void setSuccess ( boolean b ) {
        this.success = b;
    }
    public boolean getSuccess() {
        return this.success;
    }
    public void setPageContents ( String s ) {
        this.pageContents = s;
    }
    public String getPageContents() {
        return this.pageContents;
    }
}
