public class PasswordFile {
    private String f00;
    private String f10;
    private java.io.File f20;
    private java.io.BufferedReader f30;
    public PasswordFile ( String s ) {
        super();
        this.f00 = s;
        try {
            this.f20 = new java.io.File ( this.f00 );
            this.f30 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( this.f20 ) );
        } catch ( Exception ignoredException ) {
            System.out.println ( new StringBuilder().append ( "Could not open file " ).append ( this.f00 ).toString() );
        }
    }
    String m00() {
        return this.f10;
    }
    String m10() {
        try {
            this.f10 = this.f30.readLine();
        } catch ( Exception ignoredException ) {
            String s = null;
            return s;
        }
        return this.f10;
    }
}
