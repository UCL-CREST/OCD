import java.io.*;
public class PasswordFile {
    private String f00;
    private String f10;
    private File f20;
    private BufferedReader f30;
    public PasswordFile ( String v0 ) {
        f00 = v0;
        try {
            f20 = new File ( f00 );
            f30 = new BufferedReader ( new FileReader ( f20 ) );
        } catch ( Exception v1 ) {
            System.out.println ( "Could not open file " + f00 );
        }
    }
    String m00() {
        return f10;
    }
    String m10() {
        try {
            f10 = f30.readLine();
        } catch ( Exception v2 ) {
            return null;
        }
        return f10;
    }
}
