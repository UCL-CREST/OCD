public class PasswordFile {
    private String strFilepath;
    private String strCurrWord;
    private java.io.File fWordFile;
    private java.io.BufferedReader in;
    public PasswordFile ( String s ) {
        super();
        this.strFilepath = s;
        try {
            this.fWordFile = new java.io.File ( this.strFilepath );
            this.in = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.FileReader ( this.fWordFile ) );
        } catch ( Exception ignoredException ) {
            System.out.println ( new StringBuilder().append ( "Could not open file " ).append ( this.strFilepath ).toString() );
        }
    }
    String getPassword() {
        return this.strCurrWord;
    }
    String getNextPassword() {
        try {
            this.strCurrWord = this.in.readLine();
        } catch ( Exception ignoredException ) {
            String s = null;
            return s;
        }
        return this.strCurrWord;
    }
}
