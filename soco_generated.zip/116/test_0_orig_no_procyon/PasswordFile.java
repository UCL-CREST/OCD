import java.io.Reader;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
public class PasswordFile {
    private String strFilepath;
    private String strCurrWord;
    private File fWordFile;
    private BufferedReader in;
    public PasswordFile ( final String strFilepath ) {
        this.strFilepath = strFilepath;
        try {
            this.fWordFile = new File ( this.strFilepath );
            this.in = new BufferedReader ( new FileReader ( this.fWordFile ) );
        } catch ( Exception ex ) {
            System.out.println ( "Could not open file " + this.strFilepath );
        }
    }
    String getPassword() {
        return this.strCurrWord;
    }
    String getNextPassword() {
        try {
            this.strCurrWord = this.in.readLine();
        } catch ( Exception ex ) {
            return null;
        }
        return this.strCurrWord;
    }
}
