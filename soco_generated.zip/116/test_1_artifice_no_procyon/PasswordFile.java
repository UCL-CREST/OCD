import java.io.Reader;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
public class PasswordFile {
    private String f00;
    private String f10;
    private File f20;
    private BufferedReader f30;
    public PasswordFile ( final String f00 ) {
        this.f00 = f00;
        try {
            this.f20 = new File ( this.f00 );
            this.f30 = new BufferedReader ( new FileReader ( this.f20 ) );
        } catch ( Exception ex ) {
            System.out.println ( "Could not open file " + this.f00 );
        }
    }
    String m00() {
        return this.f10;
    }
    String m10() {
        try {
            this.f10 = this.f30.readLine();
        } catch ( Exception ex ) {
            return null;
        }
        return this.f10;
    }
}
