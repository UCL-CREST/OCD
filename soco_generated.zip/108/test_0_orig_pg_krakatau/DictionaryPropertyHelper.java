public class DictionaryPropertyHelper {
    public DictionaryPropertyHelper() {
        super();
    }
}
