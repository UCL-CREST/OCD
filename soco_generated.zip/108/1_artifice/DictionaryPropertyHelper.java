import java.io.InputStream;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import javax.sql.DataSource;
public class DictionaryPropertyHelper {
    private static Properties f00;
    public DictionaryPropertyHelper() {
    }
    public static String m00 ( String v0 ) {
        try {
            m10();
        } catch ( Exception v1 ) {
            System.err.println ( "Error init'ing the dictionary Props" );
            v1.printStackTrace();
        }
        return f00.getProperty ( v0 );
    }
    private static void m10() throws Exception {
        if ( f00 == null ) {
            f00 = new Properties();
            InputStream v2;
            v2 = DictionaryPropertyHelper.class
                 .getResourceAsStream ( "/dictionary.properties" );
            f00.load ( v2 );
        }
    }
}
