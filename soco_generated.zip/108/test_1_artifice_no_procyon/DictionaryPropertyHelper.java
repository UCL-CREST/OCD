import java.util.Properties;
public class DictionaryPropertyHelper {
    private static Properties f00;
    public static String m00 ( final String s ) {
        try {
            m10();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the dictionary Props" );
            ex.printStackTrace();
        }
        return DictionaryPropertyHelper.f00.getProperty ( s );
    }
    private static void m10() throws Exception {
        if ( DictionaryPropertyHelper.f00 == null ) {
            ( DictionaryPropertyHelper.f00 = new Properties() ).load ( DictionaryPropertyHelper.class.getResourceAsStream ( "/dictionary.properties" ) );
        }
    }
}
