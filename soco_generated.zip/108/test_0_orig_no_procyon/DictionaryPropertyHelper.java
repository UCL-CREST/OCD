import java.util.Properties;
public class DictionaryPropertyHelper {
    private static Properties dictProps;
    public static String getProperty ( final String s ) {
        try {
            initProps();
        } catch ( Exception ex ) {
            System.err.println ( "Error init'ing the dictionary Props" );
            ex.printStackTrace();
        }
        return DictionaryPropertyHelper.dictProps.getProperty ( s );
    }
    private static void initProps() throws Exception {
        if ( DictionaryPropertyHelper.dictProps == null ) {
            ( DictionaryPropertyHelper.dictProps = new Properties() ).load ( DictionaryPropertyHelper.class.getResourceAsStream ( "/dictionary.properties" ) );
        }
    }
}
