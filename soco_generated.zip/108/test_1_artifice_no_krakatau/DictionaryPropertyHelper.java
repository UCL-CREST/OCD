public class DictionaryPropertyHelper {
    private static java.util.Properties f00;
    public DictionaryPropertyHelper() {
        super();
    }
    public static String m00 ( String s ) {
        try {
            DictionaryPropertyHelper.m10();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the dictionary Props" );
            a.printStackTrace();
        }
        return f00.getProperty ( s );
    }
    private static void m10() {
        if ( f00 == null ) {
            f00 = new java.util.Properties();
            java.io.InputStream a = DictionaryPropertyHelper.class.getResourceAsStream ( "/dictionary.properties" );
            f00.load ( a );
        }
    }
}
