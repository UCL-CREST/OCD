public class DictionaryPropertyHelper {
    private static java.util.Properties dictProps;
    public DictionaryPropertyHelper() {
        super();
    }
    public static String getProperty ( String s ) {
        try {
            DictionaryPropertyHelper.initProps();
        } catch ( Exception a ) {
            System.err.println ( "Error init'ing the dictionary Props" );
            a.printStackTrace();
        }
        return dictProps.getProperty ( s );
    }
    private static void initProps() {
        if ( dictProps == null ) {
            dictProps = new java.util.Properties();
            java.io.InputStream a = DictionaryPropertyHelper.class.getResourceAsStream ( "/dictionary.properties" );
            dictProps.load ( a );
        }
    }
}
