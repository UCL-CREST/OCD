



import javax.swing.*;

public class Dictionary {
    public static void main ( String args[] ) {
        PasswordCombination pwdCombination;

        pwdCombination = new PasswordCombination();
    }
}

