



import javax.swing.*;

public class BruteForce {
    public static void main ( String args[] ) {
        PasswordCombination pwdCombination;

        pwdCombination = new PasswordCombination();
    }
}

