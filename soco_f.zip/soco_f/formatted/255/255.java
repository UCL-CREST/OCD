

import java.io.*;
import java.net.*;
import java.*;
import java.util.*;

public class WatchDog {
    public static void main ( String[] args ) {
        new WatchDogThread ( "1" );
    }
}
